"""Local development API for Facai Mission Control."""

import asyncio
import json
import logging
import math
import os
import threading
import time
from contextvars import ContextVar
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import quote

from fastapi import FastAPI, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import (FileResponse, JSONResponse, PlainTextResponse, RedirectResponse,
                               StreamingResponse, Response)
from pydantic import BaseModel, Field

from .auth import AuthManager, CSRF_HEADER, SAFE_METHODS, SESSION_COOKIE
from .channels import ChannelRegistry, InboundMessage, OutboundReply
from .checkpoint import diff as git_diff
from .execution import execute_mission_task, mission_attribution
from .gateway import complete
from .n8n import CALLBACK_STATUSES, N8nIntegration, N8nRelay
from .opencode import OpenCodeAdapter
from .prompting import (complete_with_bound_model, convert_message, is_claude_model)
from .registries import Registries, public_registry_value
from .scheduler import Scheduler
from .store import Store

logger = logging.getLogger(__name__)
_request_owner = ContextVar("facai_request_owner", default="admin")


class MissionCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    original_input: str = Field(min_length=1)
    steps: list[str | dict] = Field(min_length=1)


class Binding(BaseModel):
    agent_id: str | None = None
    model_id: str | None = None
    skill_id: str | None = None
    runtime_id: str | None = None


class StepUpdate(BaseModel):
    status: str


class PromptUpdate(BaseModel):
    professional_prompt: str | None = None


class EventCreate(BaseModel):
    type: str = Field(min_length=1)
    payload: dict = Field(default_factory=dict)
    step_id: str | None = None
    session_id: str | None = None
    agent_id: str | None = None


class ModelRequest(BaseModel):
    messages: list[dict]
    step_id: str | None = None


class OpenCodeRun(BaseModel):
    prompt: str = Field(min_length=1)
    step_id: str | None = None
    model_ref: str | None = None
    timeout: int = Field(default=300, ge=1, le=3600)


class JobCreate(BaseModel):
    prompt: str = Field(min_length=1)
    step_id: str | None = None
    model_ref: str | None = None
    priority: int = 0
    max_attempts: int = Field(default=1, ge=1, le=10)
    timeout: int = Field(default=300, ge=1, le=3600)


class LoginRequest(BaseModel):
    username: str = "admin"
    password: str = Field(min_length=1)


class ChannelSend(BaseModel):
    recipient: str = Field(min_length=1)
    text: str = Field(min_length=1, max_length=4096)
    reply_to: str | None = None


class ChannelReply(BaseModel):
    text: str = Field(min_length=1, max_length=4096)


class WeChatVerifyCode(BaseModel):
    code: str = Field(min_length=4, max_length=8, pattern=r"^[0-9]+$")


PUBLIC_PATHS = frozenset({
    "/login",
    "/api/v1/auth/login",
    "/api/v1/auth/logout",
    "/api/v1/auth/session",
    "/api/v1/health",
    "/api/v1/n8n/callback",
    "/favicon.ico",
})


def is_public_path(path):
    """Webhook callbacks come from the messaging provider, not a browser session.

    They are public at the transport layer and authenticate themselves with the
    provider's verify token or HMAC signature inside the endpoint.
    """
    if path in PUBLIC_PATHS:
        return True
    return path.startswith("/api/v1/channels/") and path.endswith("/webhook")


# A minimal, harmless prompt for the manual connectivity probe. It exists only to
# prove the configured credential can complete a request; it is never sent on page
# load and its response body is discarded.
MODEL_TEST_PROMPT = "Reply with the single word: ok"

# A single authenticated user may run at most one connectivity probe per window.
# This is a server-side guard so repeated direct calls cannot drain upstream
# tokens; it is not a promise of high-precision pacing.
MODEL_TEST_COOLDOWN_SECONDS = 15.0

# Owner-facing "today's development progress". The facts live in a versioned JSON
# file so a human can audit and update them without touching code; percentages are
# always derived from the completed milestones in that file, so the API can never
# invent progress and can never report a provider as active when its call failed.
DAILY_PROGRESS_FILE = (Path(__file__).resolve().parent.parent
                       / "docs" / "DAILY_PROGRESS_2026-10-02.json")

DAILY_STATUS_LABELS = {
    "verified_local": "本地已验证",
    "in_progress": "进行中",
    "blocked": "受阻",
    "deployed": "已部署",
    "stopped": "已停止",
    "not_executing": "未执行",
}


def _daily_progress_path():
    override = os.getenv("FACAI_DAILY_PROGRESS_FILE", "").strip()
    return Path(override).resolve() if override else DAILY_PROGRESS_FILE


def _daily_progress_percent(milestones):
    """Whole 0-100 integer from completed milestones only.

    Floor division matches the mission progress convention: no milestone is 0,
    every milestone is 100, and a partial list rounds down so a half-finished
    task is never shown as complete or with a fractional value.
    """
    total = len(milestones)
    if total <= 0:
        return 0
    done = sum(1 for milestone in milestones if milestone.get("done") is True)
    return max(0, min(100, (100 * done) // total))


def daily_progress_payload():
    """Build the owner-facing progress payload from the versioned facts file."""
    raw = json.loads(_daily_progress_path().read_text(encoding="utf-8"))
    providers = []
    for entry in raw.get("providers", []):
        milestones = entry.get("milestones") or []
        status = entry.get("status") or "not_executing"
        providers.append({
            "id": entry.get("id") or entry.get("provider"),
            "provider": entry.get("provider"),
            "work": entry.get("work", ""),
            "status": status,
            "status_label": DAILY_STATUS_LABELS.get(status, status),
            "local_verified": bool(entry.get("local_verified")),
            "production_deployed": bool(entry.get("production_deployed")),
            "percent": _daily_progress_percent(milestones),
            "summary": entry.get("summary", ""),
            "milestones": milestones,
            "evidence": entry.get("evidence") or [],
            "blockers": entry.get("blockers") or [],
        })
    return {
        "date": raw.get("date"),
        "title": raw.get("title", "今日开发进度"),
        "note": raw.get("note", ""),
        "providers": providers,
    }


def _reported_token_usage(usage):
    """Normalize only the token counts the upstream actually reported.

    Arbitrary upstream payload keys are dropped so a connectivity probe can never
    echo a provider error body or a credential back through the ``usage`` field.
    """
    from .prompting import normalized_token_usage
    return normalized_token_usage(usage)


def _env_seconds(name, default):
    """Read a non-negative second interval from the environment."""
    try:
        return max(0.0, float(os.getenv(name, default)))
    except (TypeError, ValueError):
        return default


def _env_data_dir(override=None, name="FACAI_DATA_DIR", default="data"):
    """Resolve the runtime data directory, treating a blank value as unset.

    A blank ``FACAI_DATA_DIR`` in the systemd ``EnvironmentFile`` means "leave it
    at the default" (the shipped template itself blanks other settings). Treating
    ``""`` as a real path would silently resolve to the process working directory,
    which under the hardened unit (``ProtectSystem=strict`` with only ``data/``
    writable) makes the service fail to open its database on startup.
    """
    value = override if override is not None else os.getenv(name)
    value = "" if value is None else str(value).strip()
    return Path(value or default).resolve()


def create_app(data_dir=None, opencode_adapter=None):
    root = _env_data_dir(data_dir)
    store = Store(root)
    registries = Registries(store)
    auth = AuthManager(store)
    channels = ChannelRegistry(state_dir=root / "providers")
    opencode = opencode_adapter or OpenCodeAdapter()
    scheduler = Scheduler(store, opencode, registries, root)
    n8n = N8nIntegration()
    n8n_relay = N8nRelay(store, n8n)
    n8n_relay.initialize_cursor()
    wechat_poll_interval = _env_seconds("FACAI_WECHAT_POLL_INTERVAL", 0.2)
    wechat_error_backoff = _env_seconds("FACAI_WECHAT_ERROR_BACKOFF", 3.0)
    # Far longer than the bounded conversion model timeout, so a live worker is
    # never robbed of its claim while a crashed one is recovered promptly.
    conversion_lease_seconds = _env_seconds("FACAI_CONVERSION_LEASE_SECONDS", 300.0)

    @asynccontextmanager
    async def lifespan(_app):
        # A crashed conversion worker must not strand its inbound message across
        # a restart; expired leases return to the replayable RETRY pool.
        store.recover_stale_channel_conversions()
        wechat_task = asyncio.create_task(wechat_monitor())
        if os.getenv("FACAI_SCHEDULER_ENABLED", "1") != "0":
            scheduler.recover()
            scheduler.start()
        # The relay is a no-op while unconfigured, so starting it never fakes a
        # connection; it only forwards the stage events of new missions.
        relay_enabled = os.getenv("FACAI_N8N_RELAY_ENABLED", "1") != "0"
        if relay_enabled and n8n.configured():
            n8n_relay.start()
        try:
            yield
        finally:
            wechat_task.cancel()
            try:
                await wechat_task
            except asyncio.CancelledError:
                pass
            scheduler.stop()
            n8n_relay.stop()

    app = FastAPI(title="Facai Cloud", version="0.2.0", lifespan=lifespan)
    app.state.store = store
    app.state.registries = registries
    app.state.opencode = opencode
    app.state.scheduler = scheduler
    app.state.auth = auth
    app.state.channels = channels
    app.state.n8n = n8n
    app.state.n8n_relay = n8n_relay

    # Per-application-instance cooldown state for the manual connectivity probe.
    # Keyed by authenticated username, guarded by a lock so concurrent requests
    # cannot both pass the check, and based on monotonic time so wall-clock jumps
    # can neither extend nor bypass the window.
    model_test_lock = threading.Lock()
    model_test_probed_at = {}

    def current_owner():
        return _request_owner.get()

    def reserve_model_probe(owner):
        """Atomically claim the owner's probe slot.

        Returns ``None`` when the probe may proceed, otherwise the seconds left
        before the owner may probe again. The check-and-set happens under the
        lock so two concurrent requests cannot both be admitted.
        """
        now = time.monotonic()
        with model_test_lock:
            last = model_test_probed_at.get(owner)
            if last is not None:
                remaining = MODEL_TEST_COOLDOWN_SECONDS - (now - last)
                if remaining > 0:
                    return remaining
            model_test_probed_at[owner] = now
        return None

    def wants_html(request):
        return "text/html" in request.headers.get("accept", "")

    @app.middleware("http")
    async def admin_session_auth(request, call_next):
        owner = next(iter(auth.users), auth.username)
        if auth.enabled and not is_public_path(request.url.path):
            session = auth.session_from_request(request)
            if session is not None:
                owner = session["username"]
                if request.method not in SAFE_METHODS:
                    supplied = request.headers.get(CSRF_HEADER, "")
                    if not auth.valid_csrf(session, supplied):
                        return JSONResponse({"detail": "CSRF token missing or invalid"}, status_code=403)
            else:
                basic_owner = auth.basic_username(request)
                if basic_owner:
                    owner = basic_owner
                elif request.method in SAFE_METHODS and wants_html(request):
                    target = request.url.path
                    if request.url.query:
                        target = f"{target}?{request.url.query}"
                    return RedirectResponse(f"/login?next={quote(target, safe='')}", status_code=303)
                else:
                    return Response(status_code=401, headers={"WWW-Authenticate": 'Basic realm="Facai Cloud"'})
        token = _request_owner.set(owner)
        try:
            return await call_next(request)
        finally:
            _request_owner.reset(token)

    def require_mission(mission_id):
        mission = store.get(mission_id, owner_id=current_owner())
        if mission is None:
            raise HTTPException(404, "Mission not found")
        return mission

    @app.get("/")
    def index():
        return FileResponse(Path(__file__).parent / "static" / "index.html")

    @app.get("/login")
    def login_page():
        return FileResponse(Path(__file__).parent / "static" / "login.html")

    @app.get("/favicon.ico")
    def favicon():
        return Response(status_code=204)

    @app.get("/api/v1/auth/session")
    def auth_session(request: Request):
        if not auth.enabled:
            return {"auth_required": False, "authenticated": True, "username": auth.username}
        session = auth.session_from_request(request)
        if session is None:
            return {"auth_required": True, "authenticated": False}
        return {"auth_required": True, "authenticated": True,
                "username": session["username"], "csrf_token": session["csrf_token"],
                "expires_at": session["expires_at"]}

    @app.post("/api/v1/auth/login")
    def auth_login(body: LoginRequest, request: Request):
        if not auth.enabled:
            return {"authenticated": True, "auth_required": False}
        client_ip = request.client.host if request.client else "unknown"
        session, error = auth.login(body.username, body.password, client_ip)
        if error == "throttled":
            raise HTTPException(429, "Too many failed attempts; try again later")
        if error is not None:
            raise HTTPException(401, "Invalid credentials")
        response = JSONResponse({"authenticated": True, "auth_required": True,
                                 "username": session["username"],
                                 "csrf_token": session["csrf_token"],
                                 "expires_at": session["expires_at"]})
        response.set_cookie(SESSION_COOKIE, session["token"], max_age=auth.ttl_seconds,
                            httponly=True, samesite="strict", secure=auth.cookie_secure(request),
                            path="/")
        return response

    @app.post("/api/v1/auth/logout")
    def auth_logout(request: Request):
        auth.logout(request)
        response = JSONResponse({"authenticated": False})
        response.delete_cookie(SESSION_COOKIE, path="/")
        return response

    @app.get("/api/v1/health")
    def health():
        return {"status": "ready", "phase": 2, "auth_required": auth.enabled}

    @app.get("/api/v1/daily-progress")
    def daily_progress():
        """Owner-only view of what each AI provider changed today and its evidence.

        Protected by the same session/Basic middleware as the dashboard. The
        payload is read from a versioned JSON file and every percentage is
        computed from that file's completed milestones, so no activity is
        invented and ``local_verified`` never implies ``production_deployed``.
        """
        try:
            return daily_progress_payload()
        except FileNotFoundError:
            raise HTTPException(404, "Daily progress data not found") from None
        except (OSError, ValueError) as exc:
            # Path detail is never surfaced; the file may not exist in a partial
            # deployment, which is a configuration state, not a provider failure.
            logger.warning("daily progress data unreadable: %s", type(exc).__name__)
            raise HTTPException(500, "Daily progress data unreadable") from None

    @app.get("/api/v1/missions")
    def missions():
        return store.list(owner_id=current_owner())

    @app.post("/api/v1/missions", status_code=201)
    def create_mission(body: MissionCreate):
        try:
            return store.create(body.title, body.original_input, body.steps, owner_id=current_owner())
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from None

    @app.get("/api/v1/missions/{mission_id}")
    def get_mission(mission_id: str):
        return require_mission(mission_id)

    @app.patch("/api/v1/missions/{mission_id}/steps/{step_id}")
    def update_step(mission_id: str, step_id: str, body: StepUpdate):
        require_mission(mission_id)
        try:
            return store.step_status(mission_id, step_id, body.status)
        except KeyError:
            raise HTTPException(404, "Step not found") from None
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from None

    @app.get("/api/v1/missions/{mission_id}/events")
    def events(mission_id: str, after: int = 0):
        require_mission(mission_id)
        return store.events(mission_id, after)

    @app.post("/api/v1/missions/{mission_id}/events", status_code=201)
    def add_event(mission_id: str, body: EventCreate):
        require_mission(mission_id)
        try:
            event_id = store.append(mission_id, body.type, body.payload,
                                    body.step_id, body.session_id, body.agent_id)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from None
        return {"id": event_id}

    @app.get("/api/v1/missions/{mission_id}/stream")
    async def stream(mission_id: str, after: int = 0):
        require_mission(mission_id)

        async def generate():
            cursor = after
            while True:
                for event in store.events(mission_id, cursor):
                    cursor = event["sequence"]
                    yield f"id: {cursor}\nevent: mission\ndata: {json.dumps(event, ensure_ascii=False)}\n\n"
                await asyncio.sleep(1)

        return StreamingResponse(generate(), media_type="text/event-stream")

    @app.get("/api/v1/registries/{kind}")
    def list_registry(kind: str):
        if kind not in registries.KINDS:
            raise HTTPException(404, "Registry not found")
        # Credentials are never returned to the console.
        return {key: public_registry_value(value)
                for key, value in registries.list(kind, owner_id=current_owner()).items()}

    @app.put("/api/v1/registries/{kind}/{key}")
    def register(kind: str, key: str, value: dict):
        if kind not in registries.KINDS:
            raise HTTPException(404, "Registry not found")
        try:
            registries.register(kind, key, value, owner_id=current_owner())
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from None
        if kind in {"agents", "models", "runtimes"}:
            _retry_deferred_dispatches(("telegram", "whatsapp"))
        return {"id": key, "registered": True}

    @app.post("/api/v1/registries/models/{key}/test")
    async def test_model_connection(key: str):
        """Manually verify one registered model's credentials against its upstream.

        The response is limited to the classified outcome, provider/model
        attribution, latency and the token counts the provider actually reported.
        The upstream response body, the request headers and any credential are
        never returned or logged.
        """
        model = registries.resolve("models", key, owner_id=current_owner())
        if model is None:
            raise HTTPException(404, "Model not found")
        retry_after = reserve_model_probe(current_owner())
        if retry_after is not None:
            seconds = math.ceil(retry_after)
            # The upstream detail is never surfaced here; the operator only
            # learns that a probe is already in flight or too recent.
            raise HTTPException(429, f"Connectivity probe rate limited; retry in {seconds}s",
                                headers={"Retry-After": str(seconds)})
        started = time.perf_counter()
        try:
            result = await complete(model, [{"role": "user", "content": MODEL_TEST_PROMPT}])
        except (ValueError, KeyError) as exc:
            # Exception text can carry upstream hosts, headers or credentials, so
            # only a fixed generic message and the exception type are exposed.
            logger.warning("model connectivity probe for %s failed: %s", key, type(exc).__name__)
            raise HTTPException(422, "Model connectivity check failed") from None
        latency_ms = round((time.perf_counter() - started) * 1000, 1)
        result = result if isinstance(result, dict) else {}
        status = result.get("status")
        return {"ok": status == "MODEL_COMPLETED",
                "status": status,
                "label": result.get("label"),
                "provider": model.get("provider"),
                "model_id": key,
                "model": model.get("model"),
                "latency_ms": latency_ms,
                "usage": _reported_token_usage(result.get("usage"))}

    @app.put("/api/v1/missions/{mission_id}/binding")
    def bind(mission_id: str, body: Binding):
        require_mission(mission_id)
        provided = body.model_fields_set
        values = body.model_dump(exclude_unset=True)
        registry_for = {"agent_id": "agents", "model_id": "models",
                        "skill_id": "skills", "runtime_id": "runtimes"}
        for field, kind in registry_for.items():
            if field in provided and values[field] is not None:
                if values[field] not in registries.list(kind, owner_id=current_owner()):
                    raise HTTPException(422, f"Unknown {kind[:-1]}: {values[field]}")
        bound = store.bind(mission_id, **values, changed=set(values))
        if store.messages_for_mission(mission_id):
            ensure_channel_dispatch(mission_id)
        return bound

    @app.put("/api/v1/missions/{mission_id}/prompt")
    def set_prompt(mission_id: str, body: PromptUpdate):
        require_mission(mission_id)
        return store.set_prompt(mission_id, body.professional_prompt)

    @app.post("/api/v1/missions/{mission_id}/opencode/prepare")
    def prepare_opencode(mission_id: str):
        mission = require_mission(mission_id)
        if mission["agent_id"] != "opencode":
            raise HTTPException(409, "Mission is not bound to OpenCode")
        result = opencode.prepare(mission_id, root)
        result["session_id"] = store.start_session(mission_id, "opencode", mission["model_id"])
        return result

    @app.post("/api/v1/missions/{mission_id}/opencode/run")
    async def opencode_run(mission_id: str, body: OpenCodeRun):
        mission = require_mission(mission_id)
        if mission["agent_id"] != "opencode":
            raise HTTPException(409, "Mission is not bound to OpenCode")
        step = next((s for s in mission["steps"] if s["id"] == body.step_id), None)
        if body.step_id and step is None:
            raise HTTPException(404, "Step not found")
        owner = current_owner()
        model = registries.resolve("models", mission["model_id"], owner_id=owner)
        runtime = registries.resolve("runtimes", mission["runtime_id"], owner_id=owner)
        skill = registries.resolve("skills", mission["skill_id"], owner_id=owner)
        try:
            return await run_in_threadpool(
                execute_mission_task, store, opencode, mission, model, root, body.prompt,
                body.step_id, body.model_ref, body.timeout, runtime, skill)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from None
        except Exception:
            raise HTTPException(500, "OpenCode execution failed to start") from None

    @app.post("/api/v1/missions/{mission_id}/jobs", status_code=201)
    def enqueue_job(mission_id: str, body: JobCreate):
        mission = require_mission(mission_id)
        if mission["agent_id"] != "opencode":
            raise HTTPException(409, "Mission is not bound to OpenCode")
        if body.step_id and body.step_id not in {step["id"] for step in mission["steps"]}:
            raise HTTPException(404, "Step not found")
        try:
            return app.state.scheduler.enqueue(
                mission_id, body.prompt, step_id=body.step_id, model_ref=body.model_ref,
                priority=body.priority, max_attempts=body.max_attempts, timeout=body.timeout)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from None

    @app.get("/api/v1/missions/{mission_id}/jobs")
    def mission_jobs(mission_id: str):
        require_mission(mission_id)
        return store.jobs(mission_id, owner_id=current_owner())

    @app.get("/api/v1/jobs/{job_id}")
    def get_job(job_id: str):
        # A job id is globally unique; scope the lookup through its mission so a
        # guessed id can never reveal another tenant's prompt or status.
        job = store.get_job(job_id, owner_id=current_owner())
        if job is None:
            raise HTTPException(404, "Job not found")
        return job

    @app.post("/api/v1/jobs/{job_id}/{action}")
    def job_action(job_id: str, action: str):
        handlers = {"pause": store.pause_job, "resume": store.resume_job,
                    "cancel": store.cancel_job, "retry": store.retry_job}
        if action not in handlers:
            raise HTTPException(404, "Unknown job action")
        try:
            return handlers[action](job_id, owner_id=current_owner())
        except KeyError:
            raise HTTPException(404, "Job not found") from None
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from None

    @app.get("/api/v1/scheduler")
    def scheduler_stats():
        return app.state.scheduler.stats()

    @app.post("/api/v1/scheduler/run")
    async def scheduler_run():
        executed = await run_in_threadpool(app.state.scheduler.run_pending)
        return {"executed": executed}

    @app.get("/api/v1/missions/{mission_id}/diff")
    def mission_diff(mission_id: str, rev: str | None = None):
        mission = require_mission(mission_id)
        if not mission["checkpoints"]:
            return {"checkpoint": None, "available": False, "diff": "", "truncated": False}
        target = rev or mission["checkpoints"][-1]["commit_hash"]
        return {"checkpoint": target, **git_diff(mission["workspace"], target)}

    @app.get("/api/v1/missions/{mission_id}/artifacts/{artifact_id}")
    def artifact_content(mission_id: str, artifact_id: str, limit: int = 20000):
        mission = require_mission(mission_id)
        artifact = store.get_artifact(mission_id, artifact_id)
        if artifact is None:
            raise HTTPException(404, "Artifact not found")
        path = Path(artifact["path"]).resolve()
        workspace = Path(mission["workspace"]).resolve()
        if workspace not in path.parents or not path.is_file():
            raise HTTPException(404, "Artifact file is unavailable")
        content = path.read_text(encoding="utf-8", errors="replace")
        limit = max(1, min(limit, 200000))
        return {**artifact, "size": len(content), "truncated": len(content) > limit,
                "content": content[:limit]}

    @app.post("/api/v1/missions/{mission_id}/model/complete")
    async def model_complete(mission_id: str, body: ModelRequest):
        mission = require_mission(mission_id)
        model_id = mission["model_id"]
        if not model_id:
            raise HTTPException(409, "No model bound to this mission")
        owner = current_owner()
        model = registries.list("models", owner_id=owner).get(model_id)
        if model is None:
            raise HTTPException(409, "Bound model is unavailable")
        if body.step_id and body.step_id not in {step["id"] for step in mission["steps"]}:
            raise HTTPException(404, "Step not found")
        try:
            result = await complete(model, body.messages)
        except (ValueError, KeyError) as exc:
            raise HTTPException(422, str(exc)) from None
        runtime = registries.resolve("runtimes", mission["runtime_id"], owner_id=owner)
        skill = registries.resolve("skills", mission["skill_id"], owner_id=owner)
        attribution = mission_attribution(mission, model, runtime, skill)
        usage = result.get("usage") or {}
        tokens = usage.get("total_tokens") if isinstance(usage, dict) else None
        if tokens:
            store.add_cost(mission_id, model.get("provider", "custom"), model_id, 0.0, tokens)
        store.append(mission_id, result["status"],
                     {**attribution, "http_status": result["http_status"],
                      "reason": result["reason"], "upstream": result["upstream"],
                      "tokens": tokens},
                     body.step_id, agent_id=mission["agent_id"])
        return {**attribution, **result, "tokens": tokens}

    # --- message channels ------------------------------------------------------

    def require_channel(channel):
        provider = channels.get(channel)
        if provider is None:
            raise HTTPException(404, "Channel not found")
        return provider

    def unconfigured(provider):
        return HTTPException(503, {"detail": f"{provider.name} channel is not configured",
                                   "missing": provider.missing()})

    @app.get("/api/v1/channels")
    def list_channels():
        return channels.statuses()

    @app.get("/api/v1/channels/{channel}")
    def get_channel(channel: str):
        return require_channel(channel).status().to_dict()

    @app.get("/api/v1/channels/{channel}/messages")
    def channel_messages(channel: str, limit: int = 100):
        require_channel(channel)
        return store.channel_messages(channel, limit, owner_id=current_owner())

    def default_binding(owner_id="admin"):
        """Return the first fully-dispatchable default binding, or None.

        Only an agent whose adapter is actually wired (OpenCode) together with a
        resolvable model and runtime counts as valid. Anything less is reported
        as deferred rather than faked.
        """
        agent_id = next((key for key, value in registries.list("agents", owner_id=owner_id).items()
                         if value.get("adapter") == "opencode"), None)
        model_id = next(iter(registries.list("models", owner_id=owner_id)), None)
        runtime_id = next(iter(registries.list("runtimes", owner_id=owner_id)), None)
        if agent_id and model_id and runtime_id:
            return agent_id, model_id, runtime_id
        return None

    def ensure_channel_dispatch(mission_id):
        """Bind a valid default and enqueue once; never enqueue without one."""
        mission = store.get(mission_id)
        if mission is None or store.jobs(mission_id):
            return {"status": "QUEUED" if mission and store.jobs(mission_id) else "MISSING"}
        owner = mission["owner_id"]
        if not mission["agent_id"]:
            binding = default_binding(owner_id=owner)
            if binding is None:
                store.append(mission_id, "DISPATCH_DEFERRED",
                             {"reason": "NO_VALID_BINDING",
                              "detail": "缺少可用的 Agent / Model / Runtime 绑定"})
                return {"status": "DEFERRED", "reason": "NO_VALID_BINDING"}
            agent_id, model_id, runtime_id = binding
            store.bind(mission_id, agent_id=agent_id, model_id=model_id, runtime_id=runtime_id,
                       changed={"agent_id", "model_id", "runtime_id"})
            mission = store.get(mission_id)
        agent = registries.resolve("agents", mission["agent_id"], owner_id=owner)
        model = registries.resolve("models", mission["model_id"], owner_id=owner)
        runtime = registries.resolve("runtimes", mission["runtime_id"], owner_id=owner)
        if not agent or not model or not runtime or agent.get("adapter") != "opencode":
            store.append(mission_id, "DISPATCH_DEFERRED",
                         {"reason": "INVALID_BINDING", "agent_id": mission["agent_id"],
                          "model_id": mission["model_id"], "runtime_id": mission["runtime_id"]})
            return {"status": "DEFERRED", "reason": "INVALID_BINDING"}
        step_id = mission["steps"][0]["id"] if mission["steps"] else None
        job = store.enqueue_job(mission_id, mission["professional_prompt"] or mission["original_input"],
                                step_id=step_id, priority=0, max_attempts=1, timeout=300,
                                dispatch={"agent_id": mission["agent_id"],
                                          "model_id": mission["model_id"],
                                          "runtime_id": mission["runtime_id"],
                                          "step_id": step_id})
        return {"status": "QUEUED", "job_id": job["id"]}

    def bound_conversion_model(owner_id="admin"):
        """Return the default dispatch model, or None when it cannot be called.

        Claude/Anthropic entries are never selected. A missing or incomplete
        registry entry is also skipped so conversion falls back deterministically.
        """
        binding = default_binding(owner_id=owner_id)
        if binding is None:
            return None, None
        _agent_id, model_id, _runtime_id = binding
        model = registries.resolve("models", model_id, owner_id=owner_id)
        if not model or is_claude_model(model) or not model.get("endpoint") or not model.get("model"):
            return None, None
        return model_id, model

    def convert_channel_text(channel, text, owner_id="admin"):
        """Prefer the bound model, then fall back without exposing upstream errors."""
        fallback = convert_message(text, channel)
        model_id, model = bound_conversion_model(owner_id=owner_id)
        if model is None:
            return fallback
        try:
            return complete_with_bound_model(text, channel, model_id, model, complete)
        except Exception as exc:
            logger.warning("channel prompt conversion for %s fell back: %s",
                           model_id, type(exc).__name__)
            return fallback

    def conversion_payload_for(channel, message_id, conversion):
        payload = {
            "channel": channel, "message_id": message_id,
            "original_input": conversion.original,
            "professional_prompt": conversion.professional,
            "basis": list(conversion.basis),
            "conversion_status": "CONVERTED",
            "conversion_source": conversion.source,
        }
        if conversion.model_id:
            payload["model_id"] = conversion.model_id
        if conversion.usage:
            payload["usage"] = conversion.usage
        return payload

    def convert_and_link_mission(channel, message_id, recorded, owner_id="admin"):
        """Convert one inbound message exactly once, then link and dispatch it.

        A durable per-message lease serializes duplicate webhook deliveries: only
        the claim holder may invoke the conversion model, and every duplicate gets
        a truthful ``IN_PROGRESS`` result without conversion or dispatch. The lease
        is released on failure so a replay retries, and it expires if the holder
        crashes so stale claims are recovered.
        """
        duplicate = not recorded
        claim = store.claim_channel_conversion(message_id, conversion_lease_seconds)
        if not claim["claimed"]:
            row = claim["row"]
            if claim["reason"] == "ALREADY_LINKED" and row and row["mission_id"]:
                dispatch = ensure_channel_dispatch(row["mission_id"])
                return {"status": dispatch["status"], "message_id": message_id, "durable": True,
                        "mission_id": row["mission_id"], "duplicate": duplicate, **dispatch}
            if claim["reason"] == "IN_PROGRESS":
                return {"status": "IN_PROGRESS", "message_id": message_id, "durable": True,
                        "duplicate": duplicate}
            return {"status": "RETRY", "reason": "CONVERSION_CLAIM_FAILED",
                    "message_id": message_id, "durable": True, "duplicate": duplicate}
        owner = claim["owner"]
        text = claim["row"]["text"]
        try:
            conversion = convert_channel_text(channel, text, owner_id=owner_id)
        except ValueError as exc:
            store.release_channel_conversion(message_id, owner, status="CONVERSION_FAILED")
            if recorded:
                store.record_channel_event(channel, message_id, "CONVERSION_FAILED",
                                           {"error": str(exc), "original_input": text})
            return {"status": "CONVERSION_FAILED", "message_id": message_id, "durable": True,
                    "duplicate": duplicate, "error": str(exc)}
        conversion_payload = conversion_payload_for(channel, message_id, conversion)
        try:
            mission_id, _created = store.create_mission_from_message(
                message_id, channel, title=conversion.title,
                original_input=conversion.original, labels=list(conversion.steps),
                professional_prompt=conversion.professional, conversion_payload=conversion_payload,
                owner_id=owner_id)
        except Exception:
            # Never strand the lease on an unexpected failure: release it so the
            # next delivery or the monitor can replay this message.
            store.release_channel_conversion(message_id, owner)
            raise
        if mission_id is None:
            store.release_channel_conversion(message_id, owner)
            return {"status": "RETRY", "reason": "MISSION_CREATION_FAILED",
                    "message_id": message_id, "durable": True, "duplicate": duplicate}
        if recorded:
            store.record_channel_event(channel, message_id, "PROMPT_CONVERTED", conversion_payload)
        dispatch = ensure_channel_dispatch(mission_id)
        return {"status": dispatch["status"], "message_id": message_id, "durable": True,
                "mission_id": mission_id, "duplicate": duplicate, **dispatch}

    def process_channel_message(channel, message):
        """Persist original channel text, convert it and retry its idempotent dispatch."""
        payload = dict(message.raw or {})
        context_token = (message.metadata or {}).get("context_token")
        if context_token:
            payload["context_token"] = context_token
        owner = current_owner()
        message_id = store.record_channel_message(
            channel, "INBOUND", "RECEIVED", external_id=message.external_id,
            sender=message.sender, recipient=message.recipient, kind=message.kind,
            text=message.text, payload=payload, owner_id=owner)
        recorded = message_id is not None
        if message_id is None:
            existing = store.channel_message_by_external_id(channel, message.external_id)
            if existing is None:
                return {"status": "RETRY", "reason": "MESSAGE_LOOKUP_FAILED", "durable": False}
            message_id = existing["id"]
        existing = store.channel_message(message_id)
        if existing["mission_id"]:
            dispatch = ensure_channel_dispatch(existing["mission_id"])
            return {"status": dispatch["status"], "message_id": message_id, "durable": True,
                    "mission_id": existing["mission_id"], "duplicate": not recorded, **dispatch}
        return convert_and_link_mission(channel, message_id, recorded, owner_id=owner)

    def process_telegram_message(message):
        return process_channel_message("telegram", message)

    def _wechat_message_from_row(row):
        """Rebuild a normalized inbound message from a durable audit row."""
        payload = row.get("payload") or {}
        return InboundMessage(
            channel="wechat", external_id=row["external_id"], sender=row["sender"] or "",
            text=row["text"], received_at=row["created_at"], recipient=row["recipient"],
            kind=row["kind"], raw=payload,
            metadata={"context_token": payload.get("context_token")})

    def _wechat_message_id(external_id):
        try:
            existing = store.channel_message_by_external_id("wechat", external_id)
        except Exception:
            logger.exception("wechat: could not look up message %s", external_id)
            return None
        return existing["id"] if existing else None

    def _wechat_retry_audit(message_id, event_type, reason, exc=None):
        """Best-effort RETRY audit; a failing write must never stop the task."""
        try:
            store.set_channel_message_status(message_id, "RETRY")
        except Exception:
            logger.exception("wechat: could not mark message %s RETRY", message_id)
        payload = {"reason": reason}
        if exc is not None:
            payload["error"] = str(exc)
            payload["error_type"] = type(exc).__name__
        try:
            store.record_channel_event("wechat", message_id, event_type, payload)
        except Exception:
            logger.exception("wechat: could not record %s for message %s",
                             event_type, message_id)

    def _process_wechat_message(message):
        """Process one inbound message in isolation; never abort the monitor."""
        message_id = _wechat_message_id(message.external_id)
        try:
            result = process_channel_message("wechat", message)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("wechat: processing message %s failed", message.external_id)
            if message_id is None:
                message_id = _wechat_message_id(message.external_id)
            if message_id is not None:
                _wechat_retry_audit(message_id, "PROCESSING_RETRY", "PROCESSING_ERROR", exc)
            return {"status": "RETRY", "reason": "PROCESSING_ERROR",
                    "message_id": message_id, "durable": message_id is not None}
        if result.get("status") == "RETRY":
            if message_id is None:
                message_id = _wechat_message_id(message.external_id)
            if message_id is not None:
                _wechat_retry_audit(message_id, "MISSION_CREATION_FAILED",
                                    result.get("reason", "MISSION_CREATION_FAILED"))
                result["message_id"] = message_id
                result["durable"] = True
        return result

    def _retry_deferred_dispatches(channels):
        """Retry durable channel missions after an operator fixes their binding."""
        for message in store.deferred_channel_messages(channels):
            mission_id = message["mission_id"]
            mission = store.get(mission_id)
            if mission is None:
                continue
            owner = mission.get("owner_id", "admin")
            if mission.get("agent_id"):
                agent = registries.resolve("agents", mission.get("agent_id"), owner_id=owner)
                model = registries.resolve("models", mission.get("model_id"), owner_id=owner)
                runtime = registries.resolve("runtimes", mission["runtime_id"], owner_id=owner)
                binding_ready = bool(agent and model and runtime
                                     and agent.get("adapter") == "opencode")
            else:
                binding_ready = default_binding(owner_id=owner) is not None
            if binding_ready:
                ensure_channel_dispatch(mission_id)

    async def wechat_monitor():
        """Long-poll personal WeChat and feed messages into the same audited pipeline."""
        provider = channels.require("wechat")
        while True:
            try:
                if not provider.configured():
                    await asyncio.sleep(wechat_error_backoff)
                    continue
                # Return fresh crashed conversion claims to the RETRY pool before
                # replaying, so a message abandoned mid-conversion is retried.
                store.recover_stale_channel_conversions()
                # A previously deferred Mission is already durable and therefore
                # absent from pending_inbound_messages. Retry its queue binding
                # when registry entries become available, without new upstream
                # delivery or repeated deferred events.
                _retry_deferred_dispatches(("wechat",))
                # Replay durable pending messages before polling so a message
                # recorded just before a transient failure is never lost.
                for pending in store.pending_inbound_messages("wechat"):
                    await run_in_threadpool(
                        _process_wechat_message, _wechat_message_from_row(pending))
                result = await provider.fetch_updates()
                if result.get("state") != "OK":
                    await asyncio.sleep(wechat_error_backoff)
                    continue
                for message in result.get("messages", []):
                    processed = await run_in_threadpool(_process_wechat_message, message)
                    if not processed.get("durable", processed.get("status") != "RETRY"):
                        # Keep the old iLink cursor so the next poll can replay a
                        # batch that failed before an inbound message was stored.
                        break
                else:
                    acknowledge = getattr(provider, "acknowledge_updates", None)
                    if callable(acknowledge):
                        acknowledge()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("wechat: monitoring round failed; retrying")
                await asyncio.sleep(wechat_error_backoff)
                continue
            await asyncio.sleep(wechat_poll_interval)

    @app.get("/api/v1/inbox")
    def inbox(limit: int = 100):
        return store.channel_messages(limit=limit, owner_id=current_owner())

    @app.get("/api/v1/missions/{mission_id}/channel-messages")
    def mission_channel_messages(mission_id: str):
        require_mission(mission_id)
        return store.messages_for_mission(mission_id)

    @app.get("/api/v1/channels/{channel}/messages/{message_id}/events")
    def channel_message_events(channel: str, message_id: str):
        require_channel(channel)
        if store.channel_message(message_id, owner_id=current_owner()) is None:
            raise HTTPException(404, "Channel message not found")
        return store.channel_events(message_id=message_id, channel=channel)

    @app.post("/api/v1/channels/{channel}/messages/{message_id}/dispatch", status_code=201)
    def dispatch_channel_message(channel: str, message_id: str):
        require_channel(channel)
        message = store.channel_message(message_id, owner_id=current_owner())
        if message is None or message["channel"] != channel or message["direction"] != "INBOUND":
            raise HTTPException(404, "Inbound channel message not found")
        if message["mission_id"]:
            ensure_channel_dispatch(message["mission_id"])
            return require_mission(message["mission_id"])
        result = convert_and_link_mission(channel, message_id, recorded=True)
        if result["status"] == "CONVERSION_FAILED":
            # A failed conversion never drops the message: it stays verbatim and
            # can be dispatched again once its content is understood.
            raise HTTPException(422, f"消息无法转换为专业提示词：{result.get('error', '')}") from None
        if result["status"] == "IN_PROGRESS":
            # Another delivery already holds the conversion lease; report that
            # truthfully instead of calling the model or creating a second task.
            return JSONResponse(result, status_code=202)
        mission_id = result.get("mission_id")
        if not mission_id:
            raise HTTPException(503, "消息暂时无法创建任务，请稍后重试")
        ensure_channel_dispatch(mission_id)
        return require_mission(mission_id)

    @app.post("/api/v1/channels/wechat/login")
    async def wechat_login_start():
        provider = require_channel("wechat")
        if provider.configured():
            return {"state": "AUTHORIZED"}
        result = await provider.start_login()
        if result.get("state") == "FAILED":
            raise HTTPException(502, result.get("error", "WECHAT_LOGIN_FAILED"))
        return result

    @app.post("/api/v1/channels/wechat/messages/{message_id}/reply")
    async def wechat_reply(message_id: str, body: ChannelReply):
        provider = require_channel("wechat")
        if not provider.configured():
            raise unconfigured(provider)
        source = store.channel_message(message_id, owner_id=current_owner())
        if source is None or source["channel"] != "wechat" or source["direction"] != "INBOUND":
            raise HTTPException(404, "Inbound WeChat message not found")
        metadata = {"context_token": source["payload"].get("context_token")}
        result = await provider.send(OutboundReply(channel="wechat", recipient=source["sender"],
                                                   text=body.text, metadata=metadata))
        store.record_channel_message("wechat", "OUTBOUND", result.get("status", "FAILED"),
            external_id=result.get("external_id"), recipient=source["sender"], kind="text",
            text=body.text, payload={"reply_to_message": message_id,
                                     "http_status": result.get("http_status"),
                                     "error": result.get("error")}, mission_id=source.get("mission_id"),
            owner_id=current_owner())
        return result

    @app.get("/api/v1/channels/wechat/login")
    async def wechat_login_status():
        provider = require_channel("wechat")
        result = await provider.poll_login()
        if result.get("state") == "AUTHORIZED":
            store.record_channel_event("wechat", result["account"], "ACCOUNT_AUTHORIZED",
                                       {"account": result["account"], "method": "QR"})
        return result

    @app.post("/api/v1/channels/wechat/login/verify")
    def wechat_login_verify(body: WeChatVerifyCode):
        provider = require_channel("wechat")
        try:
            return provider.submit_verify_code(body.code)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from None

    @app.get("/api/v1/channels/{channel}/webhook")
    def channel_webhook_verify(channel: str, request: Request):
        provider = require_channel(channel)
        if channel == "telegram":
            raise HTTPException(405, "Telegram webhooks accept POST only", headers={"Allow": "POST"})
        if not provider.implemented:
            raise HTTPException(501, f"{channel} adapter interface is reserved, not wired")
        if not provider.configured():
            raise unconfigured(provider)
        challenge = provider.verify_challenge(request.query_params)
        if challenge is None:
            raise HTTPException(403, "Webhook verification failed")
        return PlainTextResponse(challenge)

    @app.post("/api/v1/channels/{channel}/webhook")
    async def channel_webhook_receive(channel: str, request: Request):
        provider = require_channel(channel)
        if not provider.implemented:
            raise HTTPException(501, f"{channel} adapter interface is reserved, not wired")
        if not provider.configured():
            raise unconfigured(provider)
        chunks = []
        size = 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > 1024 * 1024:
                raise HTTPException(413, "Webhook body exceeds 1 MiB")
            chunks.append(chunk)
        body = b"".join(chunks)
        if not provider.verify_signature(body, request.headers):
            raise HTTPException(403, "Webhook signature verification failed")
        try:
            payload = json.loads(body or b"{}")
        except ValueError:
            raise HTTPException(400, "Webhook body must be valid JSON") from None
        try:
            messages = provider.parse_inbound(payload)
        except ValueError:
            raise HTTPException(400, "Invalid channel message payload") from None
        except NotImplementedError:
            raise HTTPException(501, f"{channel} inbound parsing is reserved, not wired") from None
        dispatch_channels = ("telegram", "whatsapp")
        if channel in dispatch_channels:
            # Without a long-poll monitor, the next webhook delivery is the
            # natural recovery point for a claim abandoned by a crashed worker.
            store.recover_stale_channel_conversions()
        received = 0
        dispatch_results = []
        for message in messages:
            if channel in dispatch_channels:
                dispatch_results.append(await run_in_threadpool(
                    process_channel_message, channel, message))
                received += dispatch_results[-1].get("duplicate") is False
                continue
            recorded = store.record_channel_message(
                channel, "INBOUND", "RECEIVED", external_id=message.external_id,
                sender=message.sender, recipient=message.recipient, kind=message.kind,
                text=message.text, payload=message.raw, owner_id=current_owner())
            received += recorded is not None
        if channel in dispatch_channels:
            if not dispatch_results:
                return {"received": 0, "dispatch": "NO_MESSAGES", "conversion_failed": 0,
                        "results": []}
            deferred = [result for result in dispatch_results if result["status"] in {"DEFERRED", "RETRY"}]
            conversion_failed = sum(result["status"] == "CONVERSION_FAILED" for result in dispatch_results)
            if deferred:
                raise HTTPException(503, {"received": received, "dispatch": "DEFERRED",
                                          "results": dispatch_results})
            return {"received": received, "dispatch": "QUEUED", "conversion_failed": conversion_failed,
                    "results": dispatch_results}
        return {"received": received}

    @app.post("/api/v1/channels/{channel}/send")
    async def channel_send(channel: str, body: ChannelSend):
        provider = require_channel(channel)
        if not provider.implemented:
            raise HTTPException(501, f"{channel} adapter interface is reserved, not wired")
        if not provider.configured():
            raise unconfigured(provider)
        reply = OutboundReply(channel=channel, recipient=body.recipient,
                              text=body.text, reply_to=body.reply_to)
        try:
            result = await provider.send(reply)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from None
        except NotImplementedError:
            raise HTTPException(501, f"{channel} outbound send is reserved, not wired") from None
        store.record_channel_message(
            channel, "OUTBOUND", result.get("status", "FAILED"),
            external_id=result.get("external_id"), recipient=body.recipient,
            kind="text", text=body.text,
            payload={"http_status": result.get("http_status"), "error": result.get("error")},
            owner_id=current_owner())
        return result

    # --- n8n automation --------------------------------------------------------

    def public_delivery(delivery):
        """Delivery view without the forwarded payload or any secret."""
        return {key: delivery[key] for key in (
            "id", "request_id", "mission_id", "event_id", "event_type", "status",
            "attempts", "max_attempts", "http_status", "error", "retryable",
            "created_at", "updated_at")}

    async def read_limited_body(request, limit=1024 * 1024):
        chunks = []
        size = 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > limit:
                raise HTTPException(413, "Request body exceeds 1 MiB")
            chunks.append(chunk)
        return b"".join(chunks)

    @app.get("/api/v1/n8n")
    def n8n_status():
        return {
            **n8n.status(),
            "summary": store.n8n_delivery_summary(),
            "recent": [public_delivery(d) for d in store.n8n_deliveries(15)],
            "recent_callbacks": store.n8n_callbacks(10),
        }

    @app.post("/api/v1/n8n/relay")
    async def n8n_relay_run():
        return await run_in_threadpool(app.state.n8n_relay.run_pending)

    @app.post("/api/v1/n8n/callback")
    async def n8n_callback(request: Request):
        """Signed, idempotent callback that updates a mission's events/steps.

        n8n authenticates with the same HMAC scheme Facai uses outbound. The
        callback is public at the transport layer (no browser session) but is
        rejected unless the timestamp is fresh and the signature matches.
        """
        if not n8n.callback_ready():
            raise HTTPException(503, {
                "state": n8n.status()["state"],
                "missing": n8n.missing(),
                "detail": "n8n 回调签名密钥未配置"})
        body = await read_limited_body(request)
        if not n8n.verify(body, request.headers):
            raise HTTPException(403, "n8n signature verification failed")
        try:
            payload = json.loads(body or b"{}")
        except ValueError:
            raise HTTPException(400, "Callback body must be valid JSON") from None
        if not isinstance(payload, dict):
            raise HTTPException(400, "Callback body must be a JSON object")
        request_id = payload.get("request_id")
        if not isinstance(request_id, str) or not request_id.strip() or len(request_id) > 200:
            raise HTTPException(422, "request_id is required")
        mission = store.get(payload.get("mission_id") or "")
        if mission is None:
            raise HTTPException(404, "Mission not found")
        mission_id = mission["id"]
        status = payload.get("status") or "SUCCEEDED"
        if status not in CALLBACK_STATUSES:
            raise HTTPException(422, "Invalid callback status")
        error = payload.get("error") if isinstance(payload.get("error"), dict) else None
        retryable = bool(error.get("retryable")) if error else False
        detail = json.dumps({"status": status, "error": error,
                             "retry": payload.get("retry")}, ensure_ascii=False)
        claimed, existing = store.claim_n8n_callback(request_id, mission_id, status, detail)
        if not claimed:
            return {"duplicate": True, "request_id": request_id, "mission_id": mission_id,
                    "status": existing["status"]}
        applied = {"event_id": None, "step": None}
        try:
            event = payload.get("event")
            if isinstance(event, dict) and event.get("type"):
                applied["event_id"] = store.append(
                    mission_id, str(event["type"]),
                    event.get("payload") if isinstance(event.get("payload"), dict) else {},
                    event.get("step_id"), event.get("session_id"), event.get("agent_id"))
            step = payload.get("step")
            if isinstance(step, dict) and step.get("step_id") and step.get("status"):
                store.step_status(mission_id, step["step_id"], step["status"])
                applied["step"] = {"step_id": step["step_id"], "status": step["status"]}
        except KeyError:
            store.finish_n8n_callback(request_id, status, "UNKNOWN_STEP")
            raise HTTPException(404, "Step not found") from None
        except ValueError as exc:
            store.finish_n8n_callback(request_id, status, f"INVALID_TRANSITION: {exc}")
            raise HTTPException(409, str(exc)) from None
        return {"duplicate": False, "request_id": request_id, "mission_id": mission_id,
                "status": status, "applied": applied, "retryable": retryable}

    return app


app = create_app()
