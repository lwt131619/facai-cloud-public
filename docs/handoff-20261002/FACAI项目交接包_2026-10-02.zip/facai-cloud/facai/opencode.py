"""OpenCode integration boundary.

Preparation only creates the isolated workspace. Execution runs the OpenCode
CLI inside exactly one mission workspace and returns its real outcome so the
API can attribute success or failure honestly. No credential is placed on the
command line; OpenCode reads its own provider store from the environment.
"""

import json
import re
import shutil
import subprocess
import threading
from pathlib import Path


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value


_SECRET_PATTERNS = (
    re.compile(r"(?i)([\"']?(?:api[_-]?key|access[_-]?token|secret|password)[\"']?\s*:\s*[\"']?)[^\s,;}\"']+"),
    re.compile(r"(?i)(api[_-]?key|access[_-]?token|secret|password)(\s*[=:]\s*)[^\s,;\"']+"),
    re.compile(r"(?i)Bearer\s+[^\s,;\"']+"),
)


def redact_output(value):
    """Remove common credential forms before output is exposed or persisted."""
    value = _text(value)
    for pattern in _SECRET_PATTERNS:
        def replacement(match):
            if match.lastindex == 2:
                prefix = match.group(1) + match.group(2)
            elif match.lastindex == 1:
                prefix = match.group(1)
            else:
                prefix = "Bearer "
            return prefix + "[REDACTED]"
        value = pattern.sub(replacement, value)
    return value


def summarize_output(stdout):
    """Parse OpenCode's --format json stream into text, tokens and reported cost.

    Cost is summed across steps; tokens use the largest cumulative count because
    OpenCode reports a running total per session.
    """
    parts, cost, tokens, lines = [], 0.0, 0, 0
    for line in (stdout or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if not isinstance(event, dict):
            continue
        lines += 1
        part = event.get("part") or {}
        if part.get("type") == "text" and part.get("text"):
            parts.append(part["text"])
        if isinstance(part.get("cost"), (int, float)):
            cost += part["cost"]
        token_data = part.get("tokens")
        if isinstance(token_data, dict) and isinstance(token_data.get("total"), (int, float)):
            tokens = max(tokens, int(token_data["total"]))
    return {"text": "\n".join(parts), "cost": round(cost, 8), "tokens": tokens, "event_lines": lines}


class OpenCodeAdapter:
    def __init__(self, binary=None, runner=None):
        self.binary = binary
        self.runner = runner or self._run

    def availability(self):
        binary = self.binary or shutil.which("opencode")
        return {"installed": binary is not None, "binary": binary}

    @staticmethod
    def _run(command, cwd, timeout, on_output=None):
        # Inherits the process environment (including OpenCode's own provider store).
        # Reader threads drain both pipes concurrently and publish complete lines
        # as they arrive; this works on both Windows and POSIX (unlike selectors
        # over subprocess pipes on Windows).
        process = subprocess.Popen(command, cwd=str(cwd), stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                   errors="replace", bufsize=1)
        output = {"stdout": [], "stderr": []}

        def drain(stream_name, pipe):
            try:
                for line in iter(pipe.readline, ""):
                    output[stream_name].append(line)
                    if on_output:
                        on_output(stream_name, redact_output(line.rstrip("\r\n")))
            finally:
                pipe.close()

        readers = [threading.Thread(target=drain, args=(name, pipe), daemon=True)
                   for name, pipe in (("stdout", process.stdout), ("stderr", process.stderr))]
        for reader in readers:
            reader.start()
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            process.kill()
            process.wait()
            for reader in readers:
                reader.join()
            raise subprocess.TimeoutExpired(command, timeout,
                                            output="".join(output["stdout"]),
                                            stderr="".join(output["stderr"])) from exc
        for reader in readers:
            reader.join()
        return subprocess.CompletedProcess(command, process.returncode,
                                           "".join(output["stdout"]), "".join(output["stderr"]))

    def workspace(self, mission, root):
        workspace = (Path(root) / "workspaces" / mission).resolve()
        base = (Path(root) / "workspaces").resolve()
        if workspace.parent != base:
            raise ValueError("Invalid mission workspace")
        return workspace

    def prepare(self, mission, root):
        workspace = self.workspace(mission, root)
        workspace.mkdir(parents=True, exist_ok=True)
        return {"mission_id": mission, "workspace": str(workspace), **self.availability()}

    def command(self, prompt, workspace, model_ref=None):
        availability = self.availability()
        binary = self.binary or availability["binary"]
        if binary is None:
            raise ValueError("OpenCode binary is not installed")
        command = [binary, "run", "--format", "json"]
        if model_ref:
            command += ["--model", model_ref]
        command += ["--dir", str(workspace)]
        command.append(prompt)
        return command

    def execute(self, mission, root, prompt, model_ref=None, timeout=300, on_output=None):
        workspace = self.workspace(mission, root)
        workspace.mkdir(parents=True, exist_ok=True)
        command = self.command(prompt, workspace, model_ref)
        streamed_lines = 0

        def emit(stream, line):
            nonlocal streamed_lines
            streamed_lines += 1
            if on_output:
                on_output(stream, redact_output(line))

        try:
            if self.runner == self._run:
                completed = self.runner(command, workspace, timeout, on_output=emit)
            else:
                # Preserve the historical injected-runner API used by callers
                # and tests. New runners may opt into the output callback.
                import inspect
                if "on_output" in inspect.signature(self.runner).parameters:
                    completed = self.runner(command, workspace, timeout, on_output=emit)
                else:
                    completed = self.runner(command, workspace, timeout)
        except subprocess.TimeoutExpired as exc:
            return {"status": "OPENCODE_TIMEOUT", "exit_code": None, "workspace": str(workspace),
                    "stdout": redact_output(exc.stdout), "stderr": redact_output(exc.stderr),
                    "streamed": streamed_lines > 0}
        exit_code = getattr(completed, "returncode", None)
        return {
            "status": "OPENCODE_COMPLETED" if exit_code == 0 else "OPENCODE_FAILED",
            "exit_code": exit_code,
            "workspace": str(workspace),
            "stdout": redact_output(getattr(completed, "stdout", "")),
            "stderr": redact_output(getattr(completed, "stderr", "")),
            "streamed": streamed_lines > 0,
        }
