"""SQLite mission record. Every mutable item is keyed by mission ID."""

import json
import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path
from uuid import uuid4


def now():
    return datetime.now(timezone.utc).isoformat()


def mission_progress(completed, total, active=0):
    """Whole-percent mission progress in ``[0, 100]`` as an ``int``.

    Only real COMPLETED steps count (never a RUNNING or FAILED one), and the
    arithmetic stays in integers so the UI can never receive a float such as
    ``33.33333``. A partial mission is clamped to ``1..99``: the first completed
    step is visible as at least 1%, and the bar only reaches 100% once every
    step is complete. With ``total <= 100`` each completed step therefore moves
    the value by at least one percentage point.
    """
    if total <= 0:
        return 0
    if completed <= 0:
        return 1 if active else 0
    if completed >= total:
        return 100
    return max(1, min(99, (100 * completed) // total))


def _validate_step_graph(specs):
    """Reject cycles before a mission and its workspace are created."""
    dependencies = {spec["id"]: spec["depends_on"] for spec in specs}
    visiting, visited = set(), set()

    def visit(step_id):
        if step_id in visiting:
            raise ValueError("Step dependencies must form a DAG")
        if step_id in visited:
            return
        visiting.add(step_id)
        for dependency in dependencies[step_id]:
            visit(dependency)
        visiting.remove(step_id)
        visited.add(step_id)

    for key in dependencies:
        visit(key)


SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS missions (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, original_input TEXT NOT NULL,
 status TEXT NOT NULL, workspace TEXT NOT NULL, agent_id TEXT, model_id TEXT,
 created_at TEXT NOT NULL, professional_prompt TEXT,
 skill_id TEXT, runtime_id TEXT, owner_id TEXT NOT NULL DEFAULT 'admin'
);
CREATE TABLE IF NOT EXISTS steps (
 id TEXT NOT NULL, mission_id TEXT NOT NULL REFERENCES missions(id),
 label TEXT NOT NULL, position INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'WAITING',
 depends_on TEXT NOT NULL DEFAULT '[]',
 PRIMARY KEY (mission_id, id)
);
CREATE TABLE IF NOT EXISTS events (
 sequence INTEGER PRIMARY KEY AUTOINCREMENT,
 id TEXT NOT NULL UNIQUE, mission_id TEXT NOT NULL REFERENCES missions(id),
 step_id TEXT, session_id TEXT, agent_id TEXT, type TEXT NOT NULL,
 payload TEXT NOT NULL, occurred_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_by_mission ON events(mission_id, sequence);
CREATE TABLE IF NOT EXISTS sessions (
 id TEXT PRIMARY KEY, mission_id TEXT NOT NULL REFERENCES missions(id),
 agent_id TEXT NOT NULL, model_id TEXT, status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS artifacts (
 id TEXT PRIMARY KEY, mission_id TEXT NOT NULL REFERENCES missions(id),
 name TEXT NOT NULL, path TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS registries (
 kind TEXT NOT NULL, id TEXT NOT NULL, value TEXT NOT NULL,
 updated_at TEXT NOT NULL, owner_id TEXT NOT NULL DEFAULT 'admin',
 PRIMARY KEY (kind, id, owner_id)
);
CREATE TABLE IF NOT EXISTS checkpoints (
 id TEXT PRIMARY KEY, mission_id TEXT NOT NULL REFERENCES missions(id),
 commit_hash TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS costs (
 id TEXT PRIMARY KEY, mission_id TEXT NOT NULL REFERENCES missions(id),
 provider TEXT, model_id TEXT, amount REAL NOT NULL, tokens INTEGER,
 currency TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, mission_id TEXT NOT NULL REFERENCES missions(id),
 step_id TEXT, prompt TEXT NOT NULL, model_ref TEXT, status TEXT NOT NULL,
 priority INTEGER NOT NULL DEFAULT 0, attempts INTEGER NOT NULL DEFAULT 0,
 max_attempts INTEGER NOT NULL DEFAULT 1, timeout INTEGER NOT NULL DEFAULT 300,
 lease_owner TEXT, lease_expires_at TEXT, error TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS jobs_by_status ON jobs(status, priority, created_at);
CREATE TABLE IF NOT EXISTS auth_sessions (
 token_hash TEXT PRIMARY KEY, csrf_token TEXT NOT NULL, username TEXT NOT NULL,
 created_at TEXT NOT NULL, expires_at TEXT NOT NULL, last_seen_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS auth_sessions_expiry ON auth_sessions(expires_at);
CREATE TABLE IF NOT EXISTS login_attempts (
 client_ip TEXT PRIMARY KEY, failures INTEGER NOT NULL DEFAULT 0,
 first_at TEXT NOT NULL, last_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS channel_messages (
 id TEXT PRIMARY KEY, channel TEXT NOT NULL, direction TEXT NOT NULL,
 external_id TEXT, sender TEXT, recipient TEXT, kind TEXT NOT NULL,
 text TEXT NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL,
 mission_id TEXT, created_at TEXT NOT NULL, owner_id TEXT NOT NULL DEFAULT 'admin',
 conversion_owner TEXT, conversion_expires_at TEXT
);
CREATE INDEX IF NOT EXISTS channel_messages_lookup ON channel_messages(channel, created_at);
CREATE INDEX IF NOT EXISTS channel_messages_by_mission ON channel_messages(mission_id);
CREATE TABLE IF NOT EXISTS channel_events (
 sequence INTEGER PRIMARY KEY AUTOINCREMENT,
 id TEXT NOT NULL UNIQUE, channel TEXT NOT NULL, message_id TEXT NOT NULL,
 type TEXT NOT NULL, payload TEXT NOT NULL, occurred_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS channel_events_by_message ON channel_events(message_id, sequence);
CREATE TABLE IF NOT EXISTS n8n_deliveries (
 id TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE,
 mission_id TEXT, event_id TEXT, event_type TEXT NOT NULL,
 status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 max_attempts INTEGER NOT NULL DEFAULT 3, http_status INTEGER,
 error TEXT, retryable INTEGER NOT NULL DEFAULT 0,
 payload TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS n8n_deliveries_recent ON n8n_deliveries(created_at);
CREATE TABLE IF NOT EXISTS n8n_callbacks (
 request_id TEXT PRIMARY KEY, mission_id TEXT, status TEXT NOT NULL,
 detail TEXT NOT NULL, received_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS n8n_state (
 key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
);
"""


class Store:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.database = self.root / "facai.sqlite3"
        with self.connect() as db:
            db.executescript(SCHEMA)
            self._migrate(db)

    @staticmethod
    def _migrate(db):
        columns = {row[1] for row in db.execute("PRAGMA table_info(missions)")}
        for name in ("professional_prompt", "skill_id", "runtime_id"):
            if name not in columns:
                db.execute(f"ALTER TABLE missions ADD COLUMN {name} TEXT")
        if "owner_id" not in columns:
            db.execute("ALTER TABLE missions ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'admin'")
        # Preserve access to pre-tenant records for the configured legacy admin.
        import os
        legacy_owner = os.getenv("FACAI_ADMIN_USER", "admin")
        db.execute("UPDATE missions SET owner_id=? WHERE owner_id='admin'", (legacy_owner,))
        registry_columns = {row[1] for row in db.execute("PRAGMA table_info(registries)")}
        if "owner_id" not in registry_columns:
            # Recreate the table to update the PRIMARY KEY to (kind, id, owner_id)
            db.execute("ALTER TABLE registries RENAME TO registries_old")
            db.execute("""CREATE TABLE registries (
                kind TEXT NOT NULL, id TEXT NOT NULL, value TEXT NOT NULL,
                updated_at TEXT NOT NULL, owner_id TEXT NOT NULL DEFAULT 'admin',
                PRIMARY KEY (kind, id, owner_id)
            )""")
            db.execute("INSERT INTO registries (kind, id, value, updated_at, owner_id) "
                       "SELECT kind, id, value, updated_at, 'admin' FROM registries_old")
            db.execute("DROP TABLE registries_old")
        db.execute("UPDATE registries SET owner_id=? WHERE owner_id='admin'", (legacy_owner,))
        message_columns = {row[1] for row in db.execute("PRAGMA table_info(channel_messages)")}
        if "owner_id" not in message_columns:
            db.execute("ALTER TABLE channel_messages ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'admin'")
        db.execute("UPDATE channel_messages SET owner_id=? WHERE owner_id='admin'", (legacy_owner,))
        # Per-inbound-message conversion lease. These columns are added to
        # pre-existing databases so a duplicate webhook delivery races on an
        # atomic claim instead of both invoking the paid model.
        if "conversion_owner" not in message_columns:
            db.execute("ALTER TABLE channel_messages ADD COLUMN conversion_owner TEXT")
        if "conversion_expires_at" not in message_columns:
            db.execute("ALTER TABLE channel_messages ADD COLUMN conversion_expires_at TEXT")
        step_columns = {row[1] for row in db.execute("PRAGMA table_info(steps)")}
        if "depends_on" not in step_columns:
            db.execute("ALTER TABLE steps ADD COLUMN depends_on TEXT NOT NULL DEFAULT '[]'")
            missions = db.execute("SELECT id FROM missions").fetchall()
            for mission in missions:
                previous = None
                steps = db.execute("SELECT id FROM steps WHERE mission_id=? ORDER BY position",
                                   (mission["id"],)).fetchall()
                for row in steps:
                    deps = [previous] if previous else []
                    db.execute("UPDATE steps SET depends_on=? WHERE mission_id=? AND id=?",
                               (json.dumps(deps), mission["id"], row["id"]))
                    previous = row["id"]

    def registry_list(self, kind, owner_id=None):
        with self.connect() as db:
            if owner_id is None:
                rows = db.execute("SELECT id, value FROM registries WHERE kind=? ORDER BY id", (kind,))
            else:
                rows = db.execute("SELECT id, value FROM registries WHERE kind=? AND owner_id=? ORDER BY id", (kind, owner_id))
            return {row["id"]: json.loads(row["value"]) for row in rows}

    def registry_register(self, kind, key, value, owner_id="admin"):
        with self.connect() as db:
            db.execute("""INSERT INTO registries (kind, id, value, updated_at, owner_id) VALUES (?, ?, ?, ?, ?)
                       ON CONFLICT(kind, id, owner_id) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                       (kind, key, json.dumps(value, ensure_ascii=False), now(), owner_id))

    def connect(self):
        db = sqlite3.connect(self.database, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def create(self, title, original_input, labels, owner_id="admin"):
        specs = []
        legacy = all(isinstance(item, str) for item in labels)
        for item in labels:
            if isinstance(item, str):
                specs.append({"id": uuid4().hex, "label": item, "depends_on": []})
            elif isinstance(item, dict) and isinstance(item.get("label"), str):
                specs.append({"id": item.get("id") or uuid4().hex,
                              "label": item["label"], "depends_on": item.get("depends_on", [])})
            else:
                raise ValueError("Each step must be a label or an object with a label")
        labels_seen = [spec["label"] for spec in specs]
        ids_seen = [spec["id"] for spec in specs]
        if any(not label.strip() for label in labels_seen):
            raise ValueError("Step labels cannot be empty")
        if (not legacy and len(set(labels_seen)) != len(labels_seen)) or len(set(ids_seen)) != len(ids_seen):
            raise ValueError("Step labels and ids must be unique")
        if any(not isinstance(step_id, str) or not step_id for step_id in ids_seen):
            raise ValueError("Step ids must be non-empty strings")
        references = {spec["id"]: spec["id"] for spec in specs}
        references.update({spec["label"]: spec["id"] for spec in specs})
        for position, spec in enumerate(specs):
            raw_deps = spec["depends_on"]
            if not isinstance(raw_deps, list) or any(not isinstance(ref, str) for ref in raw_deps):
                raise ValueError("depends_on must be a list of step ids or labels")
            if legacy and position:
                raw_deps = [specs[position - 1]["id"]]
            deps = []
            for ref in raw_deps:
                if ref not in references:
                    raise ValueError(f"Unknown step dependency: {ref}")
                dep_id = references[ref]
                if dep_id == spec["id"]:
                    raise ValueError("A step cannot depend on itself")
                if dep_id not in deps:
                    deps.append(dep_id)
            spec["depends_on"] = deps
        _validate_step_graph(specs)
        mission_id = uuid4().hex
        workspace = (self.root / "workspaces" / mission_id).resolve()
        workspace.mkdir(parents=True, exist_ok=False)
        with self.connect() as db:
            db.execute("INSERT INTO missions (id, title, original_input, status, workspace, agent_id,"
                       " model_id, created_at, professional_prompt, owner_id)"
                       " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                       (mission_id, title, original_input, "WAITING", str(workspace), None, None,
                        now(), None, owner_id))
            for position, spec in enumerate(specs):
                db.execute("INSERT INTO steps (id, mission_id, label, position, status, depends_on)"
                           " VALUES (?, ?, ?, ?, 'WAITING', ?)",
                           (spec["id"], mission_id, spec["label"], position,
                            json.dumps(spec["depends_on"], ensure_ascii=False)))
            self._event(db, mission_id, None, None, None, "MISSION_CREATED", {"title": title})
        return self.get(mission_id)

    def list(self, owner_id=None):
        with self.connect() as db:
            if owner_id is None:
                ids = [row[0] for row in db.execute("SELECT id FROM missions ORDER BY created_at DESC")]
            else:
                ids = [row[0] for row in db.execute(
                    "SELECT id FROM missions WHERE owner_id=? ORDER BY created_at DESC", (owner_id,))]
        return [self.get(key) for key in ids]

    def get(self, mission_id, owner_id=None):
        with self.connect() as db:
            if owner_id is None:
                row = db.execute("SELECT * FROM missions WHERE id=?", (mission_id,)).fetchone()
            else:
                row = db.execute("SELECT * FROM missions WHERE id=? AND owner_id=?",
                                 (mission_id, owner_id)).fetchone()
            if row is None:
                return None
            steps = [dict(s) for s in db.execute(
                "SELECT id, label, position, status, depends_on FROM steps WHERE mission_id=? ORDER BY position", (mission_id,))]
            sessions = [dict(s) for s in db.execute("SELECT * FROM sessions WHERE mission_id=?", (mission_id,))]
            artifacts = [dict(a) for a in db.execute("SELECT * FROM artifacts WHERE mission_id=?", (mission_id,))]
            checkpoints = [dict(c) for c in db.execute(
                "SELECT * FROM checkpoints WHERE mission_id=? ORDER BY created_at", (mission_id,))]
            cost_total = db.execute("SELECT COALESCE(SUM(amount), 0) FROM costs WHERE mission_id=?",
                                    (mission_id,)).fetchone()[0]
        for step in steps:
            step["depends_on"] = json.loads(step["depends_on"])
            step["progress"] = 100 if step["status"] == "COMPLETED" else 1 if step["status"] in {"RUNNING", "FAILED"} else 0
        done = sum(step["status"] == "COMPLETED" for step in steps)
        active = sum(step["status"] == "RUNNING" for step in steps)
        return {**dict(row), "steps": steps, "sessions": sessions, "artifacts": artifacts,
                "checkpoints": checkpoints, "cost_total": cost_total,
                "progress": mission_progress(done, len(steps), active)}

    def _event(self, db, mission_id, step_id, session_id, agent_id, event_type, payload):
        event_id = uuid4().hex
        db.execute("INSERT INTO events (id, mission_id, step_id, session_id, agent_id, type, payload, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                   (event_id, mission_id, step_id, session_id, agent_id, event_type,
                    json.dumps(payload, ensure_ascii=False), now()))
        return event_id

    def append(self, mission_id, event_type, payload, step_id=None, session_id=None, agent_id=None):
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            if step_id and db.execute("SELECT 1 FROM steps WHERE mission_id=? AND id=?", (mission_id, step_id)).fetchone() is None:
                raise ValueError("Step belongs to another mission")
            if session_id and db.execute("SELECT 1 FROM sessions WHERE mission_id=? AND id=?", (mission_id, session_id)).fetchone() is None:
                raise ValueError("Session belongs to another mission")
            event_id = self._event(db, mission_id, step_id, session_id, agent_id, event_type, payload)
        return event_id

    def events(self, mission_id, after=0):
        with self.connect() as db:
            rows = db.execute("SELECT * FROM events WHERE mission_id=? AND sequence>? ORDER BY sequence", (mission_id, after))
            return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]

    def step_status(self, mission_id, step_id, status):
        if status not in {"WAITING", "RUNNING", "COMPLETED", "FAILED", "BLOCKED", "CANCELLED"}:
            raise ValueError("Invalid step status")
        with self.connect() as db:
            row = db.execute("SELECT status FROM steps WHERE mission_id=? AND id=?", (mission_id, step_id)).fetchone()
            if row is None:
                raise KeyError(step_id)
            allowed = {"WAITING": {"RUNNING", "BLOCKED", "CANCELLED"},
                       "RUNNING": {"COMPLETED", "FAILED"}, "FAILED": {"RUNNING"},
                       "BLOCKED": {"WAITING"}, "CANCELLED": {"WAITING"}, "COMPLETED": set()}
            if status == "RUNNING":
                dependencies = json.loads(db.execute(
                    "SELECT depends_on FROM steps WHERE mission_id=? AND id=?",
                    (mission_id, step_id)).fetchone()[0])
                if dependencies:
                    marks = ",".join("?" for _ in dependencies)
                    ready = db.execute(
                        f"SELECT COUNT(*) FROM steps WHERE mission_id=? AND id IN ({marks}) AND status='COMPLETED'",
                        (mission_id, *dependencies)).fetchone()[0]
                    if ready != len(dependencies):
                        raise ValueError("Step dependencies are not completed")
                if row["status"] == "FAILED":
                    self._unblock_descendants(db, mission_id, step_id)
            if status not in allowed[row["status"]]:
                raise ValueError(f"Invalid transition: {row['status']} -> {status}")
            db.execute("UPDATE steps SET status=? WHERE mission_id=? AND id=?", (status, mission_id, step_id))
            states = [r[0] for r in db.execute("SELECT status FROM steps WHERE mission_id=?", (mission_id,))]
            mission_status = "FAILED" if any(s in {"FAILED", "BLOCKED", "CANCELLED"} for s in states) else "COMPLETED" if all(s == "COMPLETED" for s in states) else "RUNNING"
            db.execute("UPDATE missions SET status=? WHERE id=?", (mission_status, mission_id))
            self._event(db, mission_id, step_id, None, None, f"STEP_{status}", {"status": status})
            if status in {"FAILED", "CANCELLED"}:
                self._refresh_blocked_jobs(db, mission_id)
        return self.get(mission_id)

    def _unblock_descendants(self, db, mission_id, step_id):
        """Re-open dependent steps when their failed prerequisite is retried."""
        rows = db.execute("SELECT id, status, depends_on FROM steps WHERE mission_id=?",
                          (mission_id,)).fetchall()
        dependencies = {row["id"]: json.loads(row["depends_on"]) for row in rows}
        blocked = {row["id"] for row in rows if row["status"] == "BLOCKED"}
        recovered = set()
        frontier = {step_id}
        while frontier:
            next_frontier = {candidate for candidate, deps in dependencies.items()
                             if candidate in blocked and candidate not in recovered
                             and any(dep in frontier for dep in deps)}
            if not next_frontier:
                break
            recovered.update(next_frontier)
            frontier = next_frontier
        for descendant in recovered:
            db.execute("UPDATE steps SET status='WAITING' WHERE mission_id=? AND id=?",
                       (mission_id, descendant))
            db.execute("UPDATE jobs SET status='QUEUED', error=NULL, updated_at=? "
                       "WHERE mission_id=? AND step_id=? AND status='BLOCKED'",
                       (now(), mission_id, descendant))
            self._event(db, mission_id, descendant, None, None, "STEP_UNBLOCKED",
                        {"status": "WAITING", "dependency_retry": step_id})

    def bind(self, mission_id, agent_id=None, model_id=None, skill_id=None, runtime_id=None,
             changed=None):
        """Bind any subset of the four capability registries to one mission.

        `changed` restricts which fields are written so agent, model, skill and
        runtime can be bound independently without clearing the others.
        """
        values = {"agent_id": agent_id, "model_id": model_id,
                  "skill_id": skill_id, "runtime_id": runtime_id}
        if changed is None:
            changed = set(values)
        updates = {key: values[key] for key in values if key in changed}
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            if updates:
                assignments = ", ".join(f"{key}=?" for key in updates)
                db.execute(f"UPDATE missions SET {assignments} WHERE id=?",
                           (*updates.values(), mission_id))
            row = db.execute("SELECT agent_id, model_id, skill_id, runtime_id FROM missions WHERE id=?",
                             (mission_id,)).fetchone()
            self._event(db, mission_id, None, None, row["agent_id"], "BINDING_CHANGED",
                        {"agent_id": row["agent_id"], "model_id": row["model_id"],
                         "skill_id": row["skill_id"], "runtime_id": row["runtime_id"],
                         "changed": sorted(updates)})
        return self.get(mission_id)

    def set_prompt(self, mission_id, professional_prompt):
        """Store the derived professional prompt. The original input is never modified.

        Each change records an audit event that keeps the exact original words
        next to the professional prompt, so the pairing can be reviewed later.
        """
        with self.connect() as db:
            row = db.execute("SELECT original_input FROM missions WHERE id=?", (mission_id,)).fetchone()
            if row is None:
                raise KeyError(mission_id)
            db.execute("UPDATE missions SET professional_prompt=? WHERE id=?", (professional_prompt, mission_id))
            self._event(db, mission_id, None, None, None, "PROMPT_UPDATED",
                        {"has_prompt": bool(professional_prompt),
                         "professional_prompt": professional_prompt,
                         "original_input": row["original_input"]})
        return self.get(mission_id)

    def start_session(self, mission_id, agent_id, model_id):
        session_id = uuid4().hex
        with self.connect() as db:
            db.execute("INSERT INTO sessions VALUES (?, ?, ?, ?, ?)",
                       (session_id, mission_id, agent_id, model_id, "PREPARED"))
            self._event(db, mission_id, None, session_id, agent_id, "SESSION_PREPARED", {"model_id": model_id})
        return session_id

    def session_status(self, mission_id, session_id, status):
        with self.connect() as db:
            row = db.execute("SELECT 1 FROM sessions WHERE mission_id=? AND id=?", (mission_id, session_id)).fetchone()
            if row is None:
                raise KeyError(session_id)
            db.execute("UPDATE sessions SET status=? WHERE mission_id=? AND id=?", (status, mission_id, session_id))
            self._event(db, mission_id, None, session_id, None, f"SESSION_{status}", {"status": status})

    def add_artifact(self, mission_id, name, path):
        if (self.root / "workspaces").resolve() not in Path(path).resolve().parents:
            raise ValueError("Artifact must live inside the mission workspace tree")
        artifact_id = uuid4().hex
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            db.execute("INSERT INTO artifacts VALUES (?, ?, ?, ?, ?)",
                       (artifact_id, mission_id, name, str(path), now()))
            self._event(db, mission_id, None, None, None, "ARTIFACT_CREATED",
                        {"name": name, "artifact_id": artifact_id})
        return artifact_id

    def get_artifact(self, mission_id, artifact_id):
        with self.connect() as db:
            row = db.execute("SELECT * FROM artifacts WHERE mission_id=? AND id=?",
                             (mission_id, artifact_id)).fetchone()
        return dict(row) if row else None

    def add_checkpoint(self, mission_id, commit_hash, message, stat=""):
        checkpoint_id = uuid4().hex
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            db.execute("INSERT INTO checkpoints VALUES (?, ?, ?, ?, ?)",
                       (checkpoint_id, mission_id, commit_hash, message, now()))
            self._event(db, mission_id, None, None, None, "GIT_CHECKPOINT",
                        {"commit_hash": commit_hash, "message": message, "stat": stat})
        return checkpoint_id

    def add_cost(self, mission_id, provider, model_id, amount, tokens=None, currency="USD"):
        if amount <= 0 and not tokens:
            return None
        cost_id = uuid4().hex
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            db.execute("INSERT INTO costs VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                       (cost_id, mission_id, provider, model_id, float(amount),
                        tokens, currency, now()))
            self._event(db, mission_id, None, None, None, "COST_RECORDED",
                        {"provider": provider, "model_id": model_id, "amount": float(amount),
                         "tokens": tokens, "currency": currency})
        return cost_id

    # --- durable scheduler jobs -------------------------------------------------

    def enqueue_job(self, mission_id, prompt, step_id=None, model_ref=None,
                    priority=0, max_attempts=1, timeout=300, dispatch=None):
        job_id = uuid4().hex
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            if step_id and db.execute("SELECT 1 FROM steps WHERE mission_id=? AND id=?",
                                      (mission_id, step_id)).fetchone() is None:
                raise ValueError("Step belongs to another mission")
            db.execute(
                "INSERT INTO jobs (id, mission_id, step_id, prompt, model_ref, status, priority,"
                " attempts, max_attempts, timeout, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, 'QUEUED', ?, 0, ?, ?, ?, ?)",
                (job_id, mission_id, step_id, prompt, model_ref, int(priority),
                 int(max_attempts), int(timeout), now(), now()))
            self._event(db, mission_id, step_id, None, None, "JOB_QUEUED",
                        {"job_id": job_id, "priority": int(priority)})
            if dispatch is not None:
                self._event(db, mission_id, step_id, None, None, "DISPATCH_QUEUED",
                            {"job_id": job_id, **dispatch})
        return self.get_job(job_id)

    @staticmethod
    def _job_row(db, job_id, owner_id=None):
        """Fetch one job, optionally constrained to its owning tenant.

        Jobs are looked up by a globally unique id, so a bare id lookup would let
        one user read or mutate another user's job by guessing its id. When an
        owner is supplied the row must belong to a mission owned by that user.
        """
        if owner_id is None:
            return db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return db.execute(
            "SELECT j.* FROM jobs AS j JOIN missions AS m ON m.id = j.mission_id"
            " WHERE j.id=? AND m.owner_id=?", (job_id, owner_id)).fetchone()

    def get_job(self, job_id, owner_id=None):
        with self.connect() as db:
            row = self._job_row(db, job_id, owner_id)
        return dict(row) if row else None

    def jobs(self, mission_id=None, owner_id=None):
        with self.connect() as db:
            if mission_id:
                if owner_id is None:
                    rows = db.execute(
                        "SELECT * FROM jobs WHERE mission_id=? ORDER BY priority DESC, created_at",
                        (mission_id,))
                else:
                    rows = db.execute(
                        "SELECT j.* FROM jobs AS j JOIN missions AS m ON m.id = j.mission_id"
                        " WHERE j.mission_id=? AND m.owner_id=?"
                        " ORDER BY j.priority DESC, j.created_at", (mission_id, owner_id))
            else:
                rows = db.execute("SELECT * FROM jobs ORDER BY created_at DESC")
            return [dict(row) for row in rows]

    def count_running_jobs(self):
        with self.connect() as db:
            return db.execute("SELECT COUNT(*) FROM jobs WHERE status='RUNNING'").fetchone()[0]

    def _refresh_blocked_jobs(self, db, mission_id):
        """Block queued work whose prerequisites have irrecoverably failed."""
        changed = True
        while changed:
            changed = False
            steps = {row["id"]: {**dict(row), "depends_on": json.loads(row["depends_on"])}
                     for row in db.execute("SELECT id, status, depends_on FROM steps WHERE mission_id=?",
                                           (mission_id,))}
            for step_id, step in steps.items():
                if step["status"] != "WAITING":
                    continue
                failed_dependency = next((steps[dep] for dep in step["depends_on"]
                                          if steps[dep]["status"] in {"FAILED", "CANCELLED", "BLOCKED"}), None)
                if failed_dependency is None:
                    continue
                if failed_dependency["status"] == "FAILED":
                    recoverable = db.execute(
                        "SELECT 1 FROM jobs WHERE mission_id=? AND step_id=? AND ("
                        "status IN ('QUEUED','RUNNING','PAUSED') OR "
                        "(status='FAILED' AND attempts < max_attempts)) LIMIT 1",
                        (mission_id, failed_dependency["id"])).fetchone()
                    if recoverable:
                        continue
                db.execute("UPDATE steps SET status='BLOCKED' WHERE mission_id=? AND id=?",
                           (mission_id, step_id))
                self._event(db, mission_id, step_id, None, None, "STEP_BLOCKED",
                            {"status": "BLOCKED", "dependency": failed_dependency["id"]})
                steps[step_id]["status"] = "BLOCKED"
                changed = True
            blocked_jobs = db.execute(
                "SELECT * FROM jobs WHERE mission_id=? AND status='QUEUED' AND step_id IN "
                "(SELECT id FROM steps WHERE mission_id=? AND status='BLOCKED')",
                (mission_id, mission_id)).fetchall()
            for job in blocked_jobs:
                db.execute("UPDATE jobs SET status='BLOCKED', error='dependency failed or cancelled', updated_at=? WHERE id=?",
                           (now(), job["id"]))
                self._event(db, mission_id, job["step_id"], None, None, "JOB_BLOCKED",
                            {"job_id": job["id"], "reason": "dependency failed or cancelled"})
                changed = True
        states = [row[0] for row in db.execute("SELECT status FROM steps WHERE mission_id=?", (mission_id,))]
        current_status = db.execute("SELECT status FROM missions WHERE id=?", (mission_id,)).fetchone()[0]
        mission_status = ("FAILED" if any(s in {"FAILED", "BLOCKED", "CANCELLED"} for s in states)
                          else "COMPLETED" if states and all(s == "COMPLETED" for s in states)
                          else "RUNNING" if "RUNNING" in states else current_status)
        db.execute("UPDATE missions SET status=? WHERE id=?", (mission_status, mission_id))

    def claim_job(self, worker_id, lease_seconds):
        with self.connect() as db:
            # Serialize claim decisions across scheduler threads/processes, and
            # never run two writers in the same mission workspace at once.
            db.execute("BEGIN IMMEDIATE")
            missions = [row[0] for row in db.execute(
                "SELECT DISTINCT mission_id FROM jobs WHERE status='QUEUED'")]
            for mission_id in missions:
                self._refresh_blocked_jobs(db, mission_id)
            candidates = db.execute(
                "SELECT j.* FROM jobs AS j WHERE j.status='QUEUED' AND NOT EXISTS ("
                "SELECT 1 FROM jobs AS active WHERE active.mission_id=j.mission_id "
                "AND active.status='RUNNING') ORDER BY j.priority DESC, j.created_at").fetchall()
            row = None
            for candidate in candidates:
                if candidate["step_id"] is None:
                    row = candidate
                    break
                step = db.execute("SELECT depends_on FROM steps WHERE mission_id=? AND id=?",
                                  (candidate["mission_id"], candidate["step_id"])).fetchone()
                dependencies = json.loads(step["depends_on"])
                if not dependencies:
                    row = candidate
                    break
                marks = ",".join("?" for _ in dependencies)
                ready = db.execute(
                    f"SELECT COUNT(*) FROM steps WHERE mission_id=? AND id IN ({marks}) AND status='COMPLETED'",
                    (candidate["mission_id"], *dependencies)).fetchone()[0]
                if ready == len(dependencies):
                    row = candidate
                    break
            if row is None:
                return None
            expires = (datetime.now(timezone.utc) + timedelta(seconds=lease_seconds)).isoformat()
            cursor = db.execute(
                "UPDATE jobs SET status='RUNNING', lease_owner=?, lease_expires_at=?,"
                " attempts=attempts+1, updated_at=? WHERE id=? AND status='QUEUED'",
                (worker_id, expires, now(), row["id"]))
            if cursor.rowcount != 1:
                return None
            self._event(db, row["mission_id"], row["step_id"], None, None, "JOB_STARTED",
                        {"job_id": row["id"], "worker": worker_id, "attempt": row["attempts"] + 1})
            claimed = db.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone()
        return dict(claimed)

    def finish_job(self, job_id, status, error=None):
        if status not in {"COMPLETED", "FAILED"}:
            raise ValueError("Job can only finish as COMPLETED or FAILED")
        with self.connect() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            if row is None:
                raise KeyError(job_id)
            db.execute("UPDATE jobs SET status=?, error=?, lease_owner=NULL, lease_expires_at=NULL,"
                       " updated_at=? WHERE id=?", (status, error, now(), job_id))
            if status == "FAILED" and row["step_id"]:
                step = db.execute("SELECT status FROM steps WHERE mission_id=? AND id=?",
                                  (row["mission_id"], row["step_id"])).fetchone()
                if step and step["status"] in {"WAITING", "RUNNING"}:
                    db.execute("UPDATE steps SET status='FAILED' WHERE mission_id=? AND id=?",
                               (row["mission_id"], row["step_id"]))
                    self._event(db, row["mission_id"], row["step_id"], None, None, "STEP_FAILED",
                                {"status": "FAILED", "error": error})
            self._event(db, row["mission_id"], row["step_id"], None, None,
                        "JOB_COMPLETED" if status == "COMPLETED" else "JOB_FAILED",
                        {"job_id": job_id, "error": error})
            if status == "FAILED" and row["attempts"] >= row["max_attempts"]:
                self._refresh_blocked_jobs(db, row["mission_id"])
        return self.get_job(job_id)

    def _set_job_status(self, job_id, allowed, new_status, event_type, error=None, owner_id=None):
        with self.connect() as db:
            row = self._job_row(db, job_id, owner_id)
            if row is None:
                raise KeyError(job_id)
            if row["status"] not in allowed:
                raise ValueError(f"Invalid job transition: {row['status']} -> {new_status}")
            db.execute("UPDATE jobs SET status=?, error=?, lease_owner=NULL, lease_expires_at=NULL,"
                       " updated_at=? WHERE id=?", (new_status, error, now(), job_id))
            self._event(db, row["mission_id"], row["step_id"], None, None, event_type, {"job_id": job_id})
        return self.get_job(job_id, owner_id=owner_id)

    def pause_job(self, job_id, owner_id=None):
        return self._set_job_status(job_id, {"QUEUED"}, "PAUSED", "JOB_PAUSED", owner_id=owner_id)

    def resume_job(self, job_id, owner_id=None):
        return self._set_job_status(job_id, {"PAUSED"}, "QUEUED", "JOB_RESUMED", owner_id=owner_id)

    def cancel_job(self, job_id, owner_id=None):
        with self.connect() as db:
            row = self._job_row(db, job_id, owner_id)
            if row is None:
                raise KeyError(job_id)
            if row["status"] not in {"QUEUED", "PAUSED"}:
                raise ValueError(f"Invalid job transition: {row['status']} -> CANCELLED")
            db.execute("UPDATE jobs SET status='CANCELLED', lease_owner=NULL, lease_expires_at=NULL, updated_at=? WHERE id=?",
                       (now(), job_id))
            if row["step_id"]:
                step = db.execute("SELECT status FROM steps WHERE mission_id=? AND id=?",
                                  (row["mission_id"], row["step_id"])).fetchone()
                if step and step["status"] == "WAITING":
                    db.execute("UPDATE steps SET status='CANCELLED' WHERE mission_id=? AND id=?",
                               (row["mission_id"], row["step_id"]))
                    self._event(db, row["mission_id"], row["step_id"], None, None, "STEP_CANCELLED",
                                {"status": "CANCELLED"})
            self._event(db, row["mission_id"], row["step_id"], None, None, "JOB_CANCELLED", {"job_id": job_id})
            self._refresh_blocked_jobs(db, row["mission_id"])
        return self.get_job(job_id, owner_id=owner_id)

    def retry_job(self, job_id, owner_id=None):
        with self.connect() as db:
            row = self._job_row(db, job_id, owner_id)
            if row is None:
                raise KeyError(job_id)
            if row["status"] not in {"FAILED", "CANCELLED"}:
                raise ValueError("Only failed or cancelled jobs can be retried")
            db.execute("UPDATE jobs SET status='QUEUED', attempts=0, error=NULL, lease_owner=NULL,"
                       " lease_expires_at=NULL, updated_at=? WHERE id=?", (now(), job_id))
            self._event(db, row["mission_id"], row["step_id"], None, None, "JOB_RETRIED", {"job_id": job_id})
            if row["step_id"]:
                db.execute("UPDATE steps SET status='WAITING' WHERE mission_id=? AND id=? AND status IN ('FAILED','CANCELLED')",
                           (row["mission_id"], row["step_id"]))
            # Downstream work may become ready again after this retry; retain the
            # dependency gate until its prerequisite actually completes.
            blocked_jobs = db.execute("SELECT id, step_id FROM jobs WHERE mission_id=? AND status='BLOCKED'",
                                      (row["mission_id"],)).fetchall()
            for blocked in blocked_jobs:
                db.execute("UPDATE jobs SET status='QUEUED', error=NULL, updated_at=? WHERE id=?",
                           (now(), blocked["id"]))
                if blocked["step_id"]:
                    db.execute("UPDATE steps SET status='WAITING' WHERE mission_id=? AND id=? AND status='BLOCKED'",
                               (row["mission_id"], blocked["step_id"]))
            db.execute("UPDATE missions SET status='RUNNING' WHERE id=?", (row["mission_id"],))
        return self.get_job(job_id, owner_id=owner_id)

    # --- admin authentication sessions -----------------------------------------

    def create_auth_session(self, token_hash, csrf_token, username, ttl_seconds):
        expires = (datetime.now(timezone.utc) + timedelta(seconds=int(ttl_seconds))).isoformat()
        with self.connect() as db:
            db.execute("INSERT INTO auth_sessions (token_hash, csrf_token, username, created_at,"
                       " expires_at, last_seen_at) VALUES (?, ?, ?, ?, ?, ?)",
                       (token_hash, csrf_token, username, now(), expires, now()))
        return expires

    def get_auth_session(self, token_hash):
        with self.connect() as db:
            row = db.execute("SELECT * FROM auth_sessions WHERE token_hash=?", (token_hash,)).fetchone()
        return dict(row) if row else None

    def touch_auth_session(self, token_hash):
        with self.connect() as db:
            db.execute("UPDATE auth_sessions SET last_seen_at=? WHERE token_hash=?", (now(), token_hash))

    def delete_auth_session(self, token_hash):
        with self.connect() as db:
            db.execute("DELETE FROM auth_sessions WHERE token_hash=?", (token_hash,))

    def delete_user_auth_sessions(self, username):
        with self.connect() as db:
            db.execute("DELETE FROM auth_sessions WHERE username=?", (username,))

    def prune_auth_sessions(self):
        with self.connect() as db:
            cursor = db.execute("DELETE FROM auth_sessions WHERE expires_at < ?", (now(),))
            return cursor.rowcount

    def record_login_failure(self, client_ip, window_seconds):
        """Count a failed login inside a sliding window; reset the count when stale."""
        with self.connect() as db:
            row = db.execute("SELECT * FROM login_attempts WHERE client_ip=?", (client_ip,)).fetchone()
            timestamp = now()
            if row is None:
                db.execute("INSERT INTO login_attempts VALUES (?, 1, ?, ?)", (client_ip, timestamp, timestamp))
                return 1
            stale = row["last_at"] < (datetime.now(timezone.utc) - timedelta(seconds=window_seconds)).isoformat()
            failures = 1 if stale else row["failures"] + 1
            first = timestamp if stale else row["first_at"]
            db.execute("UPDATE login_attempts SET failures=?, first_at=?, last_at=? WHERE client_ip=?",
                       (failures, first, timestamp, client_ip))
            return failures

    def login_failures(self, client_ip):
        with self.connect() as db:
            row = db.execute("SELECT failures FROM login_attempts WHERE client_ip=?", (client_ip,)).fetchone()
        return row["failures"] if row else 0

    def clear_login_failures(self, client_ip):
        with self.connect() as db:
            db.execute("DELETE FROM login_attempts WHERE client_ip=?", (client_ip,))

    # --- message channel audit ------------------------------------------------

    def record_channel_message(self, channel, direction, status, *, external_id=None,
                               sender=None, recipient=None, kind="text", text="",
                               payload=None, mission_id=None, owner_id="admin"):
        """Audit one inbound or outbound channel message (never a credential)."""
        if direction not in {"INBOUND", "OUTBOUND"}:
            raise ValueError("Direction must be INBOUND or OUTBOUND")
        message_id = uuid4().hex
        with self.connect() as db:
            if direction == "INBOUND" and external_id:
                # Serialize check/insert across concurrent webhook deliveries.
                # Preserve legacy audit rows instead of deleting duplicates.
                db.execute("BEGIN IMMEDIATE")
                duplicate = db.execute(
                    "SELECT id FROM channel_messages WHERE channel=? AND direction='INBOUND'"
                    " AND external_id=? LIMIT 1", (channel, external_id)).fetchone()
                if duplicate:
                    return None
            db.execute(
                "INSERT INTO channel_messages (id, channel, direction, external_id, sender,"
                " recipient, kind, text, status, payload, mission_id, created_at, owner_id)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (message_id, channel, direction, external_id, sender, recipient, kind,
                 text, status, json.dumps(payload or {}, ensure_ascii=False),
                 mission_id, now(), owner_id))
        return message_id

    def channel_messages(self, channel=None, limit=100, owner_id=None):
        limit = max(1, min(int(limit), 500))
        with self.connect() as db:
            if channel and owner_id is not None:
                rows = db.execute(
                    "SELECT * FROM channel_messages WHERE channel=? AND owner_id=? ORDER BY created_at DESC LIMIT ?",
                    (channel, owner_id, limit))
            elif channel:
                rows = db.execute(
                    "SELECT * FROM channel_messages WHERE channel=? ORDER BY created_at DESC LIMIT ?",
                    (channel, limit))
            elif owner_id is not None:
                rows = db.execute(
                    "SELECT * FROM channel_messages WHERE owner_id=? ORDER BY created_at DESC LIMIT ?",
                    (owner_id, limit))
            else:
                rows = db.execute(
                    "SELECT * FROM channel_messages ORDER BY created_at DESC LIMIT ?", (limit,))
            return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]

    def channel_message(self, message_id, owner_id=None):
        with self.connect() as db:
            if owner_id is None:
                row = db.execute("SELECT * FROM channel_messages WHERE id=?", (message_id,)).fetchone()
            else:
                row = db.execute("SELECT * FROM channel_messages WHERE id=? AND owner_id=?",
                                 (message_id, owner_id)).fetchone()
        return {**dict(row), "payload": json.loads(row["payload"])} if row else None

    def channel_message_by_external_id(self, channel, external_id):
        """Find an inbound delivery after an idempotent webhook insert conflict."""
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM channel_messages WHERE channel=? AND direction='INBOUND'"
                " AND external_id=? ORDER BY created_at LIMIT 1", (channel, external_id)).fetchone()
        return {**dict(row), "payload": json.loads(row["payload"])} if row else None

    def pending_inbound_messages(self, channel, limit=100):
        """Inbound messages of one channel still awaiting conversion/dispatch.

        Only ``RECEIVED``/``RETRY`` messages with no linked mission are returned,
        oldest first. ``CONVERSION_FAILED`` rows are intentionally excluded so a
        blank or malformed message is never retried forever, and a message that
        already owns a mission is never replayed into a second one.
        """
        limit = max(1, min(int(limit), 500))
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM channel_messages WHERE channel=? AND direction='INBOUND'"
                " AND status IN ('RECEIVED', 'RETRY') AND mission_id IS NULL"
                " ORDER BY created_at, id LIMIT ?", (channel, limit)).fetchall()
        return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]
    def deferred_channel_messages(self, channels, limit=500):
        """Inbound messages whose linked mission has no queued/running jobs.

        These messages were persisted and converted to a mission, but their
        dispatch was deferred because no valid agent/model/runtime binding
        existed at the time.  The LEFT JOIN excludes missions that already
        have at least one job row, so a message is returned at most once
        per call and `ensure_channel_dispatch` will never duplicate a job.
        """
        limit = max(1, min(int(limit), 500))
        placeholders = ",".join("?" * len(channels))
        with self.connect() as db:
            rows = db.execute(
                f"SELECT cm.* FROM channel_messages cm "
                f"LEFT JOIN jobs j ON j.mission_id = cm.mission_id "
                f"WHERE cm.direction='INBOUND' AND cm.mission_id IS NOT NULL "
                f"AND cm.channel IN ({placeholders}) "
                f"AND j.id IS NULL "
                f"ORDER BY cm.created_at, cm.id LIMIT ?",
                (*channels, limit)).fetchall()
        return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]


    def messages_for_mission(self, mission_id):
        """Return the channel messages linked to a mission, oldest first."""
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM channel_messages WHERE mission_id=? ORDER BY created_at",
                (mission_id,))
            return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]

    def set_channel_message_status(self, message_id, status):
        with self.connect() as db:
            updated = db.execute("UPDATE channel_messages SET status=? WHERE id=?",
                                 (status, message_id)).rowcount
        if not updated:
            raise KeyError(message_id)
        return status

    def claim_channel_conversion(self, message_id, lease_seconds=300, owner=None):
        """Atomically claim the one-time prompt conversion of an inbound message.

        Duplicate webhook deliveries of the same message must not each invoke the
        paid conversion model. The claim is a durable lease stored on the audit
        row: ``BEGIN IMMEDIATE`` serializes contenders so exactly one caller gets
        ``claimed=True`` and may convert, while every duplicate receives the live
        row with ``reason='IN_PROGRESS'``. A claim whose owner crashed is taken
        over once ``lease_seconds`` elapse (``reason=None``), so a message can
        never be stranded by a dead worker. Rows that already own a mission are
        never claimable.
        """
        owner = owner or uuid4().hex
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM channel_messages WHERE id=?", (message_id,)).fetchone()
            if row is None or row["direction"] != "INBOUND":
                return {"claimed": False, "reason": "NOT_FOUND", "owner": None, "row": None}
            if row["mission_id"]:
                return {"claimed": False, "reason": "ALREADY_LINKED", "owner": None,
                        "row": {**dict(row), "payload": json.loads(row["payload"])}}
            if row["conversion_owner"] and row["conversion_expires_at"] \
                    and row["conversion_expires_at"] >= now():
                return {"claimed": False, "reason": "IN_PROGRESS", "owner": None,
                        "row": {**dict(row), "payload": json.loads(row["payload"])}}
            expires = (datetime.now(timezone.utc)
                       + timedelta(seconds=lease_seconds)).isoformat()
            cursor = db.execute(
                "UPDATE channel_messages SET status='CONVERTING', conversion_owner=?,"
                " conversion_expires_at=? WHERE id=? AND mission_id IS NULL"
                " AND (conversion_expires_at IS NULL OR conversion_expires_at < ?)",
                (owner, expires, message_id, now()))
            current = db.execute("SELECT * FROM channel_messages WHERE id=?",
                                 (message_id,)).fetchone()
            if cursor.rowcount != 1:
                return {"claimed": False, "reason": "IN_PROGRESS", "owner": None,
                        "row": {**dict(current), "payload": json.loads(current["payload"])}}
            return {"claimed": True, "reason": None, "owner": owner,
                    "row": {**dict(current), "payload": json.loads(current["payload"])}}

    def release_channel_conversion(self, message_id, owner, status="RETRY"):
        """Release a conversion lease without touching a completed mission link."""
        with self.connect() as db:
            updated = db.execute(
                "UPDATE channel_messages SET status=?, conversion_owner=NULL,"
                " conversion_expires_at=NULL WHERE id=? AND conversion_owner=?",
                (status, message_id, owner)).rowcount
        return bool(updated)

    def recover_stale_channel_conversions(self):
        """Return crashed conversion claims to the replayable RETRY pool.

        Bounded by the claim lease: only rows whose lease has already expired are
        reset. A message that linked a mission in the meantime is left alone, and
        a live claim is never disturbed, so recovery cannot duplicate a mission.
        """
        with self.connect() as db:
            cursor = db.execute(
                "UPDATE channel_messages SET status='RETRY', conversion_owner=NULL,"
                " conversion_expires_at=NULL WHERE direction='INBOUND'"
                " AND mission_id IS NULL AND conversion_owner IS NOT NULL"
                " AND conversion_expires_at IS NOT NULL AND conversion_expires_at < ?",
                (now(),))
            return cursor.rowcount

    def create_mission_from_message(self, message_id, channel, *, title, original_input,
                                    labels, professional_prompt, conversion_payload, owner_id=None):
        """Atomically convert one inbound message into a linked mission.

        The check and the insert run inside a single ``BEGIN IMMEDIATE``
        transaction, so two concurrent dispatches of the same message can never
        create two missions: the loser rolls back, removes its unused workspace
        directory and receives the winner's mission id. The message row is never
        deleted or overwritten - only its ``mission_id``/``status`` change.
        """
        mission_id = uuid4().hex
        workspace = (self.root / "workspaces" / mission_id).resolve()
        workspace.mkdir(parents=True, exist_ok=False)
        claimed = False
        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                row = db.execute("SELECT * FROM channel_messages WHERE id=?",
                                 (message_id,)).fetchone()
                if row is None or row["channel"] != channel or row["direction"] != "INBOUND":
                    db.execute("ROLLBACK")
                    return None, False
                if row["mission_id"]:
                    db.execute("ROLLBACK")
                    return row["mission_id"], False
                target_owner = owner_id or row["owner_id"]
                db.execute(
                    "INSERT INTO missions (id, title, original_input, status, workspace, agent_id,"
                    " model_id, created_at, professional_prompt, owner_id)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (mission_id, title, original_input, "WAITING", str(workspace), None, None,
                     now(), professional_prompt, target_owner))
                for position, label in enumerate(labels):
                    db.execute("INSERT INTO steps (id, mission_id, label, position, status) VALUES (?, ?, ?, ?, ?)",
                               (uuid4().hex, mission_id, label, position, "WAITING"))
                self._event(db, mission_id, None, None, None, "MISSION_CREATED",
                            {"title": title, "channel": channel, "message_id": message_id})
                self._event(db, mission_id, None, None, None, "PROMPT_CONVERTED",
                            conversion_payload)
                db.execute(
                    "UPDATE channel_messages SET mission_id=?, status='DISPATCHED',"
                    " conversion_owner=NULL, conversion_expires_at=NULL WHERE id=?",
                    (mission_id, message_id))
                claimed = True
            return mission_id, True
        finally:
            if not claimed:
                try:
                    workspace.rmdir()
                except OSError:
                    pass

    def attach_channel_mission(self, message_id, mission_id):
        with self.connect() as db:
            if db.execute("SELECT 1 FROM missions WHERE id=?", (mission_id,)).fetchone() is None:
                raise KeyError(mission_id)
            updated = db.execute(
                "UPDATE channel_messages SET mission_id=?, status='DISPATCHED'"
                " WHERE id=? AND direction='INBOUND'", (mission_id, message_id)).rowcount
        if not updated:
            raise KeyError(message_id)
        return self.channel_messages(limit=500)

    # --- message-scoped audit events ------------------------------------------

    def record_channel_event(self, channel, message_id, event_type, payload=None):
        """Append one message-level event, even when no mission exists yet."""
        event_id = uuid4().hex
        with self.connect() as db:
            db.execute(
                "INSERT INTO channel_events (id, channel, message_id, type, payload, occurred_at)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (event_id, channel, message_id, event_type,
                 json.dumps(payload or {}, ensure_ascii=False), now()))
        return event_id

    def channel_events(self, message_id=None, channel=None, after=0, limit=500):
        limit = max(1, min(int(limit), 500))
        clauses, params = ["sequence > ?"], [int(after)]
        if message_id:
            clauses.append("message_id = ?")
            params.append(message_id)
        if channel:
            clauses.append("channel = ?")
            params.append(channel)
        with self.connect() as db:
            rows = db.execute(
                f"SELECT * FROM channel_events WHERE {' AND '.join(clauses)}"
                " ORDER BY sequence LIMIT ?", (*params, limit))
            return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]

    # --- n8n integration audit -------------------------------------------------

    def last_event_sequence(self):
        with self.connect() as db:
            return db.execute("SELECT COALESCE(MAX(sequence), 0) FROM events").fetchone()[0]

    def n8n_events_after(self, sequence, limit=50):
        limit = max(1, min(int(limit), 500))
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM events WHERE sequence>? ORDER BY sequence LIMIT ?",
                (int(sequence), limit))
            return [{**dict(row), "payload": json.loads(row["payload"])} for row in rows]

    def n8n_get_state(self, key, default=None):
        with self.connect() as db:
            row = db.execute("SELECT value FROM n8n_state WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def n8n_set_state(self, key, value):
        with self.connect() as db:
            db.execute(
                "INSERT INTO n8n_state (key, value, updated_at) VALUES (?, ?, ?)"
                " ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (key, str(value), now()))

    def n8n_cursor(self):
        value = self.n8n_get_state("event_cursor")
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def n8n_set_cursor(self, sequence):
        self.n8n_set_state("event_cursor", int(sequence))

    @staticmethod
    def _n8n_delivery_row(row):
        if row is None:
            return None
        data = dict(row)
        data["payload"] = json.loads(data["payload"])
        data["retryable"] = bool(data["retryable"])
        return data

    def create_n8n_delivery(self, request_id, mission_id, event_id, event_type,
                            payload, max_attempts=3):
        """Insert one delivery row, or return the existing row for that request.

        The unique ``request_id`` makes the delivery idempotent across a retry or
        a process restart: the same event is never recorded twice.
        """
        delivery_id = uuid4().hex
        with self.connect() as db:
            db.execute(
                "INSERT OR IGNORE INTO n8n_deliveries (id, request_id, mission_id, event_id,"
                " event_type, status, attempts, max_attempts, retryable, payload, created_at,"
                " updated_at) VALUES (?, ?, ?, ?, ?, 'PENDING', 0, ?, 1, ?, ?, ?)",
                (delivery_id, request_id, mission_id, event_id, event_type,
                 int(max_attempts), json.dumps(payload, ensure_ascii=False), now(), now()))
            row = db.execute("SELECT * FROM n8n_deliveries WHERE request_id=?",
                             (request_id,)).fetchone()
        return self._n8n_delivery_row(row)

    def get_n8n_delivery(self, delivery_id):
        with self.connect() as db:
            row = db.execute("SELECT * FROM n8n_deliveries WHERE id=?", (delivery_id,)).fetchone()
        return self._n8n_delivery_row(row)

    def record_n8n_delivery_result(self, delivery_id, status, http_status=None,
                                   error=None, retryable=False):
        with self.connect() as db:
            if db.execute("SELECT 1 FROM n8n_deliveries WHERE id=?", (delivery_id,)).fetchone() is None:
                raise KeyError(delivery_id)
            db.execute(
                "UPDATE n8n_deliveries SET status=?, attempts=attempts+1, http_status=?,"
                " error=?, retryable=?, updated_at=? WHERE id=?",
                (status, http_status, error, 1 if retryable else 0, now(), delivery_id))
            row = db.execute("SELECT * FROM n8n_deliveries WHERE id=?", (delivery_id,)).fetchone()
        return self._n8n_delivery_row(row)

    def n8n_retryable_deliveries(self, limit=50):
        limit = max(1, min(int(limit), 500))
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM n8n_deliveries WHERE status IN ('PENDING', 'FAILED')"
                " AND retryable=1 AND attempts < max_attempts ORDER BY created_at, id LIMIT ?",
                (limit,)).fetchall()
        return [self._n8n_delivery_row(row) for row in rows]

    def n8n_deliveries(self, limit=20):
        limit = max(1, min(int(limit), 200))
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM n8n_deliveries ORDER BY created_at DESC, id LIMIT ?",
                (limit,)).fetchall()
        return [self._n8n_delivery_row(row) for row in rows]

    def n8n_delivery_summary(self):
        with self.connect() as db:
            rows = db.execute(
                "SELECT status, COUNT(*) AS n FROM n8n_deliveries GROUP BY status").fetchall()
        return {row["status"]: row["n"] for row in rows}

    def claim_n8n_callback(self, request_id, mission_id, status, detail):
        """Claim an inbound callback exactly once. Returns (claimed, existing)."""
        with self.connect() as db:
            cursor = db.execute(
                "INSERT OR IGNORE INTO n8n_callbacks (request_id, mission_id, status, detail,"
                " received_at) VALUES (?, ?, ?, ?, ?)",
                (request_id, mission_id, status, detail, now()))
            if cursor.rowcount == 0:
                row = db.execute("SELECT * FROM n8n_callbacks WHERE request_id=?",
                                 (request_id,)).fetchone()
                return False, dict(row)
            return True, None

    def finish_n8n_callback(self, request_id, status, detail):
        with self.connect() as db:
            db.execute("UPDATE n8n_callbacks SET status=?, detail=? WHERE request_id=?",
                       (status, detail, request_id))

    def n8n_callbacks(self, limit=20):
        limit = max(1, min(int(limit), 200))
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM n8n_callbacks ORDER BY received_at DESC LIMIT ?",
                (limit,)).fetchall()
        return [dict(row) for row in rows]

    def requeue_expired(self):
        recovered = []
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM jobs WHERE status='RUNNING' AND lease_expires_at IS NOT NULL"
                " AND lease_expires_at < ?", (now(),)).fetchall()
            for row in rows:
                if row["attempts"] >= row["max_attempts"]:
                    db.execute("UPDATE jobs SET status='FAILED', error='lease expired', lease_owner=NULL,"
                               " lease_expires_at=NULL, updated_at=? WHERE id=?", (now(), row["id"]))
                    if row["step_id"]:
                        db.execute("UPDATE steps SET status='FAILED' WHERE mission_id=? AND id=? AND status='RUNNING'",
                                   (row["mission_id"], row["step_id"]))
                        self._event(db, row["mission_id"], row["step_id"], None, None, "STEP_FAILED",
                                    {"status": "FAILED", "error": "lease expired"})
                    self._event(db, row["mission_id"], row["step_id"], None, None, "JOB_FAILED",
                                {"job_id": row["id"], "error": "lease expired"})
                    self._refresh_blocked_jobs(db, row["mission_id"])
                else:
                    db.execute("UPDATE jobs SET status='QUEUED', lease_owner=NULL, lease_expires_at=NULL,"
                               " updated_at=? WHERE id=?", (now(), row["id"]))
                    self._event(db, row["mission_id"], row["step_id"], None, None, "JOB_REQUEUED",
                                {"job_id": row["id"]})
                recovered.append(row["id"])
        return recovered
