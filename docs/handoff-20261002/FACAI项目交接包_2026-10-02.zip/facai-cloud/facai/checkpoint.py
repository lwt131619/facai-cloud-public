"""Git checkpoints for a mission workspace.

A checkpoint is a real commit in the mission's own workspace. When git is
unavailable the caller gets a structured reason instead of a fabricated
success, so Mission Control never invents a checkpoint that did not happen.
"""

import subprocess
from pathlib import Path

GITIGNORE = ".facai/\n__pycache__/\n*.pyc\n"
AUTHOR = ["-c", "user.name=Facai", "-c", "user.email=facai@localhost"]


def _run(args, cwd):
    return subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                          text=True, encoding="utf-8", errors="replace")


def _git_available():
    try:
        return _run(["--version"], Path.cwd()).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _git_is_valid(workspace):
    """Validate that *workspace itself* is a repository, including worktrees.

    ``git rev-parse`` succeeds inside any parent repository too. Accepting that
    result would let checkpoint ``git add`` / ``git commit`` modify the FACAI
    source checkout when a mission workspace lives beneath it.
    """
    workspace = Path(workspace).resolve()
    try:
        result = _run(["rev-parse", "--show-toplevel"], workspace)
        if result.returncode != 0 or not result.stdout.strip():
            return False
        top_level = Path(result.stdout.strip()).resolve()
        return top_level == workspace
    except (OSError, subprocess.SubprocessError):
        return False


def ensure_repo(workspace):
    workspace = Path(workspace)
    if _git_is_valid(workspace):
        return True
    workspace.mkdir(parents=True, exist_ok=True)
    result = _run(["init"], workspace)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git init failed")
    ignore = workspace / ".gitignore"
    if not ignore.exists():
        ignore.write_text(GITIGNORE, encoding="utf-8")
    return True


def checkpoint(workspace, message):
    workspace = Path(workspace)
    if not workspace.is_dir():
        return {"committed": False, "reason": "workspace missing"}
    if not _git_available():
        return {"committed": False, "reason": "git unavailable"}
    try:
        ensure_repo(workspace)
    except RuntimeError as exc:
        return {"committed": False, "reason": str(exc)}
    _run(["add", "-A"], workspace)
    commit = _run([*AUTHOR, "commit", "-m", message], workspace)
    if commit.returncode != 0:
        blob = f"{commit.stdout}\n{commit.stderr}"
        if "nothing to commit" in blob or "no changes added" in blob:
            return {"committed": False, "reason": "no changes"}
        return {"committed": False, "reason": commit.stderr.strip() or "commit failed"}
    commit_hash = _run(["rev-parse", "HEAD"], workspace).stdout.strip()
    stat = _run(["show", "--stat", "--format=", "HEAD"], workspace).stdout.strip()
    return {"committed": True, "hash": commit_hash, "stat": stat}


def diff(workspace, rev=None, limit=40000):
    workspace = Path(workspace)
    if not _git_is_valid(workspace) or not _git_available():
        return {"available": False, "diff": "", "truncated": False}
    target = rev or "HEAD"
    show = _run(["show", "--format=", "--patch", target], workspace)
    if show.returncode != 0:
        return {"available": False, "diff": "", "truncated": False, "reason": show.stderr.strip()}
    text = show.stdout
    return {"available": True, "diff": text[:limit], "truncated": len(text) > limit}
