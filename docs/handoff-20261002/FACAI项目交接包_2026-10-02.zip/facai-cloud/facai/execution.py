"""Shared mission-task execution used by both the synchronous API and the scheduler.

The sequence is identical in both paths: open a mission session, run OpenCode in
the mission workspace, capture raw output as artifacts and events, record tokens
and cost, make a Git checkpoint, and finalize the step and session with the real
outcome. Nothing here fabricates success.
"""

from pathlib import Path

from .checkpoint import checkpoint
from .opencode import summarize_output

OUTPUT_LINE_LIMIT = 200
TERMINAL_STATUSES = frozenset({"OPENCODE_COMPLETED", "OPENCODE_FAILED", "OPENCODE_TIMEOUT"})


def opencode_model_ref(model):
    if not model:
        return None
    if model.get("opencode_model"):
        return model["opencode_model"]
    provider, name = model.get("provider"), model.get("model")
    if provider and name:
        return f"{provider.lower()}/{name}"
    return name


def mission_attribution(mission, model, runtime=None, skill=None, model_ref=None):
    """The provider/model/runtime/skill identity attached to every task event.

    The console reads these exact fields, so a stage always shows which upstream
    provider, model, execution location and skill produced the result.
    """
    model = model or {}
    runtime = runtime or {}
    skill = skill or {}
    attribution = {
        "agent_id": mission.get("agent_id"),
        "provider": model.get("provider"),
        "model_id": mission.get("model_id"),
        "model_ref": model_ref,
        "runtime_id": mission.get("runtime_id"),
        "runtime_kind": runtime.get("kind"),
        "runtime_provider": runtime.get("provider"),
        "runtime_location": runtime.get("location"),
        "skill_id": mission.get("skill_id"),
        "skill_name": skill.get("name"),
    }
    return {key: value for key, value in attribution.items() if value is not None}


def _persist_output(mission_id, store, result, session_id):
    workspace = Path(result["workspace"])
    log_dir = workspace / ".facai"
    log_dir.mkdir(parents=True, exist_ok=True)
    artifacts = []
    for stream in ("stdout", "stderr"):
        text = result.get(stream) or ""
        if not text:
            continue
        path = log_dir / f"opencode-{session_id}.{stream}.log"
        path.write_text(text, encoding="utf-8")
        store.add_artifact(mission_id, path.name, path)
        artifacts.append(path.name)
    return artifacts


def _append_process_output(mission_id, store, result, step_id, session_id):
    lines = [("OUTPUT", {"stream": "stdout", "line": line}) for line in (result.get("stdout") or "").splitlines()]
    lines += [("ERROR", {"stream": "stderr", "line": line}) for line in (result.get("stderr") or "").splitlines()]
    for event_type, payload in lines[:OUTPUT_LINE_LIMIT]:
        store.append(mission_id, event_type, payload, step_id, session_id, "opencode")
    if len(lines) > OUTPUT_LINE_LIMIT:
        store.append(mission_id, "OUTPUT_TRUNCATED", {"omitted": len(lines) - OUTPUT_LINE_LIMIT},
                     step_id, session_id, "opencode")


def _adapter_result_problem(result, root):
    """Describe why an adapter result is unusable, or None when it is well formed.

    The adapter contract is a mapping with a mission workspace path, a terminal
    status, an exit code and text streams. Anything else is rejected before it is
    persisted, because a malformed result would otherwise raise deep in output
    capture or checkpointing after the session had already started.
    """
    if not isinstance(result, dict):
        return "adapter result is not an object"
    workspace = result.get("workspace")
    if not isinstance(workspace, str) or not workspace.strip():
        return "adapter result has no workspace"
    try:
        resolved = Path(workspace).resolve()
    except (OSError, ValueError):
        return "adapter result has an invalid workspace"
    base = (Path(root) / "workspaces").resolve()
    # The shared workspace root itself is not an individual mission workspace.
    if resolved == base or base not in resolved.parents:
        return "adapter result workspace is outside the mission root"
    status = result.get("status")
    if not isinstance(status, str) or status not in TERMINAL_STATUSES:
        return f"adapter result has an invalid status: {status!r}"
    if "exit_code" not in result:
        return "adapter result has no exit code"
    exit_code = result["exit_code"]
    if exit_code is not None and (isinstance(exit_code, bool) or not isinstance(exit_code, int)):
        return f"adapter result has an invalid exit code: {exit_code!r}"
    if status == "OPENCODE_COMPLETED" and exit_code != 0:
        return "completed adapter result must have exit code 0"
    if status == "OPENCODE_FAILED" and (exit_code is None or exit_code == 0):
        return "failed adapter result must have a nonzero exit code"
    if status == "OPENCODE_TIMEOUT" and exit_code is not None:
        return "timed-out adapter result must have no exit code"
    for stream in ("stdout", "stderr"):
        value = result.get(stream)
        if value is not None and not isinstance(value, str):
            return f"adapter result has an invalid {stream}"
    return None


def _fail_malformed_result(store, mission_id, session_id, step_id, attribution, problem):
    """Finalize a started session as failed without consuming a bad result.

    The session exists and the step may already be RUNNING, so the failure is
    recorded here even if the caller's exception is lost: session and step become
    FAILED and an OPENCODE_FAILED event carries the real reason.
    """
    try:
        store.session_status(mission_id, session_id, "FAILED")
    except (KeyError, ValueError):
        pass
    if step_id:
        try:
            store.step_status(mission_id, step_id, "FAILED")
        except (KeyError, ValueError):
            pass
    store.append(mission_id, "OPENCODE_FAILED",
                 {**attribution, "error": problem},
                 step_id, session_id, "opencode")


def execute_mission_task(store, adapter, mission, model, root, prompt, step_id=None,
                         model_ref=None, timeout=300, runtime=None, skill=None):
    """Run one OpenCode task for a mission and record every outcome. Raises on adapter failure."""
    mission_id = mission["id"]
    model_ref = model_ref or opencode_model_ref(model)
    attribution = mission_attribution(mission, model, runtime, skill, model_ref)
    step = next((s for s in mission["steps"] if s["id"] == step_id), None)
    if step is not None and step["status"] == "COMPLETED":
        # Refuse before spending a model call, creating a session or writing a
        # checkpoint: a completed step cannot be completed a second time, and the
        # store would reject the final transition after the work had already run.
        raise ValueError("Step is already completed")
    session_id = store.start_session(mission_id, "opencode", mission["model_id"])
    store.append(mission_id, "OPENCODE_STARTED",
                 {**attribution, "prompt": prompt},
                 step_id, session_id, "opencode")
    if step and step["status"] in {"WAITING", "FAILED"}:
        store.step_status(mission_id, step_id, "RUNNING")
    streamed_count = 0

    def on_output(stream, line):
        nonlocal streamed_count
        streamed_count += 1
        if streamed_count <= OUTPUT_LINE_LIMIT:
            store.append(mission_id, "OUTPUT" if stream == "stdout" else "ERROR",
                         {"stream": stream, "line": line}, step_id, session_id, "opencode")

    try:
        result = adapter.execute(mission_id, root, prompt, model_ref, timeout, on_output=on_output)
    except ValueError:
        store.session_status(mission_id, session_id, "FAILED")
        raise
    except Exception as exc:  # adapter failed before producing a result
        store.session_status(mission_id, session_id, "FAILED")
        store.append(mission_id, "OPENCODE_FAILED",
                     {**attribution, "error": type(exc).__name__},
                     step_id, session_id, "opencode")
        raise

    problem = _adapter_result_problem(result, root)
    if problem is not None:
        _fail_malformed_result(store, mission_id, session_id, step_id, attribution, problem)
        raise ValueError(problem)

    artifacts = _persist_output(mission_id, store, result, session_id)
    if result.get("streamed"):
        if streamed_count > OUTPUT_LINE_LIMIT:
            store.append(mission_id, "OUTPUT_TRUNCATED", {"omitted": streamed_count - OUTPUT_LINE_LIMIT},
                         step_id, session_id, "opencode")
    else:
        _append_process_output(mission_id, store, result, step_id, session_id)
    terminal = result["status"]
    succeeded = terminal == "OPENCODE_COMPLETED"
    summary = summarize_output(result.get("stdout"))
    if summary["cost"] or summary["tokens"]:
        store.add_cost(mission_id, (model or {}).get("provider"), mission["model_id"],
                       summary["cost"], summary["tokens"])
    message = f"Facai checkpoint: {step['label'] if step else 'task'}"
    ckpt = checkpoint(result["workspace"], message)
    checkpoint_hash = ckpt.get("hash") if ckpt.get("committed") else None
    if ckpt.get("committed"):
        store.add_checkpoint(mission_id, ckpt["hash"], message, ckpt.get("stat", ""))
    else:
        store.append(mission_id, "GIT_CHECKPOINT_SKIPPED",
                     {"reason": ckpt.get("reason")}, step_id, session_id, "opencode")
    store.session_status(mission_id, session_id, "COMPLETED" if succeeded else "FAILED")
    if step_id:
        store.step_status(mission_id, step_id, "COMPLETED" if succeeded else "FAILED")
    store.append(mission_id, terminal,
                 {**attribution, "exit_code": result["exit_code"], "artifacts": artifacts,
                  "cost": summary["cost"], "tokens": summary["tokens"],
                  "checkpoint": checkpoint_hash},
                 step_id, session_id, "opencode")
    return {"mission_id": mission_id, "session_id": session_id, "status": terminal,
            "exit_code": result["exit_code"], "workspace": result["workspace"],
            **attribution, "cost": summary["cost"], "tokens": summary["tokens"],
            "checkpoint": checkpoint_hash, "artifacts": artifacts,
            "stdout": result["stdout"], "stderr": result["stderr"]}
