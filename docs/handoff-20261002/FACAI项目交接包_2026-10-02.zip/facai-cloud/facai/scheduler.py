"""Durable mission scheduler.

Jobs live in SQLite, so queued work, leases and recovery survive a process
restart. A worker claims a job under a lease, executes it with the same
mission-scoped execution path as the synchronous API, and finalizes it with the
real outcome. Concurrency is bounded per scheduler instance.
"""

import os
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from .execution import execute_mission_task, opencode_model_ref

# Documented default and upper bound for scheduler concurrency.
DEFAULT_CONCURRENCY = 2
CONCURRENCY_LIMIT = 8


def _worker_limit(value):
    """Parse the configured concurrency without ever aborting startup.

    ``FACAI_MAX_WORKERS`` comes from the systemd ``EnvironmentFile``, where a
    blank value is a normal way to leave a setting at its default. A missing,
    empty or non-numeric value therefore falls back to the documented default
    instead of raising ``ValueError`` while the application is still importing;
    an out-of-range number is clamped to the supported range.
    """
    try:
        parsed = int(str(value).strip())
    except (TypeError, ValueError):
        parsed = DEFAULT_CONCURRENCY
    return max(1, min(CONCURRENCY_LIMIT, parsed))


class Scheduler:
    def __init__(self, store, adapter, registries, root, concurrency=None,
                 lease_seconds=600, worker_id=None):
        self.store = store
        self.adapter = adapter
        self.registries = registries
        self.root = root
        configured = (concurrency if concurrency is not None
                      else os.getenv("FACAI_MAX_WORKERS", str(DEFAULT_CONCURRENCY)))
        self.concurrency = _worker_limit(configured)
        self.lease_seconds = lease_seconds
        self.worker_id = worker_id or f"worker-{uuid.uuid4().hex[:8]}"
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self._health_lock = threading.Lock()
        self._last_attempt_at = None
        self._last_success_at = None
        self._last_error = None
        self._consecutive_errors = 0

    def enqueue(self, mission_id, prompt, **kwargs):
        return self.store.enqueue_job(mission_id, prompt, **kwargs)

    def recover(self):
        # Expired conversion claims join the same periodic recovery path as job
        # leases, so a crashed channel worker is replayed without operator action.
        self.store.recover_stale_channel_conversions()
        return self.store.requeue_expired()

    def stats(self):
        with self._health_lock:
            health = {
                "background_running": bool(self._thread and self._thread.is_alive()),
                "last_attempt_at": self._last_attempt_at,
                "last_success_at": self._last_success_at,
                "last_error": self._last_error,
                "consecutive_errors": self._consecutive_errors,
            }
        return {"concurrency": self.concurrency, "running": self.store.count_running_jobs(),
                "worker": self.worker_id, **health}

    def _execute(self, job):
        mission = self.store.get(job["mission_id"])
        if mission is None:
            self.store.finish_job(job["id"], "FAILED", "mission missing")
            return
        owner = mission.get("owner_id", "admin")
        model = self.registries.resolve("models", mission["model_id"], owner_id=owner)
        runtime = self.registries.resolve("runtimes", mission["runtime_id"], owner_id=owner)
        skill = self.registries.resolve("skills", mission["skill_id"], owner_id=owner)
        model_ref = job["model_ref"] or opencode_model_ref(model)
        try:
            result = execute_mission_task(self.store, self.adapter, mission, model, self.root,
                                          job["prompt"], job["step_id"], model_ref, job["timeout"],
                                          runtime=runtime, skill=skill)
            if result["status"] == "OPENCODE_COMPLETED":
                self.store.finish_job(job["id"], "COMPLETED")
            else:
                self.store.finish_job(job["id"], "FAILED", result["status"])
        except Exception as exc:
            # Attribute the failure truthfully; never mark a failed run complete.
            self.store.finish_job(job["id"], "FAILED", str(exc)[:500])

    def run_once(self):
        with self._lock:
            self.recover()
            slots = max(0, self.concurrency - self.store.count_running_jobs())
            jobs = []
            for _ in range(slots):
                job = self.store.claim_job(self.worker_id, self.lease_seconds)
                if job is None:
                    break
                jobs.append(job)
            if not jobs:
                return []
            if len(jobs) == 1:
                self._execute(jobs[0])
            else:
                with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
                    list(pool.map(self._execute, jobs))
            return [job["id"] for job in jobs]

    def run_pending(self):
        total = 0
        while True:
            done = self.run_once()
            total += len(done)
            if not done:
                break
        return total

    def start(self, interval=1.0):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._serve, args=(interval,), daemon=True)
        self._thread.start()

    def _serve(self, interval):
        while not self._stop.is_set():
            attempt_at = datetime.now(timezone.utc).isoformat()
            with self._health_lock:
                self._last_attempt_at = attempt_at
            try:
                self.run_once()
                with self._health_lock:
                    self._last_success_at = datetime.now(timezone.utc).isoformat()
                    self._last_error = None
                    self._consecutive_errors = 0
            except Exception as exc:
                # Keep operational state useful without exposing exception text,
                # which can contain webhook paths, credentials or user data.
                with self._health_lock:
                    self._last_error = type(exc).__name__
                    self._consecutive_errors += 1
            self._stop.wait(interval)

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
