"""Personal WeChat iLink adapter.

Implements the QR login and JSON Bot API documented by Tencent's
openclaw-weixin protocol. A QR login is held in memory until confirmed; the
resulting token is kept only in the provider process environment and is never
returned to the browser or written to logs/database.
"""

import os
import secrets
import base64
import io
import zlib
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from .base import ChannelProvider, InboundMessage, OutboundReply

DEFAULT_BASE_URL = "https://ilinkai.weixin.qq.com"
BASE_INFO = {"channel_version": "2.4.8", "bot_agent": "Facai/1.0"}


def _ilink_url(value):
    parsed = urlsplit(value)
    if parsed.scheme != "https" or parsed.port not in (None, 443) or parsed.query or parsed.fragment or not parsed.hostname or not (
            parsed.hostname == "weixin.qq.com" or parsed.hostname.endswith(".weixin.qq.com")):
        raise ValueError("INVALID_ILINK_HOST")
    return value.rstrip("/")


def _app_headers():
    return {"iLink-App-Id": "bot", "iLink-App-ClientVersion": str(0x00020408)}


def _png_chunk(tag, data):
    return (len(data).to_bytes(4, "big") + tag + data
            + zlib.crc32(tag + data).to_bytes(4, "big"))


def _qr_png_bytes(payload, border=4, scale=8):
    """Encode a QR payload as PNG without Pillow or pypng.

    qrcode.make(...).save PNG imports qrcode.image.pil, which raises
    ImportError when the runtime installed qrcode without the Pillow extra.
    Only the matrix encoder is used; PNG bytes come from the stdlib.
    """
    import qrcode

    matrix = qrcode.QRCode(border=border, error_correction=qrcode.constants.ERROR_CORRECT_M)
    matrix.add_data(payload)
    matrix.make(fit=True)
    return _png_from_modules(matrix.get_matrix(), border, scale)


def _png_from_modules(modules, border, scale=8):
    modules = list(modules)
    quiet = border * scale
    modules_px = len(modules) * scale
    size = modules_px + quiet * 2
    white = b"\xff" * size
    raw = bytearray()
    for _ in range(quiet):
        raw.append(0)
        raw.extend(white)
    for row in modules:
        line = bytearray(b"\xff" * quiet)
        for cell in row:
            line.extend(b"\x00" * scale if cell else b"\xff" * scale)
        line.extend(b"\xff" * quiet)
        for _ in range(scale):
            raw.append(0)
            raw.extend(line)
    for _ in range(quiet):
        raw.append(0)
        raw.extend(white)
    return b"".join((
        b"\x89PNG\r\n\x1a\n",
        _png_chunk(b"IHDR", size.to_bytes(4, "big") + size.to_bytes(4, "big") + b"\x08\x00\x00\x00\x00"),
        _png_chunk(b"IDAT", zlib.compress(bytes(raw), 9)),
        _png_chunk(b"IEND", b""),
    ))


class WeChatProvider(ChannelProvider):
    name = "wechat"
    implemented = True
    required_env = ("WECHAT_BOT_TOKEN", "WECHAT_ILINK_USER_ID")

    def __init__(self, env=None, state_dir=None):
        super().__init__(env)
        self._login = None
        self._updates_buf = ""
        self._pending_updates_buf = None
        self._base_url = (self.setting("WECHAT_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self._credential_file = Path(state_dir) / "wechat.env" if state_dir else None
        self._load_credentials()

    def _load_credentials(self):
        if self._credential_file is None or not self._credential_file.is_file():
            return
        try:
            for line in self._credential_file.read_text(encoding="utf-8").splitlines():
                key, sep, value = line.partition("=")
                if sep and key in {"WECHAT_BOT_TOKEN", "WECHAT_ILINK_USER_ID", "WECHAT_BASE_URL"}:
                    self.env[key] = value
            self._base_url = (self.setting("WECHAT_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        except OSError:
            return

    def _save_credentials(self, values):
        if self._credential_file is None:
            raise OSError("secure provider state directory unavailable")
        self._credential_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self._credential_file.parent, 0o700)
        except OSError:
            pass
        temp = self._credential_file.with_suffix(".tmp")
        content = "".join(f"{key}={values[key]}\n" for key in
                           ("WECHAT_BOT_TOKEN", "WECHAT_ILINK_USER_ID", "WECHAT_BASE_URL"))
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, self._credential_file)
        try:
            os.chmod(self._credential_file, 0o600)
        except OSError:
            pass

    def status(self):
        status = super().status()
        if status.configured:
            status.detail = "iLink 授权凭据已加载；可收发消息"
        else:
            status.detail = "个人微信 iLink 已支持二维码授权，等待扫码"
        return status

    async def start_login(self, client=None):
        own = client is None
        client = client or httpx.AsyncClient(timeout=15, follow_redirects=False)
        try:
            response = await client.post(
                f"{DEFAULT_BASE_URL}/ilink/bot/get_bot_qrcode?bot_type=3",
                json={"local_token_list": []}, headers={"Content-Type": "application/json",
                    "AuthorizationType": "ilink_bot_token",
                    "X-WECHAT-UIN": base64.b64encode(str(secrets.randbelow(2**32)).encode()).decode()})
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError("INVALID_QR_RESPONSE")
            qr = data.get("qrcode")
            image = data.get("qrcode_img_content")
            if not isinstance(qr, str) or not qr or not isinstance(image, str) or not image:
                raise ValueError("INVALID_QR_RESPONSE")
            self._login = {"qrcode": qr, "image": image, "base_url": DEFAULT_BASE_URL,
                           "verify_code": None, "started_at": datetime.now(timezone.utc).isoformat()}
            # PNG is rendered consistently by browsers and avoids SVG data URI
            # parsing differences (the previous SVG appeared as a broken image
            # in the deployed Mission Control page). Encoding must not import
            # qrcode.image.pil; that backend is absent unless Pillow is installed.
            png = _qr_png_bytes(image, border=4)
            qr_data = "data:image/png;base64," + base64.b64encode(png).decode("ascii")
            return {"state": "WAITING_FOR_SCAN", "qr_image": qr_data}
        except httpx.TimeoutException:
            return {"state": "FAILED", "error": "TIMEOUT"}
        except httpx.RequestError:
            return {"state": "FAILED", "error": "TRANSPORT_ERROR"}
        except (ValueError, KeyError):
            return {"state": "FAILED", "error": "INVALID_QR_RESPONSE"}
        finally:
            if own:
                await client.aclose()

    async def poll_login(self, client=None):
        if not self._login:
            return {"state": "NOT_STARTED"}
        own = client is None
        client = client or httpx.AsyncClient(timeout=35, follow_redirects=False)
        try:
            params = {"qrcode": self._login["qrcode"]}
            if self._login.get("verify_code"):
                params["verify_code"] = self._login["verify_code"]
            response = await client.get(f"{self._login['base_url']}/ilink/bot/get_qrcode_status",
                                        params=params, headers=_app_headers())
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError("INVALID_LOGIN_RESPONSE")
            state = data.get("status")
            if state == "scaned_but_redirect" and data.get("redirect_host"):
                host = str(data["redirect_host"]).removeprefix("https://")
                self._login["base_url"] = _ilink_url("https://" + host)
            if state == "need_verifycode":
                return {"state": "need_verifycode"}
            if state == "confirmed":
                token, user_id = data.get("bot_token"), data.get("ilink_user_id")
                try:
                    base_url = _ilink_url(data.get("baseurl") or self._login["base_url"])
                except ValueError:
                    return {"state": "FAILED", "error": "INVALID_LOGIN_RESPONSE"}
                if not isinstance(token, str) or not token or not isinstance(user_id, str) or not user_id:
                    return {"state": "FAILED", "error": "INVALID_LOGIN_RESPONSE"}
                # Keep secrets only in this process. Production persistence is via
                # the protected provider env file configured by the operator.
                values = {"WECHAT_BOT_TOKEN": token, "WECHAT_ILINK_USER_ID": user_id,
                          "WECHAT_BASE_URL": base_url}
                try:
                    self._save_credentials(values)
                except OSError:
                    return {"state": "FAILED", "error": "SECURE_STORAGE_UNAVAILABLE"}
                self.env.update(values)
                self._base_url = base_url.rstrip("/")
                self._login = None
                return {"state": "AUTHORIZED", "account": user_id}
            return {"state": state if state in {"wait", "scaned", "expired", "need_verifycode", "verify_code_blocked", "binded_redirect"} else "WAITING_FOR_SCAN"}
        except httpx.TimeoutException:
            return {"state": "WAITING_FOR_SCAN"}
        except httpx.RequestError:
            return {"state": "FAILED", "error": "TRANSPORT_ERROR"}
        except ValueError:
            return {"state": "FAILED", "error": "INVALID_LOGIN_RESPONSE"}
        finally:
            if own:
                await client.aclose()

    def submit_verify_code(self, code):
        if not self._login:
            raise ValueError("LOGIN_NOT_STARTED")
        if not isinstance(code, str) or not code.isdigit() or not 4 <= len(code) <= 8:
            raise ValueError("INVALID_VERIFY_CODE")
        self._login["verify_code"] = code
        return {"state": "VERIFY_CODE_SUBMITTED"}

    def _headers(self):
        token = self.setting("WECHAT_BOT_TOKEN")
        if not token:
            raise ValueError("WECHAT_NOT_AUTHORIZED")
        return {"Content-Type": "application/json", "AuthorizationType": "ilink_bot_token",
                "Authorization": f"Bearer {token}", **_app_headers(),
                "X-WECHAT-UIN": base64.b64encode(str(secrets.randbelow(2**32)).encode()).decode()}

    async def fetch_updates(self, client=None):
        self.require_configured()
        own = client is None
        client = client or httpx.AsyncClient(timeout=40, follow_redirects=False)
        try:
            response = await client.post(f"{self._base_url}/ilink/bot/getupdates",
                headers=self._headers(), json={"get_updates_buf": self._updates_buf, "base_info": BASE_INFO})
            response.raise_for_status()
            try:
                data = response.json()
            except ValueError:
                return {"state": "FAILED", "error": "INVALID_UPSTREAM_RESPONSE", "messages": []}
            if not isinstance(data, dict):
                return {"state": "FAILED", "error": "INVALID_UPSTREAM_RESPONSE", "messages": []}
            if data.get("ret", 0) != 0 or data.get("errcode", 0) != 0:
                return {"state": "FAILED", "error": "UPSTREAM_REJECTED", "messages": []}
            try:
                messages = self.parse_inbound(data)
            except ValueError:
                return {"state": "FAILED", "error": "INVALID_UPSTREAM_RESPONSE", "messages": []}
            next_buf = data.get("get_updates_buf")
            self._pending_updates_buf = next_buf if isinstance(next_buf, str) and next_buf else self._updates_buf
            return {"state": "OK", "messages": messages,
                    "get_updates_buf": self._pending_updates_buf}
        except httpx.TimeoutException:
            return {"state": "RETRY", "error": "TIMEOUT", "messages": []}
        except httpx.RequestError:
            return {"state": "RETRY", "error": "TRANSPORT_ERROR", "messages": []}
        finally:
            if own:
                await client.aclose()

    def acknowledge_updates(self):
        """Commit the returned long-poll cursor after the caller durably stores messages."""
        if self._pending_updates_buf is not None:
            self._updates_buf = self._pending_updates_buf
            self._pending_updates_buf = None

    def parse_inbound(self, payload):
        if not isinstance(payload, dict) or not isinstance(payload.get("msgs", []), list):
            raise ValueError("Invalid WeChat iLink update payload")
        result = []
        for msg in payload.get("msgs", []):
            if not isinstance(msg, dict):
                continue
            sender = msg.get("from_user_id")
            items = msg.get("item_list", [])
            if not isinstance(sender, str) or not sender or not isinstance(items, list):
                continue
            texts = [item.get("text_item", {}).get("text") for item in items
                     if isinstance(item, dict) and item.get("type") == 1
                     and isinstance(item.get("text_item"), dict)]
            # Preserve the user's exact text for the audit record and prompt.
            # Whitespace is used only to decide whether the message is empty.
            text = "\n".join(value for value in texts if isinstance(value, str))
            if not text.strip():
                continue
            message_id = str(msg.get("message_id") or msg.get("client_id") or "")
            if not message_id:
                continue
            timestamp = msg.get("create_time_ms")
            try:
                received_at = datetime.fromtimestamp(int(timestamp) / 1000, timezone.utc).isoformat()
            except (TypeError, ValueError, OSError, OverflowError):
                received_at = datetime.now(timezone.utc).isoformat()
            result.append(InboundMessage(channel=self.name, external_id=message_id,
                sender=sender, recipient=self.setting("WECHAT_ILINK_USER_ID"), text=text,
                received_at=received_at, raw=msg,
                metadata={"context_token": msg.get("context_token")}))
        return result

    async def send(self, reply: OutboundReply, client=None):
        self.require_configured()
        if reply.channel != self.name or not reply.recipient.strip() or not reply.text:
            raise ValueError("A WeChat reply needs a recipient and text")
        own = client is None
        client = client or httpx.AsyncClient(timeout=20, follow_redirects=False)
        msg = {"from_user_id": "", "to_user_id": reply.recipient,
               "client_id": secrets.token_urlsafe(18), "message_type": 2,
               "message_state": 2, "item_list": [{"type": 1, "text_item": {"text": reply.text}}]}
        if reply.metadata.get("context_token"):
            msg["context_token"] = reply.metadata["context_token"]
        try:
            response = await client.post(f"{self._base_url}/ilink/bot/sendmessage",
                headers=self._headers(), json={"msg": msg, "base_info": BASE_INFO})
            response.raise_for_status()
            try:
                data = response.json()
            except ValueError:
                return {"channel": self.name, "status": "FAILED", "http_status": response.status_code,
                        "error": "INVALID_UPSTREAM_RESPONSE"}
            if not isinstance(data, dict):
                return {"channel": self.name, "status": "FAILED", "http_status": response.status_code,
                        "error": "INVALID_UPSTREAM_RESPONSE"}
            if data.get("ret", 0) != 0:
                return {"channel": self.name, "status": "FAILED", "http_status": response.status_code,
                        "error": "UPSTREAM_REJECTED"}
            return {"channel": self.name, "status": "SENT", "http_status": response.status_code,
                    "external_id": str(data.get("message_id") or msg["client_id"]), "error": None}
        except httpx.TimeoutException:
            return {"channel": self.name, "status": "FAILED", "http_status": None, "error": "TIMEOUT"}
        except httpx.RequestError:
            return {"channel": self.name, "status": "FAILED", "http_status": None, "error": "TRANSPORT_ERROR"}
        finally:
            if own:
                await client.aclose()
