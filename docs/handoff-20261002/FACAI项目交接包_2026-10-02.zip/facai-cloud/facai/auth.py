"""Session-based admin authentication for a public-facing deployment.

Passwords and session secrets are read from the process environment only; no
secret is ever written to the database, a cookie payload is never stored raw,
and no credential is logged. Sessions are opaque random tokens whose SHA-256
hash is persisted, are bound to a per-session CSRF token, and expire after a
configurable TTL. Login failures are throttled per client address.

HTTP Basic remains accepted for scripts and health checks, but browsers use the
login form, an HttpOnly SameSite=Strict cookie and the CSRF header.
"""

import base64
import hashlib
import hmac
import os
import secrets
import json
from datetime import datetime, timezone

SESSION_COOKIE = "facai_session"
CSRF_HEADER = "x-csrf-token"
USERNAME = "admin"
SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})


def hash_token(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _default_username():
    return os.getenv("FACAI_ADMIN_USER", USERNAME)


class AuthManager:
    def __init__(self, store):
        self.store = store
        # Fail during startup for malformed or over-limit tenant configuration.
        self.users

    @property
    def enabled(self):
        return bool(self.users)

    @property
    def users(self):
        """Configured login credentials, capped at five accounts."""
        raw = os.getenv("FACAI_USERS_JSON", "").strip()
        if raw:
            try:
                configured = json.loads(raw)
            except (TypeError, ValueError) as exc:
                raise RuntimeError("FACAI_USERS_JSON must be a JSON object of usernames to passwords") from exc
            if not isinstance(configured, dict) or not configured:
                raise RuntimeError("FACAI_USERS_JSON must be a non-empty JSON object")
            if len(configured) > 5:
                raise RuntimeError("FACAI supports at most five users")
            if any(not isinstance(name, str) or not name.strip() or
                   not isinstance(password, str) or not password
                   for name, password in configured.items()):
                raise RuntimeError("FACAI_USERS_JSON entries require non-empty username and password strings")
            return configured
        password = os.getenv("FACAI_ADMIN_PASSWORD") or ""
        return {self.username: password} if password else {}

    @property
    def username(self):
        return _default_username()

    @property
    def ttl_seconds(self):
        try:
            return max(60, int(os.getenv("FACAI_SESSION_TTL", "28800")))
        except ValueError:
            return 28800

    @property
    def max_failures(self):
        try:
            return max(1, int(os.getenv("FACAI_LOGIN_MAX_FAILURES", "5")))
        except ValueError:
            return 5

    @property
    def failure_window(self):
        try:
            return max(30, int(os.getenv("FACAI_LOGIN_WINDOW", "300")))
        except ValueError:
            return 300

    def verify_credentials(self, username, password):
        users = self.users
        expected_password = users.get(username or "", "")
        valid_user = any(hmac.compare_digest(username or "", configured) for configured in users)
        valid_password = hmac.compare_digest(password or "", expected_password)
        return bool(expected_password) and valid_user and valid_password

    def is_locked(self, client_ip):
        return self.store.login_failures(client_ip) >= self.max_failures

    def login(self, username, password, client_ip):
        """Return (session, None) on success, (None, reason) otherwise."""
        if self.is_locked(client_ip):
            return None, "throttled"
        if not self.verify_credentials(username, password):
            self.store.record_login_failure(client_ip, self.failure_window)
            return None, "invalid"
        self.store.clear_login_failures(client_ip)
        token = secrets.token_urlsafe(32)
        csrf = secrets.token_urlsafe(24)
        expires_at = self.store.create_auth_session(hash_token(token), csrf, username, self.ttl_seconds)
        return {"token": token, "csrf_token": csrf, "username": username,
                "expires_at": expires_at}, None

    def session_from_token(self, token):
        if not token:
            return None
        session = self.store.get_auth_session(hash_token(token))
        if session is None:
            return None
        if session["expires_at"] < datetime.now(timezone.utc).isoformat():
            self.store.delete_auth_session(session["token_hash"])
            return None
        self.store.touch_auth_session(session["token_hash"])
        return session

    def session_from_request(self, request):
        return self.session_from_token(request.cookies.get(SESSION_COOKIE))

    def check_basic(self, request):
        return self.basic_username(request) is not None

    def basic_username(self, request):
        header = request.headers.get("authorization", "")
        try:
            scheme, encoded = header.split(" ", 1)
            username, supplied = base64.b64decode(encoded, validate=True).decode().split(":", 1)
        except (ValueError, UnicodeDecodeError):
            return None
        return username if scheme.lower() == "basic" and self.verify_credentials(username, supplied) else None

    @staticmethod
    def valid_csrf(session, supplied):
        return bool(supplied) and hmac.compare_digest(session["csrf_token"], supplied)

    def logout(self, request):
        token = request.cookies.get(SESSION_COOKIE)
        if token:
            self.store.delete_auth_session(hash_token(token))

    def prune(self):
        return self.store.prune_auth_sessions()

    @staticmethod
    def cookie_secure(request):
        setting = (os.getenv("FACAI_COOKIE_SECURE", "auto") or "auto").lower()
        if setting in {"1", "true", "yes", "on"}:
            return True
        if setting in {"0", "false", "no", "off"}:
            return False
        if not os.getenv("FACAI_TRUST_PROXY"):
            return False
        forwarded = request.headers.get("x-forwarded-proto", "").split(",")[0].strip().lower()
        return forwarded == "https" or request.url.scheme == "https"
