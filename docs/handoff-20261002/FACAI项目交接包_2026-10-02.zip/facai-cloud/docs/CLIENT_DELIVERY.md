# Facai Cloud 客户交付与授权验收

本说明区分已实现并由本地模拟测试覆盖的能力，与必须由客户实际授权后才能验收的外部连接。当前交付代码不表示 Meta、Telegram 或微信账号已经接通，也不表示已部署到客户生产环境。

## 账号、访问权限与容量边界

- 可使用单管理员兼容配置（`FACAI_ADMIN_USER` / `FACAI_ADMIN_PASSWORD`），或配置最多五个登录用户。多用户配置使用 `FACAI_USERS_JSON`，值为用户名到密码的 JSON 对象，例如 `FACAI_USERS_JSON='{"alice":"<长随机密码>","bob":"<长随机密码>"}'`。通过部署环境文件保存，文件权限保持 `0640 root:facai`；不要把真实密码放入命令行、聊天或仓库。配置无效或超过五人时服务会在启动阶段拒绝启动。
- 每个用户只能读取自己的 Mission、关联消息和费用合计；历史 Mission 与渠道消息在数据库迁移时归到 `FACAI_ADMIN_USER`（默认 `admin`）。多用户仍使用同一权限级别，没有角色或每用户配额；模型/Agent/Runtime 注册表、渠道账号及其外部平台授权为实例级共享设置。通过 HTTPS 登录，脚本可使用各自账号的 HTTP Basic。
- 登录失败按客户端地址限流，默认连续 5 次失败后，在 300 秒窗口内拒绝登录；这不是 API 通用限流。
- 调度器默认并发 2，可用 `FACAI_MAX_WORKERS` 调整，范围 1–8（每个应用实例）。这是同时运行任务上限，不是用户或月度调用配额。应用没有 API 调用预算、模型消费硬上限或渠道用户数配额。
- 出站消息文本接口限制为 1–4096 个字符。Telegram 与 WhatsApp webhook 请求体限制 1 MiB。外部服务另有自己的配额、限流、模板政策与消息窗口规则，应按相应平台当前控制台和文档确认。

## 费用与用量

Facai 记录执行过程可获得的 token / 上游成本信息，供任务审计使用；当前没有账单结算、成本保证、自动汇率换算或预算告警/硬停止。模型与消息平台费用由客户分别向对应上游支付。

部分模型响应只返回 token 用量而未提供价格，成本表会记录 `USD 0.00` 占位值。这不代表调用免费，也不能用于财务对账；请以模型供应商账单为准。WhatsApp 的费率及免费额度会随 Meta 当期政策、消息类别、地区和业务账户而变化；Telegram Bot API 的收费功能/限额也以上游账户和官方当前说明为准。上线前由客户财务或管理员核对平台控制台价格与用量，并自行设置上游预算。

## 渠道实际授权

服务端必须有稳定 HTTPS 公网地址，且该路径由客户控制。凭据只能通过部署的分类环境文件配置（参见 [部署说明](DEPLOYMENT.md)）；不要贴在聊天、工单、命令行参数、截图或仓库中。填写后重启服务，并从管理员控制台确认渠道状态为 `CONFIGURED`。状态仅表示本地配置齐全，不代表第三方授权或真实收发已经成功。

### Telegram Bot

1. 客户在 Telegram 中通过官方 `@BotFather` 创建 Bot，并妥善保管其 Bot Token。
2. 在 `/etc/facai-cloud/providers/telegram.env` 配置 `TELEGRAM_BOT_TOKEN` 和自行生成的 `TELEGRAM_WEBHOOK_SECRET`；secret 需符合适配器支持的字符与长度约束。`deploy/providers/telegram.env.example` 注释了安装位置与权限。
3. 用 Bot API `setWebhook` 将 `https://<客户域名>/api/v1/channels/telegram/webhook` 注册为回调，并把完全相同的 secret 作为 `secret_token`。Webhook 必须公网可达且 TLS 有效。
4. 用真实测试账号向 Bot 发送唯一测试文本。确认渠道收件箱保留原话、提示转换记录、Mission 和队列状态可追溯；再测试重复 webhook 不会重复创建 Mission/job，以及错误配置会明确失败。

当前只处理文本消息和 `sendMessage`；编辑、媒体、回调查询不支持。适配器不会自动重试出站发送；由调用方处理明确的失败状态。

### WhatsApp Business Platform Cloud API

1. 客户须拥有 Meta Business Portfolio、WhatsApp Business Account 和已登记的业务电话号码，并在 Meta Developer App 中启用 WhatsApp 产品。此集成仅支持官方 Cloud API，不支持个人 WhatsApp 账号或 WhatsApp Web/二维码自动化。
2. 从 Meta 管理界面取得业务号码的 Phone Number ID、可用于发送的 Access Token 和 App Secret；客户自行生成 `WHATSAPP_VERIFY_TOKEN`。将这些值填入 `/etc/facai-cloud/providers/whatsapp.env` 对应的 `WHATSAPP_PHONE_NUMBER_ID`、`WHATSAPP_ACCESS_TOKEN`、`WHATSAPP_APP_SECRET`、`WHATSAPP_VERIFY_TOKEN`。`deploy/providers/whatsapp.env.example` 注释了安装位置与权限。
3. 在 Meta App 的 Webhooks 设置中配置回调 `https://<客户域名>/api/v1/channels/whatsapp/webhook`，验证令牌填写同一个 `WHATSAPP_VERIFY_TOKEN`，并订阅 WhatsApp Business Account 的 `messages` 字段。完成 Meta 要求的 WABA 授权/订阅。
4. 在 Meta 测试环境或经客户批准的真实号码间发送一条唯一文本；核对原文、专业提示、Mission、派发状态和回复。重放相同 webhook 应复用既有消息/Mission，不重复执行。另验证错误签名会被拒绝。

当前只解析文本及按钮/交互回复中的文字；媒体本体/语音处理、模板消息、出站媒体均未接入。回复窗口、模板批准、号码/业务验证、区域费率和消息发送限制由 Meta 账户状态与当期规则决定，Facai 不代替 Meta 审批或承诺送达。

### 个人微信 iLink

1. 管理员登录 Facai 控制台，使用“个人微信扫码授权”生成二维码，再由账号所有者用目标微信账号实际扫码确认。
2. 等待登录状态确认成功，并向该账号发送唯一文本；检查收件箱原文、专业提示、Mission、任务状态和回复。
3. 授权令牌保存在 `$FACAI_DATA_DIR/providers/wechat.env`，文件权限应为 `0600`、目录 `0700`。不要复制或分享该文件。

这是腾讯公开 iLink 协议的个人账号适配，不等同于微信开放平台公众号/企业微信授权。当前仅支持文本私聊，不支持图片、文件、语音或群聊；iLink 上游服务可用性及账号资格需由客户实际扫码验收。

## 客户验收清单

- [ ] 管理员密码已设置；HTTPS、公网访问和匿名拒绝/登录成功已验证。
- [ ] 默认 Agent、Model、Skill/Runtime 绑定真实有效；否则入站消息会保留并显示暂缓/失败，不能当作已派发。
- [ ] 需要使用的渠道由客户完成真实授权；状态检查与一条真实收发测试通过。
- [ ] 用唯一文本核对原话完整保留、转换依据、Mission、事件时间线、最终执行结果和可用成本/token 指标。
- [ ] 重复投递验证幂等；若入站因缺绑定显示暂缓，补齐绑定后通过管理员接口 `POST /api/v1/channels/{channel}/messages/{message_id}/dispatch` 重试，并确认只创建一个 Mission/job；验证错误凭据、签名或授权时显示失败而非成功。
- [ ] 客户确认单管理员权限模型适用于使用人群；如需多客户/多角色隔离，先作为上线阻断项完成实现。
- [ ] 客户核对上游费率和账户配额，并建立供应商侧预算/告警；Facai 当前不强制消费上限。

以上验收涉及客户账号授权和真实消息，仅应由客户账号所有者在其控制的环境执行。本开发与本地测试没有请求真实凭据、注册真实 webhook、扫码或发送上游消息。

## 上游官方资料

- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Meta WhatsApp Business Platform Cloud API 集合与入门条件](https://www.postman.com/meta/whatsapp-business-platform/documentation/wlk6lh4/whatsapp-cloud-api)
- [Meta WhatsApp Business Platform Webhook 参考](https://www.postman.com/meta/whatsapp-business-platform/folder/tduohwq/webhook-payload-reference)
- [腾讯 openclaw-weixin iLink 协议实现](https://github.com/Tencent/openclaw-weixin)

平台政策和价格会变更；本文件描述 Facai 当前代码能力，实际接入时应再次核对平台官方控制台与最新条款。
