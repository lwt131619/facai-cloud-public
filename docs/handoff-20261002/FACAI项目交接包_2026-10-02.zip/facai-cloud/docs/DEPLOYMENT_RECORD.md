# Deployment record — channel base layer, integer progress, deep-sea UI

Append-only log of verified production deployments. Each entry is written **after**
the post-deploy checks pass; no entry is written from inspection alone. No credential
value is ever recorded here.

## 2026-10-02 — HEAD `6275061`

- **Commit:** `62750610c0cfe0a9d65ecf917571797d00a10bbd`
  *"Cover channel send and reserved endpoints in API tests"* (includes the messaging
  channel base layer `facai/channels/`, honest whole-percent mission progress, and the
  deep-sea Facai Mission Control identity).
- **Server:** `77.221.148.118`, app root `/opt/facai-cloud` (Facai-only path; nothing
  else was touched).
- **Method:** source staged to `/root/facai-cloud-src`, then the existing
  `deploy/deploy.sh update` flow (scoped `rsync --delete`, venv refresh, classified
  provider env, systemd + nginx re-apply, service restart).
- **Pre-deploy backups (taken and verified before any change):**
  - config: `/var/backups/facai-cloud/config-predeploy-20261001T160227Z.tar.gz` (`0600`)
  - database: `/var/backups/facai-cloud/db-predeploy-20261001T160227Z.sqlite3`
    (online snapshot, `integrity ok`, 3 missions)
  - app code: `/var/backups/facai-cloud/app-20261001T160227Z.tar.gz`
- **Credential templates seeded (empty placeholders only, no values set):**
  `/etc/facai-cloud/providers/{telegram,wechat,whatsapp}.env` (`0640 root:facai`);
  the existing DeepSeek credential was preserved unchanged.

### Verification (all passed)

| Check | Result |
| --- | --- |
| systemd | `facai-cloud.service` `active` / `running`, `NRestarts=0` |
| HTTPS gate | `deploy/check_public_access.sh` exits 0 — authoritative dnsowl apex+www all `77.221.148.118`, TCP 443, TLS valid to 2026-12-30 |
| Login protection | anonymous `401`, HTTP Basic authenticated `200` (over HTTPS and loopback) |
| Health check | `GET /api/v1/health` → `200` |
| Channel status API | `GET /api/v1/channels` → WhatsApp `UNCONFIGURED`, WeChat/Telegram `UNIMPLEMENTED` (honest states, `configured=false`, no false "connected") |
| Database integrity | `PRAGMA integrity_check` → `ok`; 13 tables including the new empty `channel_messages`; mission/event/registry counts preserved (3/53/3) |

Public access verified for `https://whstapp.lol`.

### Rollback reference

Code: `deploy/deploy.sh rollback /var/backups/facai-cloud/app-20261001T160227Z.tar.gz`.
Config: restore `config-predeploy-20261001T160227Z.tar.gz` over `/` and restart.
Database: stop the service, `facai.backup restore --dest <db-predeploy-...sqlite3>`, restart.

## 2026-10-02 — daily progress, WeChat QR, tenant compatibility

- **Source:** workspace snapshot (not committed to Git during this deployment).
- **Changes deployed:** stdlib PNG rendering for personal-WeChat QR codes (removes
  the missing-Pillow 500); duplicate inbound-message conversion leases and retry
  recovery; owner-scoped registry/auth/mission compatibility; authenticated daily
  provider progress API and dashboard panel. Codex repaired the registry
  compatibility regression found during full-suite validation.
- **Tests:** full local suite **488 passed** (repeated after the final dashboard
  counter change); progress + WeChat suite **39 passed**; `git diff --check` clean.
- **Method:** staged managed source in `/root/facai-cloud-src`, then ran
  `bash ./deploy/deploy.sh update`.
- **Backups:** app code `/var/backups/facai-cloud/app-20261002T120222Z.tar.gz`;
  classified environment `/var/backups/facai-cloud/env-20261002T120224Z.tar.gz`
  (mode `0600`; credential values are not recorded here).

### Verification

| Check | Result |
| --- | --- |
| systemd | `facai-cloud.service` active/running after update |
| Local health | `GET /api/v1/health` → `200` |
| Authentication | anonymous `/api/v1/daily-progress` → `401` as expected |
| Public site | authentication gate returned `401` to unauthenticated curl; browser redirects to `/login` |
| WeChat | QR renderer is deployed; account scan/authorization was not performed by deployment |

The restart invalidated the browser's in-memory admin session; sign in again to
view the new progress panel. During the graceful stop, the old process exceeded
systemd's stop timeout and was killed before the new process started; the new
service reached active state and returned health `200` afterward.
