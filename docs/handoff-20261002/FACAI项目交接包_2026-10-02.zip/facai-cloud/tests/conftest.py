"""Shared fixtures for the real-browser console acceptance tests."""

import socket
import threading
import time
import urllib.request

import pytest

from facai.api import create_app


def _free_port():
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


def _serve(app, base):
    import uvicorn

    config = uvicorn.Config(app, host="127.0.0.1", port=int(base.rsplit(":", 1)[1]),
                            log_level="warning", lifespan="on")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(200):
        try:
            urllib.request.urlopen(base + "/api/v1/health", timeout=0.5)
            break
        except Exception:
            time.sleep(0.05)
    else:
        raise RuntimeError("uvicorn did not start")
    return server, thread


@pytest.fixture
def playwright_api():
    return pytest.importorskip("playwright.sync_api")


@pytest.fixture
def console_server(tmp_path, monkeypatch, playwright_api):
    monkeypatch.delenv("FACAI_ADMIN_PASSWORD", raising=False)
    base = f"http://127.0.0.1:{_free_port()}"
    server, thread = _serve(create_app(tmp_path), base)
    yield base
    server.should_exit = True
    thread.join(timeout=5)


@pytest.fixture
def protected_server(tmp_path, monkeypatch, playwright_api):
    monkeypatch.setenv("FACAI_ADMIN_PASSWORD", "mobile-pass")
    monkeypatch.delenv("FACAI_COOKIE_SECURE", raising=False)
    base = f"http://127.0.0.1:{_free_port()}"
    server, thread = _serve(create_app(tmp_path), base)
    yield base
    server.should_exit = True
    thread.join(timeout=5)
