import asyncio
import json

import httpx
import pytest

from facai.gateway import complete


def invoke(handler, model):
    async def go():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            return await complete(model, [
                {"role": "system", "content": "Be concise."},
                {"role": "user", "content": "Hello"},
            ], client)
    return asyncio.run(go())


def anthropic_model(endpoint="https://api.anthropic.test/v1"):
    return {"provider": "Anthropic", "endpoint": endpoint, "model": "claude-test",
            "api_key_env": "TEST_ANTHROPIC_KEY"}


def test_anthropic_messages_request_maps_system_and_auth(monkeypatch):
    monkeypatch.setenv("TEST_ANTHROPIC_KEY", "mock-secret")
    seen = {}

    def handler(request):
        seen["url"] = str(request.url)
        seen["headers"] = request.headers
        seen["json"] = request.read()
        return httpx.Response(200, json={
            "type": "message", "content": [{"type": "text", "text": "Hi"}],
            "stop_reason": "end_turn", "usage": {"input_tokens": 4, "output_tokens": 2}})

    result = invoke(handler, anthropic_model())
    payload = json.loads(seen["json"])
    assert seen["url"] == "https://api.anthropic.test/v1/messages"
    assert seen["headers"]["x-api-key"] == "mock-secret"
    assert seen["headers"]["anthropic-version"] == "2023-06-01"
    assert "authorization" not in seen["headers"]
    assert payload["system"] == "Be concise."
    assert payload["messages"] == [{"role": "user", "content": "Hello"}]
    assert payload["max_tokens"] == 8192
    assert result["status"] == "MODEL_COMPLETED"
    assert result["content"] == "Hi"
    assert result["usage"] == {"input_tokens": 4, "output_tokens": 2}


def test_anthropic_non_v1_endpoint_uses_messages_path():
    def handler(request):
        assert str(request.url) == "https://api.anthropic.test/v1/messages"
        return httpx.Response(200, json={"content": [{"type": "text", "text": "ok"}]})

    assert invoke(handler, anthropic_model("https://api.anthropic.test"))["content"] == "ok"


@pytest.mark.parametrize(("configured", "expected"), [(50000, 32768), (0, 1), ("bad", 8192)])
def test_anthropic_output_limit_is_sane_and_configurable(configured, expected):
    model = anthropic_model()
    model["max_tokens"] = configured

    def handler(request):
        assert json.loads(request.content)["max_tokens"] == expected
        return httpx.Response(200, json={"content": [{"type": "text", "text": "ok"}]})

    assert invoke(handler, model)["status"] == "MODEL_COMPLETED"


def test_anthropic_refusal_and_error_are_attributed():
    refusal = invoke(lambda request: httpx.Response(200, json={
        "type": "message", "content": [{"type": "text", "text": "Can't help."},
                                           {"type": "refusal", "text": "policy"}],
        "stop_reason": "refusal"}), anthropic_model())
    assert refusal["status"] == "MODEL_REFUSED"
    assert refusal["upstream"]["content"][1]["type"] == "refusal"

    failed = invoke(lambda request: httpx.Response(400, json={
        "type": "error", "error": {"type": "invalid_request_error", "message": "bad input"}}),
        anthropic_model())
    assert failed["status"] == "MODEL_FAILED"
    assert failed["reason"] == "invalid_request_error bad input"
    assert failed["upstream"]["type"] == "error"


@pytest.mark.parametrize(("status", "expected"), [(401, "MODEL_AUTH_FAILED"),
                                                    (429, "MODEL_RATE_LIMITED")])
def test_anthropic_http_failures_keep_existing_attribution(status, expected):
    outcome = invoke(lambda request: httpx.Response(status, json={
        "type": "error", "error": {"type": "api_error", "message": "unavailable"}}),
        anthropic_model())
    assert outcome["status"] == expected
    assert outcome["http_status"] == status
