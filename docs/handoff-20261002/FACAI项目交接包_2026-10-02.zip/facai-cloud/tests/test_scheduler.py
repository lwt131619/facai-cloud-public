"""Durable scheduler: queue, priority, leases, recovery, retry and isolation."""

import subprocess

from fastapi.testclient import TestClient

from facai.api import create_app
from facai.opencode import OpenCodeAdapter
from facai.registries import Registries
from facai.scheduler import Scheduler
from facai.store import Store


class SequencedRunner:
    """Returns prepared outcomes in order; never calls a model."""

    def __init__(self, results):
        self.results = results
        self.index = 0
        self.cwds = []

    def __call__(self, command, cwd, timeout):
        self.cwds.append(str(cwd))
        outcome = self.results[min(self.index, len(self.results) - 1)]
        self.index += 1
        if outcome == "timeout":
            raise subprocess.TimeoutExpired(command, timeout)
        returncode, stdout, stderr = outcome
        return subprocess.CompletedProcess(command, returncode, stdout, stderr)


def build(tmp_path, runner, concurrency=1, lease_seconds=600):
    store = Store(tmp_path)
    registries = Registries(store)
    adapter = OpenCodeAdapter(binary='opencode', runner=runner)
    scheduler = Scheduler(store, adapter, registries, tmp_path, concurrency=concurrency,
                          lease_seconds=lease_seconds, worker_id='test-worker')
    return store, scheduler


def make_mission(store, title='M', steps=('开发',)):
    mission = store.create(title, f'input {title}', list(steps))
    store.bind(mission['id'], 'opencode', 'deepseek-flash')
    return store.get(mission['id'])


def test_run_pending_executes_jobs_and_isolates_missions(tmp_path):
    runner = SequencedRunner([(0, '{"type":"text","text":"ok"}\n', '')] * 4)
    store, scheduler = build(tmp_path, runner)
    a, b = make_mission(store, 'A'), make_mission(store, 'B')
    store.enqueue_job(a['id'], 'task A', step_id=a['steps'][0]['id'])
    store.enqueue_job(b['id'], 'task B', step_id=b['steps'][0]['id'])

    assert scheduler.run_pending() == 2
    assert all(job['status'] == 'COMPLETED' for job in store.jobs())
    # Each job ran inside its own mission workspace.
    assert a['id'] in runner.cwds[0] and b['id'] in runner.cwds[1]
    for mission in (a, b):
        events = store.events(mission['id'])
        assert any(event['type'] == 'JOB_COMPLETED' for event in events)
        assert all(event['mission_id'] == mission['id'] for event in events)


def test_priority_orders_claim(tmp_path):
    runner = SequencedRunner([(0, '', '')] * 2)
    store, scheduler = build(tmp_path, runner, concurrency=1)
    mission = make_mission(store)
    low = store.enqueue_job(mission['id'], 'low', priority=0)
    high = store.enqueue_job(mission['id'], 'high', priority=5)

    first_batch = scheduler.run_once()
    assert first_batch == [high['id']]
    assert store.get_job(high['id'])['status'] == 'COMPLETED'
    assert store.get_job(low['id'])['status'] == 'QUEUED'
    scheduler.run_pending()
    assert store.get_job(low['id'])['status'] == 'COMPLETED'


def test_concurrency_limit_bounds_batch(tmp_path):
    runner = SequencedRunner([(0, '', '')] * 3)
    store, scheduler = build(tmp_path, runner, concurrency=2)
    mission_a = make_mission(store, 'A')
    mission_b = make_mission(store, 'B')
    mission_c = make_mission(store, 'C')
    store.enqueue_job(mission_a['id'], 'task A')
    store.enqueue_job(mission_b['id'], 'task B')
    store.enqueue_job(mission_c['id'], 'task C')
    assert len(scheduler.run_once()) == 2
    assert store.count_running_jobs() == 0
    assert sum(job['status'] == 'COMPLETED' for job in store.jobs()) == 2


def test_same_mission_never_claims_two_jobs_concurrently(tmp_path):
    runner = SequencedRunner([(0, '', '')] * 3)
    store, scheduler = build(tmp_path, runner, concurrency=3)
    mission = make_mission(store)
    for _ in range(3):
        store.enqueue_job(mission['id'], 'task')
    claimed = store.claim_job('external-worker', lease_seconds=600)
    assert claimed is not None
    # A separate scheduler worker must leave this mission's other jobs queued.
    assert scheduler.run_once() == []
    assert sum(job['status'] == 'QUEUED' for job in store.jobs(mission['id'])) == 2


def test_failure_can_be_retried(tmp_path):
    runner = SequencedRunner([(1, '', 'boom'), (0, 'ok', '')])
    store, scheduler = build(tmp_path, runner)
    mission = make_mission(store)
    job = store.enqueue_job(mission['id'], 'task', max_attempts=2)
    scheduler.run_pending()
    assert store.get_job(job['id'])['status'] == 'FAILED'

    retried = store.retry_job(job['id'])
    assert retried['status'] == 'QUEUED' and retried['attempts'] == 0
    scheduler.run_pending()
    assert store.get_job(job['id'])['status'] == 'COMPLETED'


def test_expired_lease_is_recovered(tmp_path):
    runner = SequencedRunner([(0, '', '')])
    store, scheduler = build(tmp_path, runner)
    mission = make_mission(store)

    requeueable = store.enqueue_job(mission['id'], 'task', max_attempts=2)
    claimed = store.claim_job('dead-worker', lease_seconds=-1)
    assert claimed['id'] == requeueable['id'] and claimed['status'] == 'RUNNING'
    assert store.requeue_expired() == [requeueable['id']]
    assert store.get_job(requeueable['id'])['status'] == 'QUEUED'

    exhausted = store.enqueue_job(mission['id'], 'task', max_attempts=1, priority=5)
    claimed = store.claim_job('dead-worker', lease_seconds=-1)
    assert claimed['id'] == exhausted['id']
    assert store.requeue_expired() == [exhausted['id']]
    assert store.get_job(exhausted['id'])['status'] == 'FAILED'


def test_paused_and_cancelled_jobs_are_not_run(tmp_path):
    runner = SequencedRunner([(0, '', '')])
    store, scheduler = build(tmp_path, runner)
    mission = make_mission(store)
    paused = store.enqueue_job(mission['id'], 'paused')
    store.pause_job(paused['id'])
    cancelled = store.enqueue_job(mission['id'], 'cancelled')
    store.cancel_job(cancelled['id'])

    assert scheduler.run_once() == []
    assert store.get_job(paused['id'])['status'] == 'PAUSED'
    assert store.get_job(cancelled['id'])['status'] == 'CANCELLED'
    store.resume_job(paused['id'])
    assert scheduler.run_pending() == 1
    assert store.get_job(paused['id'])['status'] == 'COMPLETED'


def test_five_missions_concurrency_two_queues_safely(tmp_path):
    runner = SequencedRunner([(0, '{"type":"text","text":"ok"}\n', '')] * 5)
    store, scheduler = build(tmp_path, runner, concurrency=2)
    missions = [make_mission(store, f'M{i}') for i in range(5)]
    for m in missions:
        store.enqueue_job(m['id'], f'task {m["title"]}', step_id=m['steps'][0]['id'])

    first = scheduler.run_once()
    assert len(first) == 2
    assert sum(job['status'] == 'COMPLETED' for job in store.jobs()) == 2
    assert sum(job['status'] == 'QUEUED' for job in store.jobs()) == 3

    second = scheduler.run_once()
    assert len(second) == 2
    assert sum(job['status'] == 'COMPLETED' for job in store.jobs()) == 4

    third = scheduler.run_once()
    assert len(third) == 1
    assert all(job['status'] == 'COMPLETED' for job in store.jobs())

    mission_ids = {m['id'] for m in missions}
    for cwd in runner.cwds:
        assert any(mid in cwd for mid in mission_ids)
    seen = set()
    for m in missions:
        matches = [c for c in runner.cwds if m['id'] in c]
        assert len(matches) >= 1
        seen.add(m['id'])
    assert seen == mission_ids


def test_job_http_lifecycle(tmp_path, monkeypatch):
    monkeypatch.setenv('FACAI_SCHEDULER_ENABLED', '0')
    runner = SequencedRunner([(0, '{"type":"text","text":"done"}', '')])
    client = TestClient(create_app(tmp_path, opencode_adapter=OpenCodeAdapter(binary='opencode', runner=runner)))
    mission = client.post('/api/v1/missions', json={
        'title': 'J', 'original_input': 'in', 'steps': ['开发']}).json()
    client.put(f"/api/v1/missions/{mission['id']}/binding",
               json={'agent_id': 'opencode', 'model_id': 'deepseek-flash'})

    queued = client.post(f"/api/v1/missions/{mission['id']}/jobs",
                         json={'prompt': 'task', 'step_id': mission['steps'][0]['id']})
    assert queued.status_code == 201 and queued.json()['status'] == 'QUEUED'
    assert len(client.get(f"/api/v1/missions/{mission['id']}/jobs").json()) == 1

    ran = client.post('/api/v1/scheduler/run')
    assert ran.status_code == 200 and ran.json()['executed']
    job = client.get(f"/api/v1/jobs/{queued.json()['id']}").json()
    assert job['status'] == 'COMPLETED'
    assert client.get('/api/v1/scheduler').json()['concurrency'] >= 1

    assert client.post('/api/v1/missions/%s/jobs' % mission['id'],
                       json={'prompt': 'x', 'step_id': 'wrong'}).status_code == 404
    assert client.post('/api/v1/jobs/unknown/cancel').status_code == 404


def test_background_scheduler_health_records_safe_error_and_recovers(tmp_path):
    store, scheduler = build(tmp_path, SequencedRunner([(0, '', '')]))

    class StopAfterOneCycle:
        stopped = False

        def is_set(self):
            return self.stopped

        def wait(self, _interval):
            self.stopped = True
            return True

    stop = StopAfterOneCycle()
    scheduler._stop = stop
    scheduler.run_once = lambda: (_ for _ in ()).throw(RuntimeError("secret webhook path"))
    scheduler._serve(0.01)
    failed = scheduler.stats()
    assert failed["background_running"] is False
    assert failed["last_attempt_at"] is not None
    assert failed["last_success_at"] is None
    assert failed["last_error"] == "RuntimeError"
    assert failed["consecutive_errors"] == 1
    assert "secret webhook path" not in str(failed)

    stop.stopped = False
    scheduler.run_once = lambda: []
    scheduler._serve(0.01)
    recovered = scheduler.stats()
    assert recovered["last_success_at"] is not None
    assert recovered["last_error"] is None
    assert recovered["consecutive_errors"] == 0
