"""End-to-end personal WeChat path against a mock iLink server.

The provider-level tests prove each call in isolation; this one drives the whole
operator-visible flow through the real app: start a QR login, poll it to
``AUTHORIZED``, let the background monitor pick up an inbound text, then reply
through the dedicated endpoint and confirm the reply carries the original
``context_token``. Only ``httpx.AsyncClient`` is redirected to a mock transport,
so the API, store, monitor and dispatch code under test are the real ones.
"""

import json
import os
import time

import httpx
from fastapi.testclient import TestClient

import facai.channels as channels_module
import facai.channels.wechat as wechat_module
from facai.api import create_app

INBOUND = {
    "message_id": 101,
    "from_user_id": "friend-1",
    "create_time_ms": 1720000000000,
    "context_token": "ctx-1",
    "item_list": [{"type": 1, "text_item": {"text": "帮我把部署步骤整理一下"}}],
}


class MockILink:
    """Smallest iLink server the app needs: login, one update, send."""

    def __init__(self):
        self.sent = []
        self.login_polls = 0
        self.updates_served = 0

    async def handler(self, request):
        path = request.url.path
        if path.endswith("get_bot_qrcode"):
            return httpx.Response(200, json={"qrcode": "qr-1",
                                             "qrcode_img_content": "https://weixin.qq.com/qr"})
        if path.endswith("get_qrcode_status"):
            self.login_polls += 1
            return httpx.Response(200, json={"status": "confirmed", "bot_token": "bot-secret",
                                             "ilink_user_id": "bot-1",
                                             "baseurl": "https://ilinkai.weixin.qq.com"})
        if path.endswith("getupdates"):
            self.updates_served += 1
            payload = {"ret": 0, "get_updates_buf": "cursor-1", "msgs": [INBOUND]}
            if self.updates_served == 1:
                return httpx.Response(200, json=payload)
            return httpx.Response(200, json={"ret": 0, "msgs": []})
        if path.endswith("sendmessage"):
            self.sent.append(json.loads(request.content))
            return httpx.Response(200, json={"ret": 0, "message_id": "out-1"})
        return httpx.Response(404)


def test_wechat_qr_login_receive_and_reply_end_to_end(tmp_path, monkeypatch):
    mock = MockILink()
    real_async_client = httpx.AsyncClient

    # The QR flow must not write credentials into the real process env.
    env_keys = ("WECHAT_BOT_TOKEN", "WECHAT_ILINK_USER_ID", "WECHAT_BASE_URL")
    env_before = {key: os.environ.get(key) for key in env_keys}

    def factory(*args, **kwargs):
        kwargs.pop("transport", None)
        return real_async_client(transport=httpx.MockTransport(mock.handler), **kwargs)

    monkeypatch.setattr(wechat_module.httpx, "AsyncClient", factory)
    monkeypatch.delenv("FACAI_ADMIN_PASSWORD", raising=False)
    # Give the app its own credential mapping instead of the shared os.environ:
    # the QR flow writes the token into the provider env, and that must never
    # leak into the real process environment or into later tests. A fresh dict
    # (instead of ChannelRegistry defaulting to os.environ) keeps it isolated.
    real_build_providers = channels_module.build_providers
    monkeypatch.setattr(
        channels_module, "build_providers",
        lambda env=None, state_dir=None: real_build_providers({}, state_dir=state_dir))
    monkeypatch.setenv("FACAI_SCHEDULER_ENABLED", "0")
    monkeypatch.setenv("FACAI_N8N_RELAY_ENABLED", "0")
    monkeypatch.setenv("FACAI_WECHAT_POLL_INTERVAL", "0.02")
    monkeypatch.setenv("FACAI_WECHAT_ERROR_BACKOFF", "0.02")

    app = create_app(tmp_path)
    with TestClient(app) as client:
        started = client.post("/api/v1/channels/wechat/login")
        assert started.status_code == 200
        assert started.json()["state"] == "WAITING_FOR_SCAN"
        assert started.json()["qr_image"].startswith("data:image/png;base64,")

        authorized = client.get("/api/v1/channels/wechat/login")
        assert authorized.status_code == 200
        assert authorized.json() == {"state": "AUTHORIZED", "account": "bot-1"}
        assert app.state.channels.get("wechat").configured() is True

        deadline = time.time() + 10
        inbound = []
        while time.time() < deadline:
            inbound = [row for row in app.state.store.channel_messages("wechat")
                       if row["direction"] == "INBOUND"]
            if (inbound and inbound[0]["mission_id"]
                    and app.state.store.jobs(inbound[0]["mission_id"])):
                break
            time.sleep(0.02)

        assert mock.login_polls == 1
        assert len(inbound) == 1
        message = inbound[0]
        assert message["external_id"] == "101"
        assert message["text"] == "帮我把部署步骤整理一下"
        assert message["sender"] == "friend-1"
        assert message["payload"]["context_token"] == "ctx-1"
        assert message["mission_id"]

        mission = app.state.store.get(message["mission_id"])
        assert mission["original_input"] == "帮我把部署步骤整理一下"
        assert mission["agent_id"] and mission["model_id"] and mission["runtime_id"]
        jobs = app.state.store.jobs(mission["id"])
        assert len(jobs) == 1
        assert jobs[0]["status"] == "QUEUED"
        event_types = [event["type"] for event in app.state.store.events(mission["id"])]
        assert "MISSION_CREATED" in event_types
        assert "PROMPT_CONVERTED" in event_types
        assert "DISPATCH_QUEUED" in event_types

        inbox = client.get("/api/v1/inbox").json()
        assert any(row["external_id"] == "101" for row in inbox)

        reply = client.post(
            f"/api/v1/channels/wechat/messages/{message['id']}/reply",
            json={"text": "收到，正在整理"})
        assert reply.status_code == 200
        assert reply.json()["status"] == "SENT"

        assert len(mock.sent) == 1
        sent_message = mock.sent[0]["msg"]
        assert sent_message["to_user_id"] == "friend-1"
        assert sent_message["context_token"] == "ctx-1"
        assert sent_message["item_list"][0]["text_item"]["text"] == "收到，正在整理"

        outbound = [row for row in app.state.store.channel_messages("wechat")
                    if row["direction"] == "OUTBOUND"]
        assert len(outbound) == 1
        assert outbound[0]["status"] == "SENT"
        assert outbound[0]["external_id"] == "out-1"
        assert outbound[0]["payload"]["reply_to_message"] == message["id"]
        assert "bot-secret" not in json.dumps(outbound[0])

    assert {key: os.environ.get(key) for key in env_keys} == env_before
