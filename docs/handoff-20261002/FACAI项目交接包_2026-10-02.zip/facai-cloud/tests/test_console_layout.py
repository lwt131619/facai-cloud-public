"""Desktop-first-screen and deep-link acceptance for Mission Control.

The product complaint was that opening Mission Control showed the creation
forms but not the selected mission's real progress, so these tests prove in a
real Chromium that a 1440x900 first screen shows the progress bar, the current
stage and the pipeline, that creation/registration are collapsed by default,
and that a ``?mission=<id>`` deep link survives the login round-trip.
"""

import base64
import json

import pytest


def _launch(playwright):
    try:
        return playwright.chromium.launch()
    except Exception as exc:  # browser binary not installed
        pytest.skip(f"Playwright chromium unavailable: {exc}")


def _json_headers(extra=None):
    headers = {"Content-Type": "application/json"}
    if extra:
        headers.update(extra)
    return headers


def _create_mission(request, base, title, steps, headers=None):
    response = request.post(
        base + "/api/v1/missions",
        data=json.dumps({"title": title, "original_input": f"原始要求：{title}", "steps": steps}),
        headers=_json_headers(headers))
    assert response.ok, response.text
    return response.json()


def _advance(request, base, mission_id, step_id, status, headers=None):
    response = request.patch(
        f"{base}/api/v1/missions/{mission_id}/steps/{step_id}",
        data=json.dumps({"status": status}), headers=_json_headers(headers))
    assert response.ok, response.text


def test_desktop_first_screen_shows_real_progress_and_pipeline(console_server, playwright_api):
    base = console_server
    errors = []
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

        mission = _create_mission(page.request, base, "桌面首屏核验", ["规划", "开发", "测试"])
        first = mission["steps"][0]["id"]
        _advance(page.request, base, mission["id"], first, "RUNNING")
        _advance(page.request, base, mission["id"], first, "COMPLETED")

        page.goto(f"{base}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail [role=progressbar]")

        # Real progress comes from completed steps: 1/3 -> 33%, never a fake value.
        assert page.get_attribute("#detail [role=progressbar]", "aria-valuenow") == "33"
        assert "33%" in page.inner_text("#detail .overview .pct")

        # The complaint: progress must be on the first screen without scrolling.
        box = page.eval_on_selector(
            "#detail [role=progressbar]",
            "el => { const r = el.getBoundingClientRect(); return { top: r.top, bottom: r.bottom }; }")
        assert 0 <= box["top"] and box["bottom"] <= 900, f"progress bar below the fold: {box}"

        current_bottom = page.eval_on_selector("#detail #current-stage", "el => el.getBoundingClientRect().bottom")
        assert current_bottom <= 900, "current stage below the fold"
        assert "开发" in page.inner_text("#detail #current-stage"), "current stage should be the next waiting step"

        stage_top = page.eval_on_selector("#detail .pipeline .stage", "el => el.getBoundingClientRect().top")
        assert stage_top <= 900, "pipeline not visible on the first screen"

        overflow = page.evaluate(
            "document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 1, f"desktop horizontal overflow of {overflow}px"

        # Creation and registration are secondary, collapsed sections on desktop too.
        assert page.eval_on_selector("#create-panel", "el => el.open") is False
        assert page.eval_on_selector("#registry-panel", "el => el.open") is False
        assert page.eval_on_selector("#create-panel", "el => !!el.querySelector('form')") is True

        browser.close()
    assert not errors, f"console errors: {errors}"


def test_progress_bar_width_aria_and_label_agree(console_server, playwright_api):
    base = console_server
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        mission = _create_mission(page.request, base, "进度一致性", ["规划", "开发", "测试"])
        first = mission["steps"][0]["id"]
        _advance(page.request, base, mission["id"], first, "RUNNING")
        _advance(page.request, base, mission["id"], first, "COMPLETED")

        page.goto(f"{base}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail [role=progressbar]")

        rendered = page.eval_on_selector(
            "#detail .overview",
            "el => { const bar = el.querySelector('[role=progressbar]');"
            " const fill = bar.querySelector('span');"
            " return { now: bar.getAttribute('aria-valuenow'),"
            " label: bar.getAttribute('aria-label'),"
            " width: fill.style.width,"
            " text: el.querySelector('.pct').textContent }; }")
        # Width, aria-valuenow and the visible label are the same whole number.
        assert rendered["now"] == "33"
        assert rendered["width"] == "33%"
        assert "33%" in rendered["text"]
        assert "33%" in rendered["label"]
        assert "." not in rendered["now"], f"fractional progress leaked: {rendered['now']}"
        browser.close()


def test_pipeline_nodes_and_integer_stage_progress_follow_backend(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        mission = _create_mission(page.request, console_server, "节点状态", ["规划", "开发", "测试"])
        first, second = (step["id"] for step in mission["steps"][:2])
        _advance(page.request, console_server, mission["id"], first, "RUNNING")
        _advance(page.request, console_server, mission["id"], first, "COMPLETED")
        _advance(page.request, console_server, mission["id"], second, "RUNNING")

        backend = page.request.get(f"{console_server}/api/v1/missions/{mission['id']}").json()
        page.goto(f"{console_server}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail .pipeline .stage")

        stages = page.eval_on_selector_all(
            "#detail .pipeline .stage:not([data-step=''])",
            "els => els.map(el => ({label: el.querySelector('.label').textContent.trim(),"
            "aria: el.getAttribute('aria-label'), node: el.querySelector('.node').textContent.trim(),"
            "pct: el.querySelector('.meta span:last-child').textContent.trim(),"
            "width: el.querySelector('.stage-progress span').style.width,"
            "connector: getComputedStyle(el, '::after').backgroundImage}))")
        assert len(stages) == len(backend["steps"]) == 3
        for rendered, actual in zip(stages, backend["steps"]):
            pct = f"{actual['progress']}%"
            assert rendered["label"] == actual["label"]
            assert rendered["pct"].startswith(pct)
            assert rendered["width"] == pct
            assert f"进度 {pct}" in rendered["aria"]
        assert [stage["pct"].split(" · ")[0] for stage in stages] == ["100%", "1%", "0%"]
        assert stages[0]["node"] == "✓" and stages[1]["node"] == "2"
        assert page.locator("#workflow-edges path.complete").count() > 0, \
            "a completed dependency should have a green connector"

        # Connector geometry stays in one horizontal chain on desktop.
        boxes = page.eval_on_selector_all(
            "#detail .pipeline .workflow-step", "els => els.map(el => { const r=el.getBoundingClientRect(); return {x:r.x,y:r.y}; })")
        assert len({round(box["y"]) for box in boxes}) == 1
        assert all(boxes[i]["x"] < boxes[i+1]["x"] for i in range(len(boxes)-1))
        browser.close()


def test_dag_branches_merges_and_real_step_events_render(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        response = page.request.post(
            f"{console_server}/api/v1/missions",
            data=json.dumps({"title": "分支汇合", "original_input": "dag", "steps": [
                {"label": "准备"},
                {"label": "支路 A", "depends_on": ["准备"]},
                {"label": "支路 B", "depends_on": ["准备"]},
                {"label": "汇合", "depends_on": ["支路 A", "支路 B"]},
            ]}), headers=_json_headers())
        assert response.ok, response.text
        mission = response.json()
        root, branch_a, branch_b, join = mission["steps"]
        _advance(page.request, console_server, mission["id"], root["id"], "RUNNING")
        _advance(page.request, console_server, mission["id"], root["id"], "COMPLETED")
        _advance(page.request, console_server, mission["id"], branch_a["id"], "RUNNING")
        for line in ("older: warning", "renderer: missing asset"):
            error_response = page.request.post(
                f"{console_server}/api/v1/missions/{mission['id']}/events",
                data=json.dumps({"type": "ERROR", "step_id": branch_b["id"],
                                 "payload": {"line": line}}), headers=_json_headers())
            assert error_response.ok, error_response.text

        page.goto(f"{console_server}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail .pipeline-graph .workflow-step")
        geometry = page.eval_on_selector_all(
            "#detail .pipeline-graph .workflow-step",
            "els => els.map(el => ({id:el.dataset.step,label:el.querySelector('.label').textContent.trim(),"
            "deps:el.querySelector('.stage-deps').textContent,"
            "x:el.getBoundingClientRect().x,y:el.getBoundingClientRect().y,error:el.querySelector('.stage-error')?.textContent||'',"
            "meta:el.querySelector('.meta').textContent}))")
        assert len(geometry) == 4
        by_label = {step["label"]: step for step in geometry}
        assert by_label["准备"]["deps"] == "起点阶段"
        assert by_label["支路 A"]["deps"] == "依赖：准备"
        assert by_label["支路 B"]["deps"] == "依赖：准备"
        assert by_label["汇合"]["deps"] == "依赖：支路 A、支路 B"
        assert by_label["准备"]["x"] < by_label["支路 A"]["x"] < by_label["汇合"]["x"]
        assert by_label["支路 A"]["y"] != by_label["支路 B"]["y"]
        assert by_label["准备"]["error"] == ""
        assert "最近错误：renderer: missing asset" in by_label["支路 B"]["error"]
        assert "用时" in by_label["准备"]["meta"]
        paths = page.eval_on_selector_all(
            "#workflow-edges path", "els => els.map(el => ({class:el.getAttribute('class'),d:el.getAttribute('d'),stroke:getComputedStyle(el).stroke}))")
        assert len(paths) == 4 and all(path["d"].startswith("M ") for path in paths)
        assert any(path["class"] == "complete" and "74, 222, 128" in path["stroke"] for path in paths)

        # On a phone, the same dependency graph stacks topologically and keeps its wires.
        page.set_viewport_size({"width": 390, "height": 844})
        page.wait_for_timeout(100)
        overflow = page.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
        metrics = page.evaluate("""() => [...document.querySelectorAll('body *')].map(el => {
          const r=el.getBoundingClientRect(),s=getComputedStyle(el);
          return {tag:el.tagName,id:el.id,cls:el.className?.baseVal||el.className,
            left:Math.round(r.left),right:Math.round(r.right),width:Math.round(r.width),
            scrollWidth:el.scrollWidth,display:s.display,minWidth:s.minWidth,overflow:s.overflow};
        }).filter(x=>x.right>innerWidth+1||x.left< -1).slice(0,12)""")
        assert overflow <= 1, f"mobile DAG horizontal overflow: {overflow}px; elements: {metrics}"
        mobile_rows = page.eval_on_selector_all(
            "#detail .pipeline-graph .workflow-step", "els => els.map(el => el.getBoundingClientRect().y)")
        assert mobile_rows == sorted(mobile_rows)
        assert page.locator("#workflow-edges path").count() == 4
        browser.close()


def test_parallel_running_nodes_show_real_progress_and_reduced_motion(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        response = page.request.post(
            f"{console_server}/api/v1/missions",
            data=json.dumps({"title": "并行运行反馈", "original_input": "并行测试", "steps": [
                {"label": "准备"},
                {"label": "工作 A", "depends_on": ["准备"]},
                {"label": "工作 B", "depends_on": ["准备"]},
                {"label": "等待节点", "depends_on": ["工作 A", "工作 B"]},
            ]}), headers=_json_headers())
        assert response.ok, response.text
        mission = response.json()
        root, first, second, waiting = mission["steps"]
        _advance(page.request, console_server, mission["id"], root["id"], "RUNNING")
        _advance(page.request, console_server, mission["id"], root["id"], "COMPLETED")
        _advance(page.request, console_server, mission["id"], first["id"], "RUNNING")
        _advance(page.request, console_server, mission["id"], second["id"], "RUNNING")
        page.goto(f"{console_server}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail .pipeline-graph .workflow-step")

        result = page.evaluate("""() => {
          const cards = [...document.querySelectorAll('#detail .pipeline-graph .workflow-step')];
          const byLabel = label => cards.find(card => card.querySelector('.label').textContent.trim() === label);
          const active = byLabel('工作 A');
          const other = byLabel('工作 B');
          const waiting = byLabel('等待节点');
          return {
            activePercent: active.querySelector('.meta span:last-child').textContent.trim(),
            activeWidth: active.querySelector('.stage-progress span').style.width,
            activeMotion: getComputedStyle(active.querySelector('.node'), '::before').animationName,
            activeIndicatorMotion: getComputedStyle(active, '::before').animationName,
            edgeMotion: getComputedStyle(document.querySelector('#workflow-edges path.running')).animationName,
            waitingMotion: getComputedStyle(waiting.querySelector('.node'), '::before').animationName,
            parallelChips: cards.filter(card => card.querySelector('.parallel-chip')).length,
            overview: document.querySelector('#detail .pipeline-overview').textContent,
            prefersReduced: matchMedia('(prefers-reduced-motion: reduce)').matches
          };
        }""")
        assert result["activePercent"].startswith("1%")
        assert result["activeWidth"] == "1%"
        assert result["activeMotion"] == "facai-orbit"
        assert result["activeIndicatorMotion"] == "facai-indicator-flow"
        assert result["edgeMotion"] == "facai-edge-flow"
        assert result["waitingMotion"] == "none"
        assert result["parallelChips"] == 2
        assert "2 路并行" in result["overview"]

        page.emulate_media(reduced_motion="reduce")
        reduced = page.evaluate("""() => ({
          node: getComputedStyle(document.querySelector('.stage.RUNNING .node'), '::before').animationName,
          indicator: getComputedStyle(document.querySelector('.stage.RUNNING'), '::before').animationName,
          edge: getComputedStyle(document.querySelector('#workflow-edges path.running')).animationName
        })""")
        assert reduced["node"] == "none"
        assert reduced["indicator"] == "none"
        assert reduced["edge"] == "none"
        browser.close()


def test_pipeline_status_percentages_and_latest_step_events_are_truthful(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        response = page.request.post(
            f"{console_server}/api/v1/missions",
            data=json.dumps({"title": "阶段状态验收", "original_input": "状态覆盖", "steps": [
                {"label": "失败前置"},
                {"label": "卡住节点", "depends_on": ["失败前置"]},
                {"label": "工作节点"},
                {"label": "等待节点"},
                {"label": "完成节点"},
            ]}), headers=_json_headers())
        assert response.ok, response.text
        mission = response.json()
        failed, blocked, running, waiting, completed = mission["steps"]
        _advance(page.request, console_server, mission["id"], failed["id"], "RUNNING")
        _advance(page.request, console_server, mission["id"], failed["id"], "FAILED")
        _advance(page.request, console_server, mission["id"], running["id"], "RUNNING")
        for line in ("较早的输出", "最新事件：正在处理输入"):
            event_response = page.request.post(
                f"{console_server}/api/v1/missions/{mission['id']}/events",
                data=json.dumps({"type": "OUTPUT", "step_id": running["id"],
                                 "payload": {"line": line}}), headers=_json_headers())
            assert event_response.ok, event_response.text
        _advance(page.request, console_server, mission["id"], completed["id"], "RUNNING")
        _advance(page.request, console_server, mission["id"], completed["id"], "COMPLETED")

        backend = page.request.get(f"{console_server}/api/v1/missions/{mission['id']}").json()
        page.goto(f"{console_server}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail .pipeline-graph .workflow-step")
        cards = page.eval_on_selector_all(
            "#detail .pipeline-graph .workflow-step",
            "els => els.map(el => ({label:el.querySelector('.label').textContent.trim(),"
            "status:el.classList.contains('BLOCKED')?'BLOCKED':el.classList.contains('FAILED')?'FAILED':"
            "el.classList.contains('RUNNING')?'RUNNING':el.classList.contains('COMPLETED')?'COMPLETED':'WAITING',"
            "statusText:el.querySelector('.pill').textContent.trim(),"
            "percent:el.querySelector('.meta span:last-child').textContent.trim().split(' · ')[0],"
            "width:el.querySelector('.stage-progress span').style.width,"
            "recent:el.querySelector('.stage-event')?.textContent.trim()||'',"
            "error:el.querySelector('.stage-error')?.textContent.trim()||'',aria:el.getAttribute('aria-label')}))")
        announcement = page.locator("#pipeline-announcement").inner_text()
        by_label = {card["label"]: card for card in cards}
        backend_by_label = {step["label"]: step for step in backend["steps"]}
        for label, card in by_label.items():
            actual = backend_by_label[label]
            percent = f"{actual['progress']}%"
            assert card["percent"] == percent
            assert card["width"] == percent
            assert f"进度 {percent}" in card["aria"]
        assert [(name, by_label[name]["statusText"]) for name in
                ("工作节点", "等待节点", "卡住节点", "失败前置")] == [
                    ("工作节点", "工作中"), ("等待节点", "等待中"),
                    ("卡住节点", "卡住"), ("失败前置", "失败")]
        assert by_label["卡住节点"]["status"] == "BLOCKED"
        assert "依赖阻塞" in by_label["卡住节点"]["recent"]
        assert "依赖 失败前置 未满足" in by_label["卡住节点"]["recent"]
        assert "正在处理输入" in by_label["工作节点"]["recent"]
        assert "较早的输出" not in by_label["工作节点"]["recent"]
        assert by_label["失败前置"]["error"] == "最近错误：阶段失败"
        assert by_label["等待节点"]["recent"] == ""
        assert page.locator("#pipeline-announcement").get_attribute("role") == "status"
        assert page.locator("#pipeline-announcement").get_attribute("aria-live") == "polite"
        assert "工作节点：工作中，进度 1%" in announcement
        assert "卡住节点：卡住" in announcement and "依赖阻塞" in announcement
        assert "失败前置：失败" in announcement
        _advance(page.request, console_server, mission["id"], failed["id"], "RUNNING")
        page.reload(wait_until="load")
        page.wait_for_selector("#detail .pipeline-graph .workflow-step")
        recovered_announcement = page.locator("#pipeline-announcement").inner_text()
        assert "卡住节点：等待中" in recovered_announcement
        assert "最近事件：依赖解除" in recovered_announcement
        browser.close()


def test_billing_totals_use_reported_usage_and_configurable_multiplier(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        mission = _create_mission(page.request, console_server, "用量与费用", ["代码阶段", "模型阶段"])
        code_step, model_step = mission["steps"]
        events = [
            {"type": "OPENCODE_COMPLETED", "step_id": code_step["id"],
             "payload": {"cost": 0.002, "tokens": {"total": 120, "input_tokens": 80, "output_tokens": 40}}},
            {"type": "COST_RECORDED", "payload": {"amount": 0.002, "tokens": 120, "currency": "USD"}},
            {"type": "MODEL_COMPLETED", "step_id": model_step["id"],
             "payload": {"usage": {"input_tokens": 20, "output_tokens": 10, "total_tokens": 30}}},
            {"type": "COST_RECORDED", "payload": {"amount": 0.003, "tokens": 30, "currency": "USD"}},
        ]
        for event in events:
            response = page.request.post(
                f"{console_server}/api/v1/missions/{mission['id']}/events",
                data=json.dumps(event), headers=_json_headers())
            assert response.ok, response.text

        page.goto(f"{console_server}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail .billing-panel")
        panel = page.locator("#detail .billing-panel")
        assert panel.locator(".billing-metric").nth(0).inner_text().endswith("2")
        assert panel.locator(".billing-metric").nth(1).inner_text().endswith("100")
        assert panel.locator(".billing-metric").nth(2).inner_text().endswith("50")
        assert panel.locator(".billing-metric").nth(3).inner_text().endswith("150")
        assert "$0.0050" in panel.locator(".billing-metric").nth(4).inner_text()
        assert "$0.0250" in panel.locator(".billing-metric").nth(5).inner_text()

        code_metrics = page.locator(f".workflow-step[data-step='{code_step['id']}'] .stage-billing").inner_text()
        model_metrics = page.locator(f".workflow-step[data-step='{model_step['id']}'] .stage-billing").inner_text()
        assert "调用 1 次 · 输入 80 · 输出 40 · Token 120" in code_metrics
        assert "$0.0100" in code_metrics
        assert "调用 1 次 · 输入 20 · 输出 10 · Token 30" in model_metrics
        assert "倍率估算 未报告" in model_metrics, "stage cost must not be guessed from mission-only ledger rows"

        multiplier = panel.locator("#billing-multiplier")
        multiplier.fill("2.5")
        multiplier.dispatch_event("change")
        assert "$0.0125" in panel.locator(".billing-metric").nth(5).inner_text()
        assert "$0.0050" in page.locator(f".workflow-step[data-step='{code_step['id']}'] .stage-billing").inner_text()
        assert page.evaluate("localStorage.getItem('facai.billingMultiplier')") == "2.5"
        browser.close()


def test_wechat_qr_authorization_opens_modal_and_shows_loading_and_qr(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page()
        page.route("**/api/v1/channels/wechat/login", lambda route: route.fulfill(
            status=200, content_type="application/json",
            body=json.dumps({"state": "WAITING_FOR_SCAN",
                             "qr_image": "data:image/png;base64,aGVsbG8="})))
        page.goto(console_server)
        page.locator("#channel-panel").evaluate("element => { element.open = true; }")
        page.locator("#wechat-login").click()

        dialog = page.locator("#wechat-dialog")
        dialog.wait_for(state="visible")
        assert page.locator("#wqdlg-status").inner_text() == "请用个人微信扫码"
        assert page.locator("#wqdlg-qr-wrap img").is_visible()
        page.locator("#wqdlg-close").click()
        dialog.wait_for(state="hidden")
        browser.close()


def test_workflow_cards_top_align_and_clamp_verbose_event_detail(console_server, playwright_api):
    """Regression: verbose latest-event detail used to wrap in a narrow column and
    stretch sibling WAITING cards to a huge blank height. Cards must top-align,
    keep the kind/time on one row, and clamp the detail to a full-width second row
    while retaining the full text in the accessible title."""
    base = console_server
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        mission = _create_mission(page.request, base, "卡片布局回归", ["规划", "开发", "测试"])
        first, second, _third = mission["steps"]
        _advance(page.request, base, mission["id"], first["id"], "RUNNING")
        _advance(page.request, base, mission["id"], first["id"], "COMPLETED")
        _advance(page.request, base, mission["id"], second["id"], "RUNNING")
        long_line = "正在处理输入 " + "很长的日志内容 " * 60
        response = page.request.post(
            f"{base}/api/v1/missions/{mission['id']}/events",
            data=json.dumps({"type": "OUTPUT", "step_id": second["id"],
                             "payload": {"line": long_line}}), headers=_json_headers())
        assert response.ok, response.text

        page.goto(f"{base}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#detail .pipeline-graph .workflow-step")
        layout = page.evaluate("""() => {
          const canvas = document.querySelector('#detail .pipeline-canvas');
          const cards = [...document.querySelectorAll('#detail .pipeline-graph .workflow-step')];
          const byLabel = label => cards.find(card => card.querySelector('.label').textContent.trim() === label);
          const running = byLabel('开发');
          const waiting = byLabel('测试');
          const detail = running.querySelector('.stage-event .event-detail');
          const detailStyle = getComputedStyle(detail);
          return {
            align: getComputedStyle(canvas).alignItems,
            runningTop: running.getBoundingClientRect().top,
            waitingTop: waiting.getBoundingClientRect().top,
            runningHeight: running.getBoundingClientRect().height,
            waitingHeight: waiting.getBoundingClientRect().height,
            detailColumnStart: detailStyle.gridColumnStart,
            detailColumnEnd: detailStyle.gridColumnEnd,
            detailLines: detailStyle.webkitLineClamp,
            detailTitle: running.querySelector('.stage-event').getAttribute('title'),
          };
        }""")
        assert layout["align"] == "start", "workflow grid must top-align instead of stretching siblings"
        assert abs(layout["runningTop"] - layout["waitingTop"]) <= 1, "cards in one row should share a top edge"
        assert layout["waitingHeight"] < layout["runningHeight"] - 10, \
            "a WAITING sibling must not be stretched to the tall RUNNING card"
        assert layout["detailColumnStart"] == "1" and layout["detailColumnEnd"] == "-1", \
            "verbose event detail must occupy a full-width second row"
        assert layout["detailLines"] == "3", "verbose event detail should be clamped to a few lines"
        assert "很长的日志内容" in (layout["detailTitle"] or ""), \
            "full event text must remain accessible in the title"
        browser.close()


def test_deep_link_mission_is_restored_after_login(protected_server, playwright_api):
    base = protected_server
    basic = base64.b64encode(b"admin:mobile-pass").decode()
    auth = {"Authorization": f"Basic {basic}"}
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": 390, "height": 844})
        mission = _create_mission(page.request, base, "登录后恢复", ["规划", "开发"], headers=auth)

        page.goto(f"{base}/?mission={mission['id']}", wait_until="load")
        page.wait_for_selector("#login-form")
        assert "/login" in page.url and "next=" in page.url

        page.fill("#password", "mobile-pass")
        page.click("#submit")
        page.wait_for_selector("#detail [role=progressbar]", timeout=10000)

        assert f"mission={mission['id']}" in page.url, "deep link must survive login"
        assert mission["title"] in page.inner_text("#detail h2")
        browser.close()
