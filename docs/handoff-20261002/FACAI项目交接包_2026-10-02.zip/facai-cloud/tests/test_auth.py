"""Production session authentication: login, CSRF, throttling, logout, expiry."""

import base64

import pytest
from fastapi.testclient import TestClient

from facai.api import create_app
from facai.auth import SESSION_COOKIE, hash_token
from facai.store import Store


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_ADMIN_PASSWORD", "correct-horse")
    monkeypatch.delenv("FACAI_COOKIE_SECURE", raising=False)
    return TestClient(create_app(tmp_path))


def login(client, password="correct-horse"):
    response = client.post("/api/v1/auth/login", json={"username": "admin", "password": password})
    assert response.status_code == 200
    return response.json()


def test_session_login_csrf_and_logout(client):
    assert client.get("/api/v1/missions").status_code == 401
    session = login(client)
    assert session["authenticated"] is True
    assert session["csrf_token"]
    assert SESSION_COOKIE in client.cookies

    assert client.get("/api/v1/missions").status_code == 200
    # Unsafe request without the CSRF header is rejected.
    blocked = client.post("/api/v1/missions", json={
        "title": "A", "original_input": "A", "steps": ["Build"]})
    assert blocked.status_code == 403

    created = client.post("/api/v1/missions", headers={"X-CSRF-Token": session["csrf_token"]}, json={
        "title": "A", "original_input": "A", "steps": ["Build"]})
    assert created.status_code == 201

    assert client.post("/api/v1/auth/logout").status_code == 200
    assert client.get("/api/v1/missions").status_code == 401


def test_wrong_password_and_basic_fallback(client):
    assert client.post("/api/v1/auth/login", json={
        "username": "admin", "password": "wrong"}).status_code == 401
    # HTTP Basic stays available for scripts and health tooling.
    encoded = base64.b64encode(b"admin:correct-horse").decode()
    headers = {"Authorization": f"Basic {encoded}"}
    assert client.get("/api/v1/missions", headers=headers).status_code == 200
    assert client.get("/", headers=headers).status_code == 200


def test_browser_navigation_redirects_to_login(client):
    page = client.get("/", headers={"Accept": "text/html"}, follow_redirects=False)
    assert page.status_code == 303
    # The original path is preserved so a deep link survives the login round-trip.
    assert page.headers["location"].startswith("/login")
    assert "next=" in page.headers["location"]
    assert client.get("/login").status_code == 200
    assert client.get("/login").text.count("登录") >= 1


def test_login_throttling(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_ADMIN_PASSWORD", "correct-horse")
    monkeypatch.setenv("FACAI_LOGIN_MAX_FAILURES", "3")
    client = TestClient(create_app(tmp_path))
    for _ in range(3):
        assert client.post("/api/v1/auth/login", json={
            "username": "admin", "password": "no"}).status_code == 401
    # Even a correct password is refused while the lockout is active.
    assert client.post("/api/v1/auth/login", json={
        "username": "admin", "password": "correct-horse"}).status_code == 429


def test_expired_session_is_rejected(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_ADMIN_PASSWORD", "correct-horse")
    app = create_app(tmp_path)
    client = TestClient(app)
    login(client)
    with app.state.store.connect() as db:
        db.execute("UPDATE auth_sessions SET expires_at='2000-01-01T00:00:00+00:00'")
    assert client.get("/api/v1/missions").status_code == 401


def test_raw_session_token_is_never_stored(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_ADMIN_PASSWORD", "correct-horse")
    app = create_app(tmp_path)
    client = TestClient(app)
    session = login(client)
    token = client.cookies.get(SESSION_COOKIE)
    with app.state.store.connect() as db:
        row = db.execute("SELECT token_hash, csrf_token FROM auth_sessions").fetchone()
    assert token != row["token_hash"]
    assert session["csrf_token"] == row["csrf_token"]
    assert hash_token(token) == row["token_hash"]
    assert "correct-horse" not in f"{row['token_hash']} {row['csrf_token']}"


def test_auth_disabled_without_password(tmp_path, monkeypatch):
    monkeypatch.delenv("FACAI_ADMIN_PASSWORD", raising=False)
    client = TestClient(create_app(tmp_path))
    assert client.get("/api/v1/missions").status_code == 200
    assert client.get("/api/v1/auth/session").json() == {
        "auth_required": False, "authenticated": True, "username": "admin"}
    assert client.get("/api/v1/health").json()["auth_required"] is False


def test_secure_cookie_flag_respects_environment(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_ADMIN_PASSWORD", "correct-horse")
    monkeypatch.setenv("FACAI_COOKIE_SECURE", "1")
    client = TestClient(create_app(tmp_path))
    response = client.post("/api/v1/auth/login", json={"username": "admin", "password": "correct-horse"})
    cookie = response.headers["set-cookie"].lower()
    assert "secure" in cookie and "httponly" in cookie and "samesite=strict" in cookie


def test_multi_user_mission_and_cost_isolation(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_USERS_JSON", '{"alice":"alice-pass","bob":"bob-pass"}')
    monkeypatch.delenv("FACAI_ADMIN_PASSWORD", raising=False)
    app = create_app(tmp_path)
    alice = TestClient(app)
    bob = TestClient(app)

    alice_session = alice.post("/api/v1/auth/login", json={
        "username": "alice", "password": "alice-pass"}).json()
    bob_session = bob.post("/api/v1/auth/login", json={
        "username": "bob", "password": "bob-pass"}).json()
    assert alice_session["username"] == "alice"
    assert bob_session["username"] == "bob"

    alice_mission = alice.post("/api/v1/missions", headers={
        "X-CSRF-Token": alice_session["csrf_token"]}, json={
            "title": "Alice", "original_input": "private", "steps": ["Build"]}).json()
    bob_mission = bob.post("/api/v1/missions", headers={
        "X-CSRF-Token": bob_session["csrf_token"]}, json={
            "title": "Bob", "original_input": "private", "steps": ["Build"]}).json()

    assert [m["title"] for m in alice.get("/api/v1/missions").json()] == ["Alice"]
    assert [m["title"] for m in bob.get("/api/v1/missions").json()] == ["Bob"]
    assert alice.get(f"/api/v1/missions/{bob_mission['id']}").status_code == 404
    assert bob.get(f"/api/v1/missions/{alice_mission['id']}").status_code == 404

    store = app.state.store
    store.add_cost(alice_mission["id"], "mock", "model", 2.5, tokens=10)
    alice_message = store.record_channel_message(
        "telegram", "INBOUND", "RECEIVED", external_id="alice-1", text="alice secret",
        owner_id="alice")
    bob_message = store.record_channel_message(
        "telegram", "INBOUND", "RECEIVED", external_id="bob-1", text="bob secret",
        owner_id="bob")
    assert alice.get(f"/api/v1/missions/{alice_mission['id']}").json()["cost_total"] == 2.5
    assert bob.get(f"/api/v1/missions/{alice_mission['id']}").status_code == 404
    assert [m["text"] for m in alice.get("/api/v1/inbox").json()] == ["alice secret"]
    assert [m["text"] for m in bob.get("/api/v1/inbox").json()] == ["bob secret"]
    assert alice.get(f"/api/v1/channels/telegram/messages/{bob_message}/events").status_code == 404


def test_multi_user_job_id_guessing_is_rejected(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_USERS_JSON", '{"alice":"alice-pass","bob":"bob-pass"}')
    monkeypatch.delenv("FACAI_ADMIN_PASSWORD", raising=False)
    monkeypatch.setenv("FACAI_SCHEDULER_ENABLED", "0")
    app = create_app(tmp_path)
    alice, bob = TestClient(app), TestClient(app)
    alice_session = alice.post("/api/v1/auth/login", json={
        "username": "alice", "password": "alice-pass"}).json()
    bob_session = bob.post("/api/v1/auth/login", json={
        "username": "bob", "password": "bob-pass"}).json()

    mission = alice.post("/api/v1/missions", headers={
        "X-CSRF-Token": alice_session["csrf_token"]}, json={
            "title": "Alice", "original_input": "private", "steps": ["Build"]}).json()
    alice.put(f"/api/v1/missions/{mission['id']}/binding", headers={
        "X-CSRF-Token": alice_session["csrf_token"]},
        json={"agent_id": "opencode", "model_id": "deepseek-flash", "runtime_id": "local"})
    job = alice.post(f"/api/v1/missions/{mission['id']}/jobs", headers={
        "X-CSRF-Token": alice_session["csrf_token"]},
        json={"prompt": "alice private prompt", "step_id": mission["steps"][0]["id"]}).json()
    assert job["status"] == "QUEUED"

    # A globally unique job id must not let another tenant read its payload.
    assert bob.get(f"/api/v1/jobs/{job['id']}").status_code == 404
    # Nor mutate it: pause/resume/cancel/retry all resolve through the mission owner.
    for action in ("pause", "resume", "cancel", "retry"):
        assert bob.post(f"/api/v1/jobs/{job['id']}/{action}", headers={
            "X-CSRF-Token": bob_session["csrf_token"]}).status_code == 404

    assert bob.get(f"/api/v1/missions/{mission['id']}/jobs").status_code == 404
    owner_view = alice.get(f"/api/v1/jobs/{job['id']}").json()
    assert owner_view["prompt"] == "alice private prompt"
    assert owner_view["status"] == "QUEUED"


def test_multi_user_configuration_is_capped_at_five(tmp_path, monkeypatch):
    monkeypatch.setenv("FACAI_USERS_JSON", '{"1":"p","2":"p","3":"p","4":"p","5":"p","6":"p"}')
    with pytest.raises(RuntimeError, match="at most five users"):
        create_app(tmp_path)
