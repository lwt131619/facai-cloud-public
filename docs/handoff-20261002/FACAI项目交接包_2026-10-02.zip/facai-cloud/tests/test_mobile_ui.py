"""Real-browser verification of the mobile console and login flow.

These tests run the FastAPI app under uvicorn and drive a Chromium (Playwright)
device viewport. They are skipped when Playwright or its browser is unavailable
so the core test suite stays runnable everywhere. Shared fixtures live in
``tests/conftest.py``.
"""

import json

import pytest


def _launch(playwright):
    try:
        return playwright.chromium.launch()
    except Exception as exc:  # browser binary not installed
        pytest.skip(f"Playwright chromium unavailable: {exc}")


def _phone(browser):
    return browser.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2,
                            is_mobile=True, has_touch=True)


def _create_mission(request, base, title="移动端核验"):
    response = request.post(
        base + "/api/v1/missions",
        data=json.dumps({"title": title, "original_input": "原始要求逐字保留",
                         "steps": ["规划", "开发", "测试"]}),
        headers={"Content-Type": "application/json"})
    assert response.ok, response.text
    return response.json()


def test_mobile_console_layout_has_no_overflow_and_is_tappable(console_server, tmp_path, playwright_api):
    errors = []
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = _phone(browser)
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

        # Creation lives in a collapsible secondary section that starts closed.
        page.goto(console_server + "/", wait_until="load")
        assert page.eval_on_selector("#create-panel", "el => el.open") is False
        page.click("#create-panel > summary")
        assert page.eval_on_selector("#create-panel", "el => el.open") is True
        page.fill('input[name="title"]', "移动端核验")
        page.fill('textarea[name="original_input"]', "原始要求逐字保留")
        page.fill('textarea[name="steps"]', "规划\n开发")
        page.click('#create-form button[type="submit"]')
        page.wait_for_selector("#detail .pipeline .stage")

        # Re-open the deep link the way a real user would; the progress bar and the
        # current stage must be visible in the first 390x844 screen.
        mission_id = page.url.split("mission=")[-1]
        page.goto(f"{console_server}/?mission={mission_id}", wait_until="load")
        page.wait_for_selector("#detail [role=progressbar]")
        progress = page.eval_on_selector(
            "#detail [role=progressbar]",
            "el => { const r = el.getBoundingClientRect(); return { top: r.top, bottom: r.bottom }; }")
        assert 0 <= progress["top"] and progress["bottom"] <= 844, \
            f"progress bar not on the first phone screen: {progress}"
        current = page.eval_on_selector("#detail #current-stage", "el => el.getBoundingClientRect().bottom")
        assert current <= 844, "current stage not on the first phone screen"

        overflow = page.evaluate(
            "document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 1, f"horizontal overflow of {overflow}px"

        widths = page.eval_on_selector_all(
            "#detail .pipeline .stage", "els => els.map(e => e.getBoundingClientRect().width)")
        assert widths and max(widths) - min(widths) < 5, "pipeline should stack vertically on phones"

        heights = page.eval_on_selector_all(
            "#detail .pipeline .stage", "els => els.map(e => e.getBoundingClientRect().height)")
        assert min(heights) >= 44, f"stage tap targets too small: {heights}"

        page.click("#detail .pipeline .workflow-step[data-step]")
        page.wait_for_selector("#detail #timeline")
        action_heights = page.eval_on_selector_all(
            "#detail .actions button", "els => els.map(e => e.getBoundingClientRect().height)")
        assert min(action_heights) >= 40, f"action tap targets too small: {action_heights}"

        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        assert page.eval_on_selector("header", "e => e.getBoundingClientRect().top") == 0, \
            "header must stay sticky on phones"
        assert page.get_attribute("#detail #timeline", "aria-live") == "polite"

        shot = tmp_path / "mobile-console.png"
        page.screenshot(path=str(shot), full_page=True)
        assert shot.exists() and shot.stat().st_size > 0
        browser.close()
    assert not errors, f"console errors: {errors}"


def test_mobile_login_flow(protected_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = _phone(browser)
        page.goto(protected_server + "/", wait_until="load")
        page.wait_for_selector("#login-form")

        page.fill("#password", "wrong")
        page.click("#submit")
        page.wait_for_function("document.querySelector('#error').textContent.length > 0")

        page.fill("#password", "mobile-pass")
        page.click("#submit")
        page.wait_for_selector("header #logout", timeout=10000)
        assert page.url.rstrip("/") == protected_server

        overflow = page.evaluate(
            "document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 1
        browser.close()


def test_mobile_billing_metrics_wrap_without_horizontal_overflow(console_server, playwright_api):
    with playwright_api.sync_playwright() as p:
        browser = _launch(p)
        page = _phone(browser)
        response = page.request.post(
            f"{console_server}/api/v1/missions",
            data=json.dumps({"title": "移动端费用显示", "original_input": "用量验收", "steps": ["长阶段名称用于费用布局验证"]}),
            headers={"Content-Type": "application/json"})
        assert response.ok, response.text
        mission = response.json()
        step = mission["steps"][0]
        for event in (
            {"type": "OPENCODE_COMPLETED", "step_id": step["id"], "payload": {
                "cost": 0.001234, "tokens": {"total": 7656, "input_tokens": 4000, "output_tokens": 3656}}},
            {"type": "COST_RECORDED", "payload": {"amount": 0.001234, "tokens": 7656, "currency": "USD"}},
        ):
            created = page.request.post(
                f"{console_server}/api/v1/missions/{mission['id']}/events",
                data=json.dumps(event), headers={"Content-Type": "application/json"})
            assert created.ok, created.text
        page.goto(f"{console_server}/?mission={mission['id']}", wait_until="load")
        panel = page.locator("#detail .billing-panel")
        panel.wait_for()
        assert "7,656" in panel.inner_text()
        assert "$0.00617" in panel.locator(".billing-metric").nth(5).inner_text()
        overflow = page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        assert overflow <= 1, f"billing UI caused horizontal overflow of {overflow}px"
        panel_box = panel.bounding_box()
        viewport_width = page.evaluate("document.documentElement.clientWidth")
        assert panel_box["x"] >= 0 and panel_box["x"] + panel_box["width"] <= viewport_width + 1
        browser.close()
