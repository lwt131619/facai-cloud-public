"""The deployment plane must be safe and parseable before it ever runs.

These checks are static (they run everywhere) plus an optional real
``nginx -t`` / ``bash -n`` pass driven by ``deploy/validate_config.sh``.
"""

import os
import re
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
HTTP_CONF = ROOT / 'deploy' / 'nginx' / 'facai-cloud.http.conf'
TLS_CONF = ROOT / 'deploy' / 'nginx' / 'facai-cloud.conf'
DEPLOY = ROOT / 'deploy' / 'deploy.sh'
INSTALL_OPENCODE = ROOT / 'deploy' / 'install-opencode.sh'
SERVICE_UNIT = ROOT / 'deploy' / 'systemd' / 'facai-cloud.service'
APP_ENV_EXAMPLE = ROOT / 'deploy' / 'facai.env.example'
PROVIDER_DIR = ROOT / 'deploy' / 'providers'
PROVIDER_EXAMPLE = PROVIDER_DIR / 'deepseek.env.example'


def code_only(path):
    """Strip ``#`` comment lines so prose cannot satisfy or break a check."""
    lines = path.read_text(encoding='utf-8').splitlines()
    return '\n'.join(line for line in lines if not line.lstrip().startswith('#'))


def find_bash():
    candidates = []
    override = os.environ.get('FACAI_BASH')
    if override:
        candidates.append(override)
    if os.name == 'nt':
        candidates += [
            r'C:\Program Files\Git\bin\bash.exe',
            r'C:\Program Files (x86)\Git\bin\bash.exe',
        ]
    else:
        candidates.append('/bin/bash')
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return candidate
    return None


def test_http_bootstrap_needs_no_certificate():
    conf = code_only(HTTP_CONF)
    assert 'listen 80' in conf
    assert '.well-known/acme-challenge' in conf
    assert 'listen 443' not in conf
    assert 'ssl_certificate' not in conf


def test_tls_config_requires_cert_and_omits_includesubdomains():
    conf = code_only(TLS_CONF)
    assert 'ssl_certificate' in conf
    assert '/etc/letsencrypt/live/' in conf
    assert 'Strict-Transport-Security' in conf
    assert 'includeSubDomains' not in conf


def test_deploy_gates_tls_and_preserves_unknown_files():
    script = DEPLOY.read_text(encoding='utf-8')
    # Two-phase install: HTTP bootstrap first, TLS only once a cert exists.
    assert 'facai-cloud.http.conf' in script
    assert 'facai-cloud.conf' in script
    assert 'has_cert' in script
    assert 'cmd_cert' in script
    # Scoped rsync: delete only inside managed paths, protect data and the rest.
    assert '--delete' in script
    assert "--exclude '/*'" in script
    assert 'P data' in script
    # Recoverability.
    assert 'backup_app_dir' in script
    assert 'cmd_rollback' in script


def test_managed_includes_reference_existing_paths():
    """Every `--include '/path'` must exist in the checkout.

    A typo here (e.g. a renamed top-level script) makes rsync silently skip the
    file, so the VPS would never receive it. This guards that class of bug.
    """
    script = DEPLOY.read_text(encoding='utf-8')
    managed = re.findall(r"--include '/+([^']+)'", script)
    assert managed, 'deploy.sh declares no managed include paths'
    for entry in managed:
        relative = entry.split('/***')[0].strip('/')
        assert (ROOT / relative).exists(), f'deploy.sh manages a missing path: {entry}'


def test_update_reinstalls_service_and_proxy_config():
    """`update` must not leave a changed unit or nginx config behind."""
    script = DEPLOY.read_text(encoding='utf-8')
    assert 'cmd_update()' in script
    body = script.split('cmd_update()', 1)[1].split('cmd_cert()', 1)[0]
    assert 'install_systemd' in body
    assert 'install_nginx' in body


def test_deploy_refuses_public_tls_without_credentials():
    """Enabling TLS exposes the API, so cert/update must fail safe.

    `update` must not reinstall a unit whose EnvironmentFile is missing, and
    `cert` must not enable public HTTPS while FACAI_ADMIN_PASSWORD is unset.
    """
    script = DEPLOY.read_text(encoding='utf-8')
    assert 'require_env_file' in script
    assert 'require_admin_password' in script
    assert 'adopt_legacy_env' in script
    update_body = script.split('cmd_update()', 1)[1].split('cmd_cert()', 1)[0]
    assert 'require_env_file' in update_body
    cert_body = script.split('cmd_cert()', 1)[1].split('cmd_backup()', 1)[0]
    assert 'require_admin_password' in cert_body


def test_service_unit_gives_opencode_a_path_and_writable_home():
    """The adapter resolves `opencode` on PATH and the CLI writes under $HOME.

    The hardened unit makes ``/opt/facai-cloud/data`` the only writable path, so
    HOME must live there; otherwise every run fails with a read-only filesystem.
    """
    unit = code_only(SERVICE_UNIT)
    assert 'Environment=PATH=/usr/local/bin' in unit
    assert 'Environment=HOME=/opt/facai-cloud/data/' in unit
    assert 'XDG_DATA_HOME=/opt/facai-cloud/data/' in unit
    assert 'EnvironmentFile=/etc/facai-cloud/facai.env' in unit
    assert 'ReadWritePaths=/opt/facai-cloud/data' in unit
    # No credential may be baked into the unit.
    for forbidden in ('DEEPSEEK_API_KEY=', 'FACAI_ADMIN_PASSWORD=', 'sk-'):
        assert forbidden not in unit


def test_opencode_installer_pins_and_verifies_version():
    """A pinned, checksum-verified install; never an unpinned download."""
    script = code_only(INSTALL_OPENCODE)
    assert 'OPENCODE_VERSION="${OPENCODE_VERSION:-' in script
    assert 'OPENCODE_SHA256="${OPENCODE_SHA256:-' in script
    assert 'sha256sum' in script
    assert 'SHA-256 mismatch' in script
    assert 'anomalyco/opencode/releases/download/v${OPENCODE_VERSION}' in script
    assert 'install -m 0755' in script
    # It must not touch any model credential.
    assert 'DEEPSEEK_API_KEY' not in script
    assert 'api_key' not in script.lower()


def test_deploy_manages_the_opencode_home_and_action():
    script = DEPLOY.read_text(encoding='utf-8')
    assert 'prepare_opencode_home' in script
    assert 'cmd_opencode' in script
    assert 'install-opencode.sh' in script
    # install and update both prepare the writable OpenCode HOME.
    install_body = script.split('cmd_install()', 1)[1].split('cmd_update()', 1)[0]
    update_body = script.split('cmd_update()', 1)[1].split('cmd_opencode()', 1)[0]
    assert 'prepare_opencode_home' in install_body
    assert 'prepare_opencode_home' in update_body


def test_service_unit_loads_app_and_classified_provider_env():
    """The unit must load the app env and every classified provider file.

    Provider credentials are one file per service under providers/; the leading
    '-' keeps the unit valid before the first provider file exists.
    """
    unit = code_only(SERVICE_UNIT)
    assert 'EnvironmentFile=/etc/facai-cloud/facai.env' in unit
    assert 'EnvironmentFile=-/etc/facai-cloud/providers/*.env' in unit


def test_app_env_example_has_no_provider_credentials():
    """Application login/runtime config must not carry model keys.

    Only the actively-used DeepSeek key may ever be migrated; unused providers
    (Tavily/Bocha/Agnes/Claude/Pollinations) must not appear at all.
    """
    text = APP_ENV_EXAMPLE.read_text(encoding='utf-8')
    assert 'DEEPSEEK_API_KEY' not in text
    for unused in ('TAVILY', 'BOCHA', 'AGNES', 'ANTHROPIC', 'CLAUDE', 'POLLINATIONS'):
        assert unused not in text
    # The template points at the classified provider directory instead.
    assert 'providers/' in text


def test_provider_env_template_declares_only_a_name():
    """A committed provider template must declare the key name, never a value."""
    assert PROVIDER_EXAMPLE.is_file()
    lines = [
        line for line in PROVIDER_EXAMPLE.read_text(encoding='utf-8').splitlines()
        if not line.lstrip().startswith('#')
    ]
    body = '\n'.join(lines)
    assert 'DEEPSEEK_API_KEY=' in body
    assert re.search(r'DEEPSEEK_API_KEY=.+', body) is None, 'template must not contain a value'


def test_every_provider_template_declares_names_without_values():
    """No classified provider template may carry a real credential value.

    Channel credentials (WhatsApp/WeChat/Telegram) are templates like DeepSeek:
    they declare the variable names and leave the values empty so nothing secret
    can be committed.
    """
    templates = sorted(PROVIDER_DIR.glob('*.env.example'))
    assert templates, 'no provider templates found'
    for template in templates:
        for line in template.read_text(encoding='utf-8').splitlines():
            stripped = line.strip()
            if stripped.startswith('#') or '=' not in stripped:
                continue
            name, _, value = stripped.partition('=')
            assert name.isupper(), f'{template.name}: {name} is not an env name'
            assert value == '', f'{template.name}: {name} must not carry a value'


def test_deploy_owns_the_provider_split_with_backup():
    """install/update must seed classified files, migrate once and back up first."""
    script = DEPLOY.read_text(encoding='utf-8')
    assert 'PROVIDER_ENV_DIR' in script
    assert 'install_provider_env_files' in script
    assert 'classify_deepseek_env' in script
    assert 'backup_env_dir' in script
    for phase in ('cmd_install()', 'cmd_update()'):
        body = script.split(phase, 1)[1].split('\n}', 1)[0]
        assert 'install_provider_env_files' in body
        assert 'classify_deepseek_env' in body
        assert 'backup_env_dir' in body


def test_validate_config_script_passes():
    bash = find_bash()
    if not bash:
        pytest.skip('bash unavailable')
    script = str(ROOT / 'deploy' / 'validate_config.sh').replace('\\', '/')
    result = subprocess.run(
        [bash, script],
        capture_output=True, text=True, timeout=120,
    )
    output = (result.stdout or '') + (result.stderr or '')
    if result.returncode != 0 and 'WSL' in output and 'execvpe' in output:
        pytest.skip('only the WSL bash launcher is available (no distro)')
    assert result.returncode == 0, output
